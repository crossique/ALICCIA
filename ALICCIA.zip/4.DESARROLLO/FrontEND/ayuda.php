<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
	</head>
	<body>
	   	<?php include 'base/cabecera.php';?>

	   	<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->
   	<div class="row">
    <div class="container-fluid px-5 pt-2 col-md-12 col-sm-12"">

		<div class="text-justify pt-2 pl-1">
		<p>Este sitio web es el resultado de mi TFM "Investigación y desarrollo de facilitadores de deliberación y decisión colectivas basado en IA" cuyos objetivos son:</p> 
		<p> 1) La investigación del estado del arte tecnológico aplicado a la toma de decisiones colectivas de manera deliberativa.</p>
		<p> 2) El diseño y desarrollo de un prototipo de asistente basado en IA que facilite estos procesos mediante técnicas de procesamiento de lenguaje natural (PLN), razonamiento automático y optimización multiobjetivo. Este prototipo denominado provisionalmente “Aplicación - Laboratorio de Inteligencia Colectiva y Consenso basado en IA” (ALICCIA), se concibe como:</p>
		<ul>
		<li>Guía pedagógica, mostrando formas de aplicación de la IA en la deliberación colectiva.</li>
		<li>Laboratorio, para testear algoritmos y metodologías en contextos reales o simulados.</li>
		<li>Plataforma abierta, sirviendo de base extensible para futuros desarrollos en el campo.</li>
		</ul>
		</div>
		<div class="col-md-6 ">
        <img src="img/general/objetivos.png" class="alinea pl-1" height="300px" width="600px" style="display: inline-block" class="img-responsive">
		</div>
		<hr/>
	    <div class="row">
	    	<img src="img/general/pdf.png" class="alinea pl-1" height="40px" width="40px" style="display: inline-block"><h5 class= "px-2 pt-2">DOCUMENTOS RELATIVOS A LA APLICACIÓN</h5>	
	    </div>		
		<div class="row px-2 pb-1">
			<div class="col-md-12 col-sm-12 text-justify">

				<ul>
					<li class="list-item py-1">
						<b><a href="docs/Estado del arte.pdf">Estado del Arte de herramientas deliberativas on-line</a></b> una revisión de herramientas digitales que existen o han existido con el objetivo de facilitar los debates abiertos y las decsisiones colectivas, y el incipiente uso de la IA en este campo.
					</li>
					<li class="list-item py-1">
						<b><a href="docs/Fundamentos teóricos.pdf">Fundamentos teóricos</a></b>: una exposición de la base teórica de los acercamientos de esta aplicación: el método Delphi de deliberación, el Frente de Pareto en planificación multiobjetivo, los modelos largos de lenguaje (LLM) y el planteamiento de un nuevo y original álgebra de propuestas en debates deliberativos. Algunos de estos fundamentos pueden ser experimentados en la sección "Lab".
					</li>					
					<li class="list-item py-1">
						<b><a href="docs/Manual de usuario.pdf">Manual de usuario básico (PENDIENTE)</a></b>: una guía rápida e introductoria a la aplicación, sus páginas, sus funcionalidades y los modos de operarla.
					</li>
					<li class="list-item py-1">
						<b><a href="docs/Glosario.pdf">Glosario de términos (PENDIENTE)</a></b>: un listado de términos comunmente usados en debates deliberativos, inteligencia artificial y eDemocracy.
					</li>					
				</ul>
			</div>
	
		</div>
		<div class="row px-2 pb-2">

		</div>
	</div>
    <div class="container-fluid px-5 pt-2 col-md-4 col-sm-12"">
		<div class="row pb-2">
		</div>
	</div>
</div>
		<!-- FIN CONTENIDO ESPECÍFICO -->

		<?php include 'base/pie.php';?>
   </body>
</html>