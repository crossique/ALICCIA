// Añadir registros
function InsertGD() {
    // toma valores
    var nombre_gd = $("#nombre_gd").val();
    // añade el registro
    $.post("datos/insertarGD.php", {
        nombre_gd: nombre_gd

    }, function (data, status) {
        // cierra el popup
        $("#add_new_group_modal").modal("hide");
         // limpiar campos del popup
        $("#nombre_gd").val("");
        // leer los grupos de nuevo
        SelectGDs();
        refresh();
    });
}

function InsertUserGD() {
    // toma valores
    var emailUGD = $("#emailUGD").val();
    console.log(emailUGD);
    var filtroGD = $("#filtroGD").val();
    // añade el registro
    console.log(filtroGD);
    if (filtroGD == 1) {alert("No tiene sentido añadir usuarios al grupo ABIERTO");}
    else{
    $.post("datos/insertarUsuarioGD.php", {
        emailUGD: emailUGD,
        filtroGD: filtroGD
    }, function (data, status) {
        // cierra el popup
        $("#add_new_user-group_modal").modal("hide");
        // leer los usuarios de nuevo
        SelectUsersGD();
         // limpiar campos del popup
        $("#emailUGD").val("");
    });}
}


// Leer registros
function SelectGDs() {
    $.post("datos/listarGDs.php", {}, function (data, status) {
        $(".records_content_gd").html(data);
    });
}

function SelectUsersGD() {
    var filtro = $("#filtro").val();
    $.post("datos/listarUsuariosGD.php", {filtro: filtro}, function (data, status) {
        $(".records_content_ud").html(data);
    });
}

// Borrar registros
function DeleteGD(id) {
    window.alert("Se le pedirá confirmación");
    var conf = confirm("¿Quiere realmente borrar el grupo? (Si hay debates dependientes o se trata del grupo ABIERTO, no se borrará)");
    if (conf == true) {
         $.post("datos/borrarGD.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                SelectGDs();
            }
        );
    }else{alert("Borrado no confirmado");}
}

function DeleteUserGD(id,gd) {
    window.alert("Se le pedirá confirmación");
    var conf = confirm("¿Quiere realmente borrar el usuario?");
    if (conf == true) {
         $.post("datos/borrarUsuarioGD.php", {
                id: id,
                gd: gd
            },
            function (data, status) {
                // reload Users by using readRecords();
                SelectUsersGD();
            }
        );
    }else{alert("Borrado no confirmado");}
}

function refresh()
{
    location.reload(true);
}


$(document).ready(function () {
    // Leer registros al cargar la página
    SelectGDs(); 
    SelectUsersGD(); 
});