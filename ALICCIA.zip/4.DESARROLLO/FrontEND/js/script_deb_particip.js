 
// READ records
function SelectPropuestas() {
    $.get("datos/listarPropuestas.php", {}, function (data, status) {
        $(".records_content_dresp").html(data);
    });
}

function LeerPropuesta(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_propuesta_id").val(id);
    $.post("datos/leerPropuesta.php", {
            id: id
        },
        function (data, status) {
            var user = JSON.parse(data);
            $("#update_texto_P").val(user.texto_respuesta);
        }
    );
    $("#texto_modal").modal("show");
}

function EvolucionarPropuesta(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_propuesta2_id").val(id);
    $.post("datos/evolucionarPropuesta.php", {
            id: id
        },
        function (data, status) {
            var datos = JSON.parse(data);
            $("#update_texto_EV").val(datos.valor);
        }
    );
    $("#evolucion_modal").modal("show");
}

function AbrirValoracion(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_respuesta_id").val(id);
        // Open modal popup
    $("#valoracion_modal").modal("show");
}

function InsertarValoracion() {
    // get values
    var id_debate = $("#vm_debate").val();
    var id_propuesta = $("#hidden_respuesta_id").val();
    var email_nick = $("#vm_email_nick").val();
    var valoracion = $("#vm_valor").val();
    var comm = $("#vm_comentario").val();
 
    // Add record
    $.post("datos/insertarValoracion.php", {
        id_debate: id_debate,
        id_propuesta: id_propuesta,
        email_nick: email_nick,
        valoracion: valoracion,
        comm: comm

    }, function (data, status) {
        // cierra el popup
            $("#valoracion_modal").modal("hide");
            $('.modal-backdrop').remove();
            // reload Users by using readRecords();
            window.alert("Compruebe que su valoración/comentario se ha insertado. No se insertará si ya ha valorado previamente esta propuesta");
 
        // read records again
        SelectPropuestas();
        refresh();  

    });
}

function SelectValoraciones(id) {
    // Add User ID to the hidden field for furture usage
    
    $.get("datos/listarValoraciones.php", {
        id:id
    }, function (data, status) {
        $(".records_content_vv").html(data);
    });
    $("#valoraciones_modal").modal("show");
}

function refresh()
{
    location.reload(true);
}

$(document).ready(function () {
    SelectPropuestas(); 
});