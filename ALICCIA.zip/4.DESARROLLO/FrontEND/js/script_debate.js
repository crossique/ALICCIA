
function CambiarEstadoDebate(id) {
         $.post("datos/cambiarEstadoDebate.php", {
                id: id
            },
            function (data, status) {
                refresh();
            }
        );
}

function CambiarEstadoFaseDebate(id) {
         $.post("datos/cambiarEstadoFaseDebate.php", {
                id: id
            },
            function (data, status) {
                refresh();
            }
        );
}

function CambiarTipoDebate(id) {
         $.post("datos/cambiarTipoDebate.php", {
                id: id
            },
            function (data, status) {
                refresh();
            }
        );
}

function AvanzarGEN(id) {
         $.post("datos/cambiarGenDebate+.php", {
                id: id
            },
            function (data, status) {
                refresh();
            }
        );
}

function RetrasarGEN(id) {
         $.post("datos/cambiarGenDebate-.php", {
                id: id
            },
            function (data, status) {
                refresh();
            }
        );
}

function InsertPropuestaFac() {
    var texto = $("#texto").val();
    var debate = $("#idD").val(); 
    var generacion = $("#idGen").val(); 
    var hija_de = $("#propuesta").val(); 

    $.post("datos/insertarParticipacionFac.php", {
        texto: texto,
        debate: debate,
        hija_de: hija_de,
        generacion: generacion

    }, function (data, status) {
        $("#add_new_record_modal").modal("hide");
        $("#texto").val("");
        $("#idD").val("");
        $("#idGen").val("");
        $("#propuesta").val("");
        window.alert("INSERTADA");

    });
    refresh(); 
}

function refresh()
{
    location.reload(true);
}

$(document).ready(function () {

});