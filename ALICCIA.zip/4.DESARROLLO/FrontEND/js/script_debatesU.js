 
// READ records
function SelectDebatesA() {
    $.get("datos/listarDebatesA.php", {}, function (data, status) {
        $(".records_content_da").html(data);
    });
}

function SelectDebatesR() {
    $.get("datos/listarDebatesR.php", {}, function (data, status) {
        $(".records_content_dr").html(data);
    });
}
 
function DetallesDebateA(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_debate_id").val(id);
    $.post("datos/leerDebateU.php", {
            id: id
        },
        function (data, status) {
            // PARSE json data
            var user = JSON.parse(data);
            // Assing existing values to the modal popup fields
            $("#update_nombre").val(user.nombre);
            $("#update_texto").val(user.texto_inicial);
            $("#update_tipo").val(user.tipo_debate);
            $("#update_fac").val(user.fac);
        }
    );
    $("#update_debate_modal").modal("show");
}

function DetallesDebateR(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_debate_idR").val(id);
    $.post("datos/leerDebateU.php", {
            id: id
        },
        function (data, status) {
            // PARSE json data
            var user = JSON.parse(data);
            // Assing existing values to the modal popup fields
            $("#update_nombreR").val(user.nombre);
            $("#update_resumenR").val(user.resumen);
            $("#update_textoR").val(user.texto_inicial);
            $("#update_tipoR").val(user.tipo_debate);
            $("#update_estadoR").val(user.estado);
        }
    );
    $("#update_debate_modalR").modal("show");
}

function DesarrolloDebateA(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_debate_id2").val(id);
    $.post("datos/leerDesarrolloU.php", {
            id: id
        },
        function (data, status) {
       $(".arbol_gojs").html(data);
        }
    );
    $("#arbol_modal").modal("show");
}





function refresh()
{
    location.reload(true);
}


$(document).ready(function () {
    SelectDebatesA(); 
    SelectDebatesR(); 
});