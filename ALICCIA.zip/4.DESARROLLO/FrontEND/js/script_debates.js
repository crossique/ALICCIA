// Add Record
function InsertDebate() {
    // get values
    var nombre = $("#nombre").val();
    var resumen = $("#resumen").val();
    var texto = $("#texto").val();
    var filtro = $("#filtro").val();
    var tipo = $("#tipo").val();
    var estado = $("#estado").val();

    $.post("datos/insertarDebate.php", {
        nombre: nombre,
        resumen: resumen,
        texto: texto,
        filtro: filtro,
        tipo: tipo,
        estado: estado

    }, function (data, status) {
        // close the popup
        $("#add_new_record_modal").modal("hide");
        // read records again
        SelectDebates();
 
        // clear fields from the popup
        $("#nombre").val("");
        $("#resumen").val("");
        $("#texto").val("");
        $("#filtro").val("");
        $("#tipo").val("");          
        $("#estado").val("");
    });
}
 
// READ records
function SelectDebates() {
    $.get("datos/listarDebates.php", {}, function (data, status) {
        $(".records_content_d").html(data);
    });
}

function DetallesDebate(id) {
    // Add User ID to the hidden field for future usage
    $("#hidden_debate_id").val(id);
    $.post("datos/leerDebate.php", {
            id: id
        },
        function (data, status) {
            // PARSE json data
            var user = JSON.parse(data);
            // Assing existing values to the modal popup fields
            $("#update_nombre").val(user.nombre);
            $("#update_resumen").val(user.resumen);
            $("#update_texto").val(user.texto_inicial);
            $("#update_tipo").val(user.tipo_debate);
            $("#update_estado").val(user.estado);
        }
    );
    // Open modal popup
    $("#update_debate_modal").modal("show");
}

function UpdateDebate() {
    // get values
    var nombre = $("#update_nombre").val();
    var resumen = $("#update_resumen").val();
    var texto = $("#update_texto").val();
    var tipo = $("#update_tipo").val();
    var estado = $("#update_estado").val();

    // get hidden field value
    var id = $("#hidden_debate_id").val();

    // Update the details by requesting to the server using ajax
    $.post("datos/actualizarDebate.php", {
            id: id,
            nombre: nombre,
            resumen: resumen,
            texto: texto,
            tipo: tipo,
            estado: estado
        },
        function (data, status) {
            // hide modal popup
            $("#update_debate_modal").modal("hide");
            $('.modal-backdrop').remove();
            // reload Users by using readRecords();
            window.alert("ACTUALIZADO");
            SelectDebates();
        }
    );
}
 
function DeleteDebate(id) {
    var conf = confirm("¿Quiere realmente borrar el debate? (Tenga en cuenta que solo se efectuará el borrado si está en estado 1P ó 5C, pero afectará a todos los datos dependientes)");
    if (conf == true) {
         $.post("datos/borrarDebate.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                SelectDebates();
            }
        );
    }else{alert("Borrado no confirmado");}
}

function redir(url){window.location=url;}
 
$(document).ready(function () {
    // READ recods on page load
    SelectDebates(); // calling function
});