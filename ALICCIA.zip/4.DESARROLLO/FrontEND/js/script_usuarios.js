// Add Record
function InsertUser() {
    // get values
    var nombre = $("#nombre").val();
    var apellidos = $("#apellidos").val();
    var email = $("#email").val();
    var tipo = $("#tipo").val();
    var comm = $("#comm").val();
    var pass = $("#pass").val();
    var pass2 = $("#pass2").val(); 
 
    // Add record
    $.post("datos/insertarUsuario.php", {
        nombre: nombre,
        apellidos: apellidos,
        email: email,
        tipo: tipo,
        comm: comm,
        pass: pass,
        pass2: pass2

    }, function (data, status) {
        // cierra el popup
        $("#add_new_record_modal").modal("hide");
 
        // read records again
        SelectUsers();
 
        // limpiar campos del popup
        $("#nombre").val("");
        $("#apellidos").val("");
        $("#email").val("");
        $("#comm").val("");
        $("#pass").val("");
        $("#pass2").val("");
    });
}
 
// READ records
function SelectUsers() {
    var filtro = $("#filtro").val();
    $.post("datos/listarUsuarios.php", {filtro: filtro}, function (data, status) {
        $(".records_content").html(data);
    });
}
 
function DetailsUser(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_user_id").val(id);
    $.post("datos/leerUsuario.php", {
            id: id
        },
        function (data, status) {
            // PARSE json data
            var user = JSON.parse(data);
            // Assing existing values to the modal popup fields
            $("#update_nombre").val(user.nombre);
            $("#update_apellidos").val(user.apellidos);
            $("#update_email").val(user.email);
            $("#update_pass").val();
            $("#update_comm").val(user.comentario);
            $("#update_tipo").val(user.tipo_usuario);
            $("#update_estado").val(user.estado);
        }
    );
    // Open modal popup
    $("#update_user_modal").modal("show");
}

function ValidateUser(id) {
    var conf = confirm("¿Quiere realmente validar/invalidar el usuario?");
    alert(id);
    idn=parseInt(id);
    alert(idn);
    if (conf == true) {
         $.post("datos/validarUsuario.php", {
                id: idn
            },
            function (data, status) {
                // reload Users by using readRecords();
                SelectUsers();
            }
        );
    }else{alert("Validación no confirmada");}
}

function UpdateUser() {
    // get values
    var nombre = $("#update_nombre").val();
    var apellidos = $("#update_apellidos").val();
    var email = $("#update_email").val();
    var pass = $("#update_pass").val();
    var comm = $("#update_comm").val();
    var tipo = $("#update_tipo").val();
    var estado = $("#update_estado").val();

    // get hidden field value
    var id = $("#hidden_user_id").val();

    // Update the details by requesting to the server using ajax
    $.post("datos/actualizarUsuario.php", {
            id: id,
            nombre: nombre,
            apellidos: apellidos,
            email: email,
            pass: pass,
            comm: comm,
            tipo: tipo,
            estado: estado
        },
        function (data, status) {
            // hide modal popup
            $("#update_user_modal").modal("hide");
            $('.modal-backdrop').remove();
            // reload Users by using readRecords();
            window.alert("ACTUALIZADO");
            SelectUsers();
        }
    );
}

function DeleteUser(id) {
    window.alert("Se le pedirá confirmación");
    var conf = confirm("¿Quiere realmente borrar el usuario?");
    if (conf == true) {
         $.post("datos/borrarUsuario.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                SelectUsers();
            }
        );
    }else{alert("Borrado no confirmado");}
}
 
$(document).ready(function () {
    // READ recods on page load
    SelectUsers(); // calling function
});