<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
     	<script src="js/script_usuarios_gd.js"></script>
	</head>
	<body>
	   	<?php include 'base/cabecera.php';?>
	   	<?php include 'base/control_sesion_fac.php';?>

	   	<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->
	<div class="container-fluid px-5">
		<div class="row pt-3">
			<div class="col-md-12">
			<h5><i class="fas fa-user-friends color:#0077AA"></i> <i class="fas fa-comments color:#0077AA"></i> Gestión de grupos de debate </h5>
			</div>
		</div>
		<div class="container-fluid">
		    <div class="btn-group">   
		      <a type="button" class="btn btn-success btn-sm text-white" data-target="#add_new_group_modal" data-toggle="modal"><i class='fas fa-share'></i> Añadir Grupo Manualmente </a>
		    </div>
		    <br>
		</div>
		<div class="row pt-2">
			<div class="col-md-12">
			<div class="records_content_gd"></div>
			</div>
		</div>
	</div>
	<hr>

	<div class="container-fluid px-5">
		<div class="row pt-3">
			<div class="col-md-12">
			<h5><i class="fas fa-user-friends color:#0077AA"></i> <i class="fas fa-comments color:#0077AA"></i> Gestión de debatientes </h5>
			</div>
		</div>
		<div class="container-fluid">
		    <form>

		    <div class="btn-group">   
		      <select name="filtro" id="filtro" style="width: 220px" class="w66 form-control border border-info rounded input-lg" value=7>
		      <!--leer los grupos actuales del facilitador en BD -->
		      <?php include("conexion.php");          
		      $query = "SELECT * FROM T_GRUPOS_DEBATE WHERE id_fac=".$_SESSION['id'];
		      if (!$result = mysqli_query($con, $query)) {exit(mysqli_error($con));}
		      if(mysqli_num_rows($result) > 0)
		      {while($row = mysqli_fetch_array($result))
		        {echo '<option value ='.$row["id_grupo_debate"].'>'.$row["nombre_gd"].'</option>';}}?>
			  <!-- fin codigo php -->
		      </select>
		    </div>
		    <div class="btn-group">   
		      <a type="button" class="btn btn-info btn-sm text-white" onclick="SelectUsersGD()"> <i class='fas fa-filter'></i> Filtrar </a>
		    </div>		    
		    <div class="btn-group">   
		      <a type="button" class="btn btn-success btn-sm text-white" data-target="#add_new_user-group_modal" data-toggle="modal"><i class='fas fa-share'></i> Añadir Usuario a Grupo </a>
		    </div>
		    </form>
		    <div class="row pt-2">
				<div class="col-md-12">
					<div class="records_content_ud"></div>
				</div>
			</div>			
		</div>
	</div>

	<!-- Inserciones Modales -->
	<div class="modal fade" id="add_new_group_modal" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
					<h4 class="modal-title" id="myModalLabel">Añadir Grupo de Debate</h4>
				</div>
				<div class="modal-body">
				 <div class="form-group">
			      Nombre: <input type="text" class="form-control" id="nombre_gd">
			     </div>
				</div>	
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-success" onclick="InsertGD()"><span class="fas fa-share"></span> Insertar</button>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="add_new_user-group_modal" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
					<h4 class="modal-title" id="myModalLabel">Añadir Usuario a grupo</h4>
				</div>
				<div class="modal-body">
				 <form>	
				 <div class="form-group">
			      Facilitador: <input type="text" class="form-control" id="id_fac" value=<?php echo $_SESSION['id'];?> readonly="readonly">
			     </div>						
				 <div class="form-group">
			      Email: (tiene que ser un usuario de la BD)<input type="email" class="form-control" id="emailUGD" name ="emailUGD" placeholder="email">
			     </div>
				 <div class="form-group">
			      <select name="filtroGD" id="filtroGD" style="width: 220px" class="w66 form-control border border-info rounded input-lg">
				      <!--leer los grupos actuales del facilitador en BD -->
				      <?php include("conexion.php");          
				      $query = "SELECT * FROM T_GRUPOS_DEBATE WHERE id_fac=".$_SESSION['id'];
				      if (!$result = mysqli_query($con, $query)) {exit(mysqli_error($con));}
				      if(mysqli_num_rows($result) > 0)
				      {while($row = mysqli_fetch_array($result))
				        {echo '<option value ='.$row["id_grupo_debate"].'>'.$row["nombre_gd"].'</option>';}}?>
					  <!-- fin codigo php -->
			      </select>
			     </div>
			     </form>			     
				</div>	
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-success" onclick="InsertUserGD()"><span class="fas fa-share"></span> Insertar</button>
				</div>
			</div>
		</div>
	</div>

	</div>
		<!-- FIN CONTENIDO ESPECÍFICO -->
		<?php include 'base/pie.php';?>
		<script>
		$(document).ready(function () {
    	SelectGDs(); // llama a la función para refrescar el listado de usuarios
		});</script>
   </body>
</html>