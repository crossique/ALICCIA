<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
		
	</head>
	<body>
		<?php include 'base/cabecera.php';?>
	   	<?php include 'base/control_sesion_admin.php';?>
	   	<?php include_once 'datos/conexion.php';?>

	   	<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->

		<?php $dir="img/custom/";?>

<div class="container_fluid px-4">
	    <div class="panel-dialog" role="document">
	        <div class="panel-content">
	            <div class="panel-header pt-3">
	                <h5><b><p>PARAMETRIZACIÓN DEL SITIO WEB</p></b></h5>
		            </div>
		            <div class="panel-body">
						<hr/>	
						<form enctype="multipart/form-data" method="POST">
						<b>IMAGEN DEL LOGO &nbsp </b>
						<input name="uploadedfile2" type="file" />
						<input type="submit" value="Enviar Logo" id="subirL" name="subirL"/>
						<small>  (tipo png, aspect ratio 1:1, recomendado 300x300, máximo 300KB)</small>
						</form>
						<hr/>
						<form method="POST">
						<b>TEXTO DE TÍTULO &nbsp &nbsp </b>
						<input name="titul" type="text" size="75" maxlength="60" />
						<input type="submit" value="Enviar Titulo" id="subirT" name="subirT"/>
						<small>  (máximo 60 caracteres)</small>
						</form>	
						<hr/>
						<form method="POST">
						<b>COLOR de Cabecera/Pie &nbsp &nbsp </b>
						<input name="color" value="#0275d8" type="color"/>
						<input type="submit" value="Enviar Color" id="subirC" name="subirC"/>
						<small>  (el texto es en blanco por lo que es recomendable elegir un color oscuro de fondo)</small>
						</form>	
						<hr/>
						<form method="POST">
						<b>COLOR de Fondo de página &nbsp &nbsp </b>
						<input name="colorB" value="#f3f3ff" type="color"/>
						<input type="submit" value="Enviar Color" id="subirCB" name="subirCB"/>
						<small>  (el texto es en negro por lo que es recomendable elegir un color muy claro de fondo)</small>
						</form>	
						<hr/>						
						<form method="POST">
						<b>TEXTO EXPLICATIVO &nbsp </b>
						<input name="expl" type="text" size="75" maxlength="600"/>
						<input type="submit" value="Enviar Explicación" id="subirE" name="subirE"/>
						<small>  (máximo 600 caracteres)</small>
						</form>	
						<hr/>						
						<form enctype="multipart/form-data" method="POST">
						<b>IMAGEN PORTADA &nbsp</b>
						<input name="uploadedfile" type="file" />
						<input type="submit" value="Enviar Portada" id="subirP" name="subirP"/>
						<small>  (tipo jpg, aspect ratio 20:7, recomendado 2000x700, máximo 1MB)</small>
						</form>
						<hr/>
						<form method="POST">
						<b>FUNCIONALIDADES &nbsp</b>
						<input type= "checkbox" id="votaciones" name="votaciones" value="on" checked/> Votaciones &nbsp &nbsp
						<input type= "checkbox" id="encuestas"name="encuestas" value="on" checked/> Encuestas &nbsp &nbsp 
						<input type= "checkbox" id="debates" name="debates" value="on" checked/> Debates &nbsp &nbsp 
						<input type= "checkbox" id="documentos" name="documentos" value="on" checked/> Incluir Documentos PFG &nbsp &nbsp 
						<input type="submit" value="Enviar Funcionalidades" id="subirF" name="subirF"/>
						<small> </small>
						</form>
						<hr/>

						<small>(NOTA: Los cambios pueden requerir un refresco de pantalla con CTRL+F5)</small>						
							
					</div>
	            </div>
	            <div class="panel-footer">
	            </div>
	    </div>
</div>

<?php
$uploadedfileload="true";

if(isset($_POST['subirP'])){
$uploadedfile_size=$_FILES['uploadedfile']['size'];
if ($_FILES['uploadedfile']['size']>1000000){$uploadedfileload="false";}
if (!($_FILES['uploadedfile']['type'] =="image/jpeg")){$uploadedfileload="false";}
$file_name="portada.jpg";

if(($uploadedfileload=="true")&&(strlen($dir)>0)){     
    //comprobamos si el archivo ha subido
    if ($file_name && move_uploaded_file($_FILES['uploadedfile']['tmp_name'],$dir.$file_name))
    {
	echo "<script type='text/javascript'> alert('Imagen subida');</script>";
    }
    else{echo "Error al subir el archivo";}
}else{echo" <script type='text/javascript'> alert('Imagen inválida (Por tamaño, tipo o inexistente)');</script>";
echo"<script>window.location='index.php'</script>;";}
}

if(isset($_POST['subirL'])){
$uploadedfile_size=$_FILES['uploadedfile2']['size'];
if ($_FILES['uploadedfile2']['size']>300000){$uploadedfileload="false";}
if (!($_FILES['uploadedfile2']['type'] =="image/png")){$uploadedfileload="false";}
$file_name="Logo.png";

if(($uploadedfileload=="true")&&(strlen($dir)>0)){     
    //comprobamos si el archivo ha subido
    if ($file_name && move_uploaded_file($_FILES['uploadedfile2']['tmp_name'],$dir.$file_name))
    {
	echo "<script type='text/javascript'> alert('Logo subido');</script>";
    }
    else{echo "Error al subir el archivo";}
}else{echo" <script type='text/javascript'> alert('Imagen inválida (Por tamaño, tipo o inexistente)');</script>";
echo"<script>window.location='index.php'</script>;";}
}

if(isset($_POST['subirT'])){
$tit=$_POST['titul'];
$query = "UPDATE T_CONFIG SET titulo ='$tit' WHERE ROWID=1";
 if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
echo "<script type='text/javascript'> alert('Texto subido');</script>";
}

if(isset($_POST['subirC'])){
$col=$_POST['color'];
$query = "UPDATE T_CONFIG SET fondo ='$col' WHERE ROWID=1";
 if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
echo "<script type='text/javascript'> alert('Color cambiado');</script>";
}

if(isset($_POST['subirCB'])){
$colB=$_POST['colorB'];
$query = "UPDATE T_CONFIG SET fondoB ='$colB' WHERE ROWID=1";
 if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
echo "<script type='text/javascript'> alert('Color cambiado');</script>";
}

if(isset($_POST['subirE'])){
$exp=$_POST['expl'];
$query = "UPDATE T_CONFIG SET explicacion ='$exp' WHERE ROWID=1";
 if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
echo "<script type='text/javascript'> alert('Texto subido');</script>";
}

if(isset($_POST['subirF'])){

	if(isset($_POST['votaciones'])){$vot=1;}else{$vot=0;}
	if(isset($_POST['encuestas'])){$enc=1;}else{$enc=0;}
	if(isset($_POST['debates'])){$deb=1;}else{$deb=0;}
	if(isset($_POST['documentos'])){$doc=1;}else{$doc=0;}

$query = "UPDATE T_CONFIG SET votaciones =$vot, encuestas =$enc, debates =$deb, documentos =$doc WHERE ROWID=1";
 if (!$result = mysqli_query($con, $query)) {exit(mysqli_error($con));}
echo "<script type='text/javascript'> alert('Funcionalidades actualizadas');</script>";
}

?>
   </body>
</html>