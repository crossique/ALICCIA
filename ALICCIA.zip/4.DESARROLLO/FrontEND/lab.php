<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
	</head>
	<body>
	   	<?php include 'base/cabecera.php';?>

	   	<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->
   	
    <div class="container-fluid px-5 pt-2">

	    <div class="row pt-12">
			<h4 class= "px-2 pt-2">LABORATORIO</h4>
		</div>
		<div class="row pt-12">
	    	<img src="img/general/lab.png" class="alinea" height="200px" width="500px" style="display: inline-block">	
		</div>
		<br>
		<br>
		<div class="col-md-12 text-justify pt-1 pt-12">
			<p>En las páginas que aquí se enlazan pueden experimentarse en la práctica algunos de los fundamentos teóricos y metodologías propuestas en este TFM</p>
		</div>
		
		<hr/>
		<div class="row px-2 pb-1">
			<div class="col-md-12 col-sm-12 text-justify">
				<ul>
					<li class="list-item py-1">
						<b><a href="lab_pareto.php">Experimentación con el Frente de Pareto</a></b>
					</li>
					<li class="list-item py-1">
						<b><a href="lab_algebra.php">Experimentación con el álgebra de propuestas y los LLM</a></b>
					</li>
				</ul>
			</div>
	
		</div>
		<div class="row px-2 pb-2">
		</div>
	</div>

		<!-- FIN CONTENIDO ESPECÍFICO -->

		<?php include 'base/pie.php';?>
   </body>
</html>