<?php
// lab_planificador.php – basado en lab_pareto.php :contentReference[oaicite:10]{index=10}
include 'base/head.php';
include 'base/cabecera.php';

$error = $description = $graph = null;
$top10  = [];

// Procesar POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1) Recoger apoyos/rechazos
    $props = ['Prop1','Prop2','Prop3','Prop4'];
    $datos = [];
    foreach ($props as $p) {
        $datos[$p] = $_POST[$p] ?? [];
    }
    // 2) Recoger cercanías
    $pairs = ['12','13','14','23','24','34'];
    $closeness = [];
    foreach ($pairs as $k) {
        $closeness[$k] = isset($_POST["c{$k}"]) ? floatval($_POST["c{$k}"]) : 0.5;
    }
    // 3) Llamar a planificador.py vía base64 (como en pareto) :contentReference[oaicite:11]{index=11}
    $input = base64_encode(json_encode([
        'data'      => $datos,
        'closeness' => $closeness
    ]));
    $python = '/usr/bin/python3';
    $script = __DIR__ . '/py/planificador.py';
    $cmd = escapeshellarg($python) . ' ' . escapeshellarg($script)
         . ' ' . escapeshellarg($input) . ' 2>&1';
    $out = shell_exec($cmd);
    if ($out && ($res = json_decode($out, true))) {
        $description = $res['description'] ?? '';
        $graph       = $res['graph']       ?? '';
        $top10       = $res['top10']       ?? [];
    } else {
        $error = "Error al ejecutar planificador.py:<br><pre>"
               . htmlspecialchars($cmd . "\n" . $out) . "</pre>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <?php include 'base/head.php'; ?>
    <style>
    /* Grid 2×2 mobile, 4×1 desktop, igual que lab_pareto.php :contentReference[oaicite:12]{index=12} */
    .propuesta-grid {
        display: grid;
        grid-template-columns: repeat(2,1fr);
        gap:1rem;
    }
    @media (min-width:992px) {
        .propuesta-grid { grid-template-columns: repeat(4,1fr); }
    }
    /* Cajas y badges idénticos a lab_pareto.php :contentReference[oaicite:13]{index=13} */
    .proposal-box {
        min-height:90px;
        border:2px dashed #ced4da;
        border-radius:.5rem;
        padding:.4rem;
        background:#f8f9fa;
    }
    .proposal-box.drag-over { background:#e2e6ea; }
    .user-badge    { cursor:move; font-size:1.15rem; color:green; }
    .reject-badge  { cursor:move; font-size:1.15rem; color:red;   }
    .support-badge { cursor:pointer; font-size:1.25rem; color:green; }
    .rejection-badge { cursor:pointer; font-size:1.25rem; color:red; }

    /* Container con imagen de fondo y posicionamiento de inputs */
    .container {
        position: relative;
        width: 300px;
        height: 300px;
        background: url('img/general/P4.jpg') no-repeat center/cover;
        border: 1px solid #333;
    }
    .container input {
        position: absolute;
        width: 75px;
        font-size: 12px;
        text-align: center;
        z-index: 1;
    }
    /* Posiciones originales de inputs de cercanía */
    #c12 { top: 22px; left: 50%; transform: translateX(-50%); }
    #c34 { bottom: 20px; left: 50%; transform: translateX(-50%); }
    #c13 { left: 16px; top: 48%; transform: translateY(-50%); }
    #c24 { right: 16px; top: 48%; transform: translateY(-50%); }
    #c14 { top: 38%; left: 50%; transform: translate(-50%, -50%); }
    #c23 { top: 60%; left: 50%; transform: translate(-50%, -50%); }
    </style>
</head>
<body>
<?php include 'base/cabecera.php'; ?>

<div class="container-fluid px-5 pt-2">
	<div class="row pt-12">
			<h4 class= "px-2 pt-2">Lab: PLANIFICADOR HACIA EL CONSENSO</h4>
		</div>
		<div class="row pt-12">
			<p class= "px-2 pt-2">En este laboratorio se puede experimentar con la planificación a partir de una serie de apoyos y rechazos de los participantes de un debate a una serie de propuestas (4) y unas medidas de cercanía. 'Validar' nos puede indicar algun usuario faltante, una propuesta no apoyada o incluso alguna serie de distancias poco consistentes. El botón principal lanzará un planificador que evaluará, segun los datos anteriores el camino 'naive' menos costoso hacia el consenso.<br><p>
		</div>
  <?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <form method="post" id="plannerForm">
    <!-- 4 cajas de propuestas con Drag & Drop íntegro de lab_pareto.php -->
    <div class="propuesta-grid my-3">
      <?php foreach (['Prop1','Prop2','Prop3','Prop4'] as $p): ?>
        <div>
          <h5 class="text-center mb-1"><?= $p ?></h5>
          <div class="proposal-box" data-propuesta="<?= $p ?>">
            <?php
            if ($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST[$p])) {
                foreach ($_POST[$p] as $u) {
                    $isReject = strpos($u,'R')===0;
                    $badgeClass = $isReject
                        ? 'text-bg-danger rejection-badge'
                        : 'text-bg-success support-badge';
                    echo "<span class='badge rounded-pill {$badgeClass} me-1 mb-1'
                              data-user='{$u}' data-type='"
                              . ($isReject ? 'reject' : 'support') . "'>
                              {$u} ×
                          </span>";
                    echo "<input type='hidden' name='{$p}[]' value='{$u}'>";
                }
            }
            ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Paletas de Apoyos y Rechazos de lab_pareto.php :contentReference[oaicite:14]{index=14} -->
    <div class="text-center mt-4">
      <h5>Apoyos de usuarios</h5>
      <div id="userPalette" class="d-flex flex-wrap gap-2 justify-content-center fs-5">
        <?php foreach (['U1','U2','U3','U4','U5','U6','U7','U8','U9','U10','U11','U12'] as $u): ?>
          <span class="badge rounded-pill text-bg-primary user-badge"
                draggable="true" data-user="<?= $u ?>" data-type="support">
            <?= $u ?>
          </span>
        <?php endforeach; ?>
      </div>
      <p class="mt-2 text-muted">Arrastra estos apoyos a las propuestas.</p>

      <h5 class="mt-4">Rechazos de usuarios</h5>
      <div id="rejectPalette" class="d-flex flex-wrap gap-2 justify-content-center fs-5">
        <?php foreach (['R1','R2','R3','R4','R5','R6','R7','R8','R9','R10','R11','R12'] as $r): ?>
          <span class="badge rounded-pill text-bg-danger reject-badge"
                draggable="true" data-user="<?= $r ?>" data-type="reject">
            <?= $r ?>
          </span>
        <?php endforeach; ?>
      </div>
      <p class="mt-2 text-muted">Arrastra estos rechazos a las propuestas.</p>
    

    <!-- Inputs de cercanía posicionados sobre container -->
    <h5 class="mt-4">Medidas de cercanía semántica entre propuestas</h5>
    <div class="container mt-3">
      <input id="c12" type="number" name="c12" class="form-control" step="0.01" min="0" max="1"
             value="<?= $_POST['c12'] ?? '0.5' ?>">
      <input id="c34" type="number" name="c34" class="form-control" step="0.01" min="0" max="1"
             value="<?= $_POST['c34'] ?? '0.5' ?>">
      <input id="c13" type="number" name="c13" class="form-control" step="0.01" min="0" max="1"
             value="<?= $_POST['c13'] ?? '0.5' ?>">
      <input id="c24" type="number" name="c24" class="form-control" step="0.01" min="0" max="1"
             value="<?= $_POST['c24'] ?? '0.5' ?>">
      <input id="c14" type="number" name="c14" class="form-control" step="0.01" min="0" max="1"
             value="<?= $_POST['c14'] ?? '0.5' ?>">
      <input id="c23" type="number" name="c23" class="form-control" step="0.01" min="0" max="1"
             value="<?= $_POST['c23'] ?? '0.5' ?>">
    </div>
</div>
    <!-- Botones Validar + Planificar -->
    <div class="row mt-4">
      <div class="col">
        <button type="button" class="btn btn-secondary me-2" onclick="validateForm()">Validar</button>
        <button type="submit" class="btn btn-primary">Encontrar una ruta hacia el consenso</button>
      </div>
    </div>
  </form>

  <!-- Ventana Modal de Validación (Bootstrap 4) -->
  <div class="modal fade" id="validationModal" tabindex="-1" role="dialog"
       aria-labelledby="validationModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="validationModalLabel">Resultados de validación</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <ul id="validationMessages" class="list-group"></ul>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>

  <?php if ($description): ?>
    <hr class="my-4">
    <h4>Resultado</h4>
    <p><?= $description ?></p>
    <strong>Grafo de la mejor ruta</strong><br><br>
    <img src="data:image/png;base64,<?= $graph ?>" class="img-fluid border" alt="Grafo">
    <br><br>
	<strong>Tipos de rutas:</strong><br><br>
	<img src="img/general/plan.jpg" alt="portada" height="125" width="600">
	<br><br>
    <strong>Top 10 rutas:</strong><br><br>
    <?= empty($top10)
         ? 'Ninguna'
         : nl2br(htmlspecialchars(implode("\n", $top10))) ?>
  <?php endif; ?>
</div>

<script src="base/dragdrop.js"></script>
<script>
// Validaciones avanzadas
function validateForm() {
  var msgs = [];
  
  // A) Propuestas sin apoyos
  ['Prop1','Prop2','Prop3','Prop4'].forEach(function(p) {
    if (document.querySelectorAll('input[name="'+p+'[]"]').length === 0) {
      msgs.push(p + ' sin apoyos/rechazos.');
    }
  });
  // B) Cada usuario debe apoyar al menos una propuesta
  for (var i = 1; i <= 12; i++) {
    if (document.querySelectorAll('input[value="U'+i+'"]').length === 0) {
      msgs.push('Usuario U'+i+' no apoya ninguna propuesta.');
    }
  }
  // C) Dominancias entre propuestas 
  var supports = {};
  ['Prop1','Prop2','Prop3','Prop4'].forEach(function(p) {
    supports[p] = Array.from(document.querySelectorAll('input[name="'+p+'[]"]'))
                        .map(i => i.value).filter(v => v.startsWith('U'));
  });
  var props = Object.keys(supports);
  for (var a = 0; a < props.length; a++) {
    for (var b = 0; b < props.length; b++) {
      if (a !== b) {
        var A = supports[props[a]], B = supports[props[b]];
        if (A.length > 0 && A.every(u => B.includes(u))) {
          msgs.push('Todos los apoyos de '+props[a]+' también apoyan '+props[b]+'.');
        }
      }
    }
  }
  // D) Atajos: comprobar desigualdad triangular en distancias = 1 - closeness
  var cl = {};
  ['12','13','14','23','24','34'].forEach(function(k){
    cl[k] = parseFloat(document.getElementById('c'+k).value);
  });
  function dist(i,j){
    var key = ''+(i<j? i+''+j: j+''+i);
    return (1-cl[key]);
  }
  var n = 4;
  for (var i = 1; i <= n; i++) {
    for (var j = 1; j <= n; j++) {
      for (var k = 1; k <= n; k++) {
        if (i!=j && j!=k && i<k) {
          if (dist(i,k) > dist(i,j) + dist(j,k) + 1e-6) {
            msgs.push('Atajo detectado: d(P'+i+',P'+k+') > d(P'+i+',P'+j+') + d(P'+j+',P'+k+').');
          }
        }
      }
    }
  }
  // Mostrar
  var ul = document.getElementById('validationMessages');
  ul.innerHTML = '';
  if (msgs.length === 0) {
    ul.innerHTML = '<li class="list-group-item text-success">¡Todo correcto!</li>';
  } else {
    msgs.forEach(function(m){
      var li = document.createElement('li');
      li.className = 'list-group-item text-warning';
      li.textContent = m;
      ul.appendChild(li);
    });
  }
  $('#validationModal').modal('show');
}
</script>
<script>
(() => {
  // Drag & Drop de lab_pareto.php :contentReference[oaicite:15]{index=15}
  function attachDelete(span) {
    span.addEventListener('click', () => {
      const next = span.nextElementSibling;
      if (next && next.tagName === 'INPUT') next.remove();
      span.remove();
    });
  }
  document.querySelectorAll('.user-badge, .reject-badge').forEach(badge =>
    badge.addEventListener('dragstart', e => {
      e.dataTransfer.setData('text/plain', badge.dataset.user);
      e.dataTransfer.setData('text/type', badge.dataset.type);
    })
  );
  function getUserNumber(user) { return user.substring(1); }
  function removeExistingUserBadge(box, userNumber) {
    box.querySelectorAll('[data-user]').forEach(badge => {
      if (getUserNumber(badge.dataset.user) === userNumber) {
        const next = badge.nextElementSibling;
        if (next && next.tagName==='INPUT') next.remove();
        badge.remove();
      }
    });
  }
  function addSupport(box, user) {
    const num = getUserNumber(user);
    removeExistingUserBadge(box, num);
    const span = document.createElement('span');
    span.className = 'badge rounded-pill text-bg-success me-1 mb-1 support-badge';
    span.dataset.user = user; span.dataset.type = 'support';
    span.textContent = user + ' ×'; attachDelete(span);
    const input = document.createElement('input');
    input.type='hidden'; input.name=box.dataset.propuesta+'[]'; input.value=user;
    box.append(span, input);
  }
  function addReject(box, user) {
    const num = getUserNumber(user);
    removeExistingUserBadge(box, num);
    const span = document.createElement('span');
    span.className = 'badge rounded-pill text-bg-danger me-1 mb-1 rejection-badge';
    span.dataset.user = user; span.dataset.type = 'reject';
    span.textContent = user + ' ×'; attachDelete(span);
    const input = document.createElement('input');
    input.type='hidden'; input.name=box.dataset.propuesta+'[]'; input.value=user;
    box.append(span, input);
  }
  document.querySelectorAll('.proposal-box').forEach(box => {
    box.addEventListener('dragover', e => { e.preventDefault(); box.classList.add('drag-over'); });
    box.addEventListener('dragleave',  () => box.classList.remove('drag-over'));
    box.addEventListener('drop',       e => {
      e.preventDefault(); box.classList.remove('drag-over');
      const user = e.dataTransfer.getData('text/plain');
      const type = e.dataTransfer.getData('text/type');
      if (type==='support') addSupport(box, user);
      else if (type==='reject') addReject(box, user);
    });
  });
  document.querySelectorAll('.support-badge, .rejection-badge').forEach(attachDelete);
})();
</script>

<?php include 'base/pie.php'; ?>
