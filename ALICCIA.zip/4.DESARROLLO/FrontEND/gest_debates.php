<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
     	<script src="js/script_debates.js"></script>
	</head>
	<body>
	   	<?php include 'base/cabecera.php';?>
	   	<?php include 'base/control_sesion_fac.php';?>

	<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->
	
	<div class="container-fluid px-5">
		<div class="row pt-3">
			<div class="col-md-12">
			<h5><i class="fas fa-comments color:#0077AA"></i> Gestión de <?php if(isset($_SESSION['email'])){if($_SESSION['tipo']==0){echo'todos los';}}?> <?php if(isset($_SESSION['email'])){if(($_SESSION['tipo']<4)&&($_SESSION['tipo']>0)){echo'mis';}}?> debates</h5>
			</div>
		</div>
		<div class="row pt-2">
			<div class="col-md-12">
			<div class="records_content_d"></div>
			</div>
		</div>
	</div>	
	<!-- Modal Inserción Debate -->
	<div class="modal fade" id="add_new_record_modal" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Añadir Debate</h4>
					</div>
				<div class="modal-body">

				<div class="form-group">
			      Nombre: <input type="text" class="form-control" id="nombre">
				</div>
			    <div class="form-group">  
			      Resumen:<input type="text" class="form-control" id="resumen">
			    </div>
				<div class="form-group">
			      Pregunta / Texto Inicial: 
			      <textarea rows="8" class="form-control" id="texto"></textarea>
				</div>
				<div class="form-group">
				  <select name="filtro" id="filtro" style="width: 220px" class="w66 form-control border border-info rounded input-lg" value=7>	
			      Grupo de debate:  
			      <?php
			      include("datos/conexion.php");          
			      $query = "SELECT * FROM T_GRUPOS_DEBATE WHERE id_fac=".$_SESSION['id'];
			      if (!$result = mysqli_query($con, $query)) {
			      exit(mysqli_error($con));
			      }
			      // if query results contains rows then featch those rows 
			      if(mysqli_num_rows($result) > 0)
			      {
				  while($row = mysqli_fetch_array($result))
			        {
			        	echo '<option value ='.$row["id_grupo_debate"].'>'.$row["nombre_gd"].'</option>';
			        }	
			      }
			      ?>
			  	  </select>
			  	</div>
                <div class="form-group">	
			      Tipo de debate:                           
                <select name="tipo" class="form-control input-lg" id="tipo">
                <option value='AP'>Tipo Appgree</option>
                <option value='IW'>Tipo IWarsMaps</option>
                <option value='VI'>Tipo Vilfredo</option>
                </select>
                </div>
                <div class="form-group">
                  Estado:
                <select name="estado" class="form-control" id="estado" >
                  <option value="1P">1-En preparación</option>
                  <option value="2L">2-Listo</option>
                  <option value="3A">3-Activo</option>
                  <option value="4F">4-Finalizado</option>
                  <option value="5C">5-Cerrado</option>
                </select>
                </div>
			    </div><!-- fin modal body -->
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-success " onclick="InsertDebate()"><span class="fas fa-share"></span> Insertar</button>
				</div>
			</div>
		</div>
	</div>

	</div>
		<!-- FIN CONTENIDO ESPECÍFICO -->
		<?php include 'base/pie.php';?>
		<script>
		$(document).ready(function () {
    	SelectDebates(); // llama a la función para refrescar el listado de votaciones
		});</script>
   </body>
</html>