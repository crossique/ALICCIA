<?php
// Crear una nueva instancia de imagen
if(!isset($_SESSION)) {session_start();}
$_SESSION['cod_captcha'] = TextoRandom(6);
$im = imagecreatetruecolor(96, 31);
$fondo = imagecolorallocate($im, rand(180,255), rand(200,255), rand(160,255));
imagefilledrectangle($im, 0, 0, 399, 31, $fondo);
putenv('GDFONTPATH=' . realpath('.'));
$fuente = '../fonts/Molot.otf';
$size_fuente = 17;
$angulo = rand(-2,6);
$color = imagecolorallocate($im, rand(0,150), rand(0,140), rand(0,140));
imagettftext($im, $size_fuente, $angulo, 7, 26, $color, $fuente, $_SESSION['cod_captcha']);

$cara = rand(0,1);
if ($cara == 1) {imagefilter($im, IMG_FILTER_NEGATE);}

imagefilter($im, IMG_FILTER_GAUSSIAN_BLUR);
imagefilter($im, IMG_FILTER_MEAN_REMOVAL);



//$cara = rand(0,2);
//if ($cara == 2) {imagefilter($im, IMG_FILTER_EMBOSS,0);}
//else{imagefilter($im, IMG_FILTER_GAUSSIAN_BLUR);
//imagefilter($im, IMG_FILTER_MEAN_REMOVAL);}






// Imprimir la imagen al navegador
header('Content-Type: image/gif');
imagegif($im);
imagedestroy($im);

function TextoRandom($length) { 
    //return substr(str_shuffle("/2346789_ABC?()EF\*GHJKMN@PQRTUWXYZ-#=$"), 0, $length);
    return substr(str_shuffle("123467890"), 0, $length);  
} 
?>