<div class="modal fade" id="AyudaModalUsu" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
      	<h5><i class='fas fa-user'></i> Prontuario sobre índices de TIPOS DE USUARIO</h5>
      </div>
      <div class="modal-body">
        <ul>
        <li>TIPOS DE USUARIO</li>
         <ul> 
            <li>0: ADMINISTRADOR</li>
            <li>2: Facilitador</li>
            <li>7: Participante</li>
            <li>9: Invitado</li>  
		     </ul>
  		
  		<li>REGLA GENERAL:</li>
           	Por defecto un usuario podrá hacer las funciones de los niveles inferiores 
           	(por ejemplo, un administrador (0) también podrá facilitar (2) debates y participar (7) en ellos)
  		</ul>
		


       </ul>
        <hr>
        <h8>Encontrará información sobre tipos de usuario más detallada y extensa en "Docs"</h8>	
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-check-circle"></i> OK</button>
      </div>
    </div>
  </div>
</div>