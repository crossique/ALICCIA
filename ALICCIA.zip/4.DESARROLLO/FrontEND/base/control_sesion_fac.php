<?php
  // Controlo si el usuario ya está logueado en el sistema y si es administrador.
  if(isset($_SESSION['email'])){
  	if($_SESSION['tipo']<=2){
  	}else{
  	header("HTTP/1.1 302 Moved Temporarily");
  	header("Location:prohibido.php");
    }
  }else{
    // Si no está ni logueado lo redirecciono a la página de login.
    header("HTTP/1.1 302 Moved Temporarily");
    header("Location:prohibido.php");
  }
?>