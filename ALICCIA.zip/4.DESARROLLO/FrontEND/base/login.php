
<?php
  session_start();
  if(isset($_SESSION['email'])){
    echo '<br><h3 style="margin-left: 2em"><font face="verdana">   ERROR: Ya hay una sesion iniciada, salga antes de iniciar otra <a href="../alta_login.php"</a>Volver</font></h3>';
  }else{
    // Obtengo los datos cargados en el formulario de login.
    $email = $_POST['emailU'];
    $password = $_POST['passwordU'];
    $password = hash("sha256", $password);
    $tipoU= $_POST['tipoU'];
    $fondo_body=$_SESSION["ColorF"];
    echo '<style> body {background-color:'.$fondo_body.';}</style>';
    include '../datos/conexion.php';
    // Investigar como hacer para evitar inyecciones SQL
$stmt = $con->prepare("SELECT * FROM T_USUARIOS WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$resultado = $stmt->get_result();
    // Verificando si el usuario existe en la base de datos.
    $row = mysqli_fetch_assoc($resultado);
    $p=(string)$row["pass"];
    if ($p==$password){
      // Guardo en la sesión los identificadores y tipología del usuario.
      $_SESSION["email"] = $email;
      $_SESSION["id"] = $row['id']; 
      if ($tipoU>=$row["tipo_usuario"]){
      $_SESSION["tipo"] = $tipoU;
      }else{
      echo "<script>alert('No tiene privilegios para ese rol, se le asigna su rol básico');</script>";
      $_SESSION["tipo"] = $row["tipo_usuario"];  
      }
      $_SESSION["estado"] = $row['estado'];
      $_SESSION["id"] = $row['id']; 
      // Y redirecciono al usuario a la página principal del sitio.
      
      if  (($row['estado_val']==0)&&($row["tipo_usuario"]<9)){
        $_SESSION["tipo"]=9;
        echo '<br><h3 style="margin-left: 2em"><font face="verdana">   '.$email.', BIENVENIDO/A A <a href="../index.php">DEMOCRACIA AVANZADA</a></h3><br><h8 style="margin-left: 2em">(Su usuario aún está pendiente de validación email revise su bandeja de entrada (y spam si no lo encuentra), debería haber un enlace de validación, hasta entonces puede visitar el sitio como usuario invitado)</font></h8>';}

      if  (($row['estado_val']==1)&&($row['estado']==0)&&($row["tipo_usuario"]<9)){
        $_SESSION["tipo"]=9;
        echo '<br><h3 style="margin-left: 2em"><font face="verdana">   '.$email.', BIENVENIDO/A A <a href="../index.php">DEMOCRACIA AVANZADA</a></h3><br><h8 style="margin-left: 2em">(Su usuario aún está pendiente de validación email y/o por el administrador, hasta entonces puede visitar el sitio como usuario invitado)</font></h8>';}

      if  (($row['estado_val']==1)&&($row['estado']==1)){
        echo '<br><h3 style="margin-left: 2em"><font face="verdana">   '.$email.', BIENVENIDO/A DE NUEVO A <a href="../index.php">DEMOCRACIA AVANZADA</a>.</font></h3>';}


    }else{
      echo '<br><h3 style="margin-left: 2em"><font face="verdana"> Usuario o password incorrecto, <a href="../alta_login.php">vuelva a intentarlo</a>.</font></h3>';
    }
  } 
?>