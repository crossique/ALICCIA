<div class="modal fade" id="AyudaModalDeb" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5><i class='fas fa-comments'></i> Prontuario sobre TIPOS DE DEBATES</h5>
      </div>
      <div class="modal-body">
        <ul>
          <li>¿QUIENES PUEDEN DEBATIR? </li>
         <ul> 
            <li>0: (PÚBLICO) Cualquiera puede debatir, con medidas para evitar duplicados</li>
            <li>1: (PRIVADA) Se necesita pertenecer al grupo de debate</li>
         </ul>
         <br/>
         <p>    Un debate consiste en ciclos de varias propuestas/respuestas. <br/>
          </p>
          <hr>
          <li>TIPOS DE DEBATES: </li>  
        <ul>
            <li>AP: Tipo Appgree - Ciclos de respuestas con valoración Sí/No</li>
            <li>IW: Tipo IWarsMaps - Propuestas anónimas - Ciclos de mejora</li>
            <li>VI: Tipo Vilfredo - Propuestas dependientes - Ciclos de mejora y frente de Pareto</li>
        </ul>
        
        <hr>    
        </ul>
        <h8 class ="pl-4">    Encontrará información sobre tipos de debates más detallada y extensa en "Docs"</h8> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-check-circle"></i> OK</button>
      </div>
    </div>
  </div>
</div>