<?php include_once 'datos/conexion.php';
session_start();
$titulo_cab="ALICCIA";
$stmt_tit = $con->prepare("SELECT titulo, fondo, fondoB, votaciones, encuestas, debates, documentos, ayuda, usuario FROM T_CONFIG WHERE ROWID = ?");
$row_id = 1; // Parámetro para la consulta
$stmt_tit->bind_param("i", $row_id); // "i" indica un entero
$stmt_tit->execute();
$result_tit = $stmt_tit->get_result();
$row_tit = $result_tit->fetch_array();
$titulo_cab = $row_tit['titulo'];
$fondo_cab = $row_tit['fondo'];
$fondo_body = $row_tit['fondoB'];
$_SESSION["ColorF"]=$fondo_body;
$deb=$row_tit['debates'];
$doc=$row_tit['documentos'];
$help=$row_tit['ayuda'];
$cuad_user=$row_tit['usuario'];
?>
  <style> body {background-color: <?php echo $fondo_body;?>;}</style>

<div class="container-fluid" style="background-color:<?php echo $fondo_cab;?>;">
	<div class="row">
		<div class="col-md-12">
			<nav class="navbar navbar-expand-lg navbar-light px-3 fixed-top" style="background-color:<?php echo $fondo_cab;?>;">
				<a href="index.php"><img src="img/general/ALICCIA.png"  data-toggle="tooltip" title="Inicio" target="_self" alt="Logo del site" width="64" height="50" class="align-middle pr-2"></a>
				<a>  </a>
				<a class="navbar-brand text-white"  data-toggle="tooltip" title="Aplicación - Laboratorio de Inteligencia Colectiva y Consenso basado en IA" target="_self">
				<b> <?php echo $titulo_cab;?></b></a>
				
				<div class="collapse navbar-collapse navbar-right" id="menu1">
					<div class="navbar-nav ml-md-auto">
				      
					<?php    

					if ($deb==1){echo '
				      <a class="nav-item nav-link text-white" href="./debates.php" data-toggle = "tooltip" title = "Aquí se accede a la práctica de la funcionalidad principal los debates como respuestas a preguntas abiertas con la idea de lograr  consenso e inteligencia colectiva, usando ciclos y apoyo de IA." target="_self"><i class="far fa-comments"></i> Debates</a>
				      ';}				      

					if ($doc==1){echo '
				      <a class="nav-item nav-link text-white" href="./lab.php" data-toggle="tooltip" title="En este apartado se puedan hacer pruebas de algunos fundamentos teóricos como el Frente de Pareto o de una novedosa y original álgebra de propuestas con apoyo de un LLM" target="_self"><i class="fas fa-flask"></i>  Lab </a>
				      ';}	
					  
					if ($help==1){echo '
				      <a class="nav-item nav-link text-white" href="./ayuda.php" data-toggle="tooltip" title="Aquí puede consultar los objetivos generales del TFM que ha dado origen a la aplicación y varios documentos asociados, manuales de usuario y un glsario de términos" target="_self"><i class="fa fa-question"></i> About</a>
				      ';}			
					
					echo '<a class="nav-item nav-link text-white"></a>';
					
					if ($cuad_user==1)
					
					{					

								if(isset($_SESSION['email']))
					  	    {
					  	    	if ($_SESSION['tipo']==2){echo '<a class="btn btn-success ';}
					  	    	if ($_SESSION['tipo']==0){echo  '<a class="btn btn-info ';}
					  	    	if ($_SESSION['tipo']==7){echo '<a class="btn btn-light ';}
					  	    	
					  	    }else
					  	    {echo '<a class="btn  btn-warning ';}?>
				      text-black" href="alta_login.php" data-toggle="tooltip" title="Registro y autenticación" target="_self">
				      <i class="fas fa-user"></i><?php if(isset($_SESSION['email'])){echo " ".$_SESSION["email"];}else{echo " Invitado";}}?>
				  	   </a>

					</div>
				</div>

				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menu1">
					<span class="navbar-toggler-icon"></span>
				</button> 

			</nav>
		</div>
	</div>
</div>
<?php if(isset($_SESSION['email'])){if($_SESSION['tipo']==0){include 'base/subcabecera_adm.php';}}?>
<?php if(isset($_SESSION['email'])){if($_SESSION['tipo']==2){include 'base/subcabecera_fac.php';}}?>
