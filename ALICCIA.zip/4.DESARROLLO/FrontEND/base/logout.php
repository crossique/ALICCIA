<?php
  session_start();
  $fondo_body=$_SESSION["ColorF"];
  echo '<style> body {background-color:'.$fondo_body.';}</style>';
  if(isset($_SESSION['email'])){
    session_destroy();
    unset($_SESSION);
    header("HTTP/1.1 302 Moved Temporarily");
    echo '<br><h3 style="margin-left: 2em"><font face="verdana">HA SALIDO DE LA SESIÓN CON ÉXITO, si lo desea puede seguir explorando este sitio como invitado.<br><br><a href="../index.php"</a>VOLVER AL INICIO</font></h3>';
  }else{
    echo '<br><h3 style="margin-left: 2em"><font face="verdana">   ERROR: No hay ninguna sesion iniciada.<a href="../index.php"</a> VOLVER AL INICIO<br/></font></h3>';
  }
?>