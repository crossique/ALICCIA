<div class="container-fluid text-white px-5 py-1 align-middle" style="background-color:<?php echo $fondo_cab;?>;">
	<div class="row">	
		<div class="col-12 py-1 g-primary text-white pie align-middle">
			<img src="img/general/by-nc-sa.png" alt="CC-BY-NC-SA" width="90" height="30" class="d-inline-block align-middle pr-2"> 
			<img src="img/general/Logo_UNIR.png" alt="Logo de UNIR" width="65" height="35" class="d-inline-block align-middle pr-2">
		    . . .   Desarrollado por Carlos Rossique. Se permite su uso, excepto para fines comerciales, citando al autor. 
	   </div>		   
	</div>
</div>
