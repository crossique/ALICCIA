    <div class="container-fluid bg-secondary">
	<div class="row">
		<div class="col-md-12">
			<nav class="navbar navbar-expand-lg px-4">
				<a class="navbar-brand text-white" data-toggle="tooltip" title="Inicio" target="_self">
   				Menú del facilitador</a>
				<div class="navbar-collapse navbar-right btn-toolbar" id="menu2">
					<div class="container-fluid">
				      <div class="btn-group">	
				      <a type="button" class="btn btn-primary btn-sm" href="gest_usuarios_fac.php" data-toggle="tooltip" title="Administrar grupos de debate" role="button">Admin <i class='fas fa-user'></i> <i class='fas fa-comments'></i></a>
				  	  </div>
					  &nbsp;&nbsp;&nbsp;						
				      <div class="btn-group">	
				      <a type="button" class="btn btn-primary btn-sm" href="gest_debates.php" role="button" data-toggle="tooltip" title="Gestionar debates">Gestión <i class='fas fa-comments'></i></a>
				      <a type="button" class="btn btn-info btn-sm text-white" data-target="#AyudaModalDeb" role="button" data-toggle="modal">Ayuda <i class='fas fa-comments'></i></a>
				  	  </div>
<!--				  	  &nbsp;&nbsp;&nbsp;				  	  						
				      <div class="btn-group">	
				      <a type="button" class="btn btn-primary btn-sm" href="gest_encuestas.php" role="button" data-toggle="tooltip" title="Gestionar encuestas">Gestión <i class='fas fa-question-circle'></i></a>
				      <a type="button" class="btn btn-info btn-sm text-white" data-target="#AyudaModalEnc" role="button" data-toggle="modal">Ayuda <i class='fas fa-question-circle'></i></a>
				  	  </div>-->				
				    </div>
				</div>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menu2">
					<span class="navbar-toggler-icon"></span>
				</button> 
			</nav>
		</div>
	</div>
</div>
<!-- Modal -->
<?php include 'modal_debates.php';?>
