<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="eDemocracy, Collective Intelligence">
<meta name="keywords" content="eDemocracy, Collective Intelligence, eVoting">
<meta name="author" content="Carlos Rossique">

<title>ALICCIA</title>

<!-- link rel=”stylesheet” href=”css/svg-with-js.min.css“> carga del css de Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.min.css" > <!-- carga del css de Bootstrap -->
<link rel="stylesheet" href="css/pfg.css" > <!-- carga del css propio -->

<script src="js/jquery-1.11.3.min.js"></script> <!-- carga de jquery general -->
<script src="js/jquery-ui.js"></script> <!-- carga de jquery para listas sortable -->
<script src="js/jquery.ui.touch-punch.min.js"></script> <!-- carga de jquery responsive -->
<script src="js/popper.min.js"></script> <!-- carga del popper  -->
<script src="js/bootstrap.min.js"></script> <!-- carga del js de Bootstrap  -->
<script src="js/fontawesome-all.min.js"></script> <!-- carga del js de fontawesome  -->

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>