<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
	</head>
	<body>
	   <?php include 'base/cabecera.php';?>

	   <!-- CONTENIDO ESPECÍFICO DE PÁGINA -->
   	

<?php include_once 'datos/conexion.php';
$query_idx = "SELECT explicacion FROM T_CONFIG WHERE ROWID=1";
$result_idx = mysqli_query($con, $query_idx);
$row_idx = mysqli_fetch_array($result_idx);
$explicacion = $row_idx['explicacion'];
?>


   	<div class="container-fluid barra2 px-5 py-7 align-middle">
			<div class="row">	
	   		<div class="pt-2 py-1 barra2 align-middle text-justify">
			    <?php echo $explicacion;?>
			   </div>
			</div>
		</div>



		<div class="container-fluid portada">
			<div class="row">
					<img src="img/portada.jpg" alt="portada" height="100%" width="100%">
			</div>
		</div>

	<!-- FIN CONTENIDO ESPECÍFICO -->

	<?php include 'base/pie.php';?>
   </body>
</html>