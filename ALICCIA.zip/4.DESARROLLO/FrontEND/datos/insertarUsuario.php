<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['nombre'], $_POST['apellidos'], $_POST['email'], $_POST['tipo'], $_POST['comm'], $_POST['pass'], $_POST['pass2'])) {
    
    include_once("conexion.php");

    // Obtener valores y sanitizar entradas
    $nombre = trim($_POST['nombre']);
    $apellidos = trim($_POST['apellidos']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $tipo = filter_var($_POST['tipo'], FILTER_VALIDATE_INT);
    $comm = trim($_POST['comm']);
    $pass = $_POST['pass'];
    $pass2 = $_POST['pass2'];

    // Verificar que el email sea válido
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Email no válido');</script>";
        exit;
    }

    // Verificar que las contraseñas coincidan
    if ($pass !== $pass2) {
        echo "<script>alert('Las contraseñas no coinciden');</script>";
        exit;
    }

    // Hashear la contraseña de manera segura
    $hashed_pass = password_hash($pass, PASSWORD_BCRYPT);

    // Preparar la consulta SQL
    $queryI = "INSERT INTO T_USUARIOS (nombre, apellidos, email, tipo_usuario, comentario, pass, estado) 
               VALUES (?, ?, ?, ?, ?, ?, 0)";

    if ($stmt = mysqli_prepare($con, $queryI)) {
        mysqli_stmt_bind_param($stmt, "sssis", $nombre, $apellidos, $email, $tipo, $comm, $hashed_pass);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Registro exitoso');</script>";
        } else {
            echo "<script>alert('Error en la base de datos. Es posible que el email ya exista.');</script>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<script>alert('Error al preparar la consulta');</script>";
    }

    mysqli_close($con);
}
?>
