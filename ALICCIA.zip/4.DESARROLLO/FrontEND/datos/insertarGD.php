<?php
	if (isset($_POST['nombre_gd']))
	{
		include_once("conexion.php");
		session_start(); 
		$nombre_gd = $_POST['nombre_gd'];
		$id_fac=$_SESSION['id'];
    	$queryIns = "INSERT INTO T_GRUPOS_DEBATE (nombre_gd, id_fac) 
		VALUES('$nombre_gd','$id_fac')";
		$b = mysqli_query($con,$queryIns);
		if(!$b){echo "<script>alert('ERROR EN BD. No se inserta');</script>";
				echo "<script>alert(".$queryIns.");</script>";}
	}
?>