<?php
	error_reporting(E_ALL);
	ini_set('display_errors','1');
	if(isset($_POST['valoracion']))
	{
		include_once("conexion.php");
		// get values 
		$id_debate = $_POST['id_debate'];
		$id_propuesta = $_POST['id_propuesta'];
		$email_nick = $_POST['email_nick'];
		$valoracion = $_POST['valoracion'];
		$comm = $_POST['comm'];
		$ip_term = getUserIp().'-'.getUserOS().'-'.getUserBrowser();
		$fecha =strftime("%Y-%m-%d", time());

			$numDUP=0;
			$autor=""; 
			$numAUTO=0;
			$queryDUP = "SELECT * FROM T_VALORACIONES WHERE id_debate=$id_debate AND id_propuesta=$id_propuesta AND email_nick='$email_nick' UNION SELECT * FROM T_VALORACIONES WHERE id_debate=$id_debate AND id_propuesta=$id_propuesta AND ip_term='$ip_term'";
				$resultDUP = mysqli_query($con,$queryDUP);
								while ($rowDUP = mysqli_fetch_assoc($resultDUP)) {$numDUP++;}


			$queryAUTO = "SELECT user_nick FROM T_PROPUESTAS WHERE id_propuesta=$id_propuesta";
				$resultAUTO = mysqli_query($con,$queryAUTO);
				$rowAUTO = mysqli_fetch_assoc($resultAUTO);
			    $autor=$rowAUTO['user_nick'];			
			if ($autor==$email_nick){$numAUTO=1;}					

			if ($numDUP==0){					
      	    $queryI = "INSERT INTO T_VALORACIONES (id_debate,id_propuesta, email_nick, valoracion, comentario, ip_term, fecha) 
			VALUES($id_debate,$id_propuesta,'$email_nick',$valoracion,'$comm','$ip_term','$fecha')";
			$a = mysqli_query($con,$queryI);
			echo "<script>alert('Hola?');</script>";
			if(!$a){echo "<script>alert('ERROR EN BD. Quizás la valoracion ya exista. No se inserta');</script>";}

			//recalcular media de las valoraciones

			$queryMedia="UPDATE T_PROPUESTAS SET valoracion = TRUNCATE((SELECT AVG(valoracion) FROM T_VALORACIONES WHERE id_propuesta=$id_propuesta),2) WHERE id_propuesta=$id_propuesta";

			$ejecutaMedia = mysqli_query($con,$queryMedia);









			}
			else{
				echo "<script>alert('Ya ha valorado esta propuesta previamente');</script>";
			}
	}


// Nivel 0 - funciones
function getUserIp()
{
    // Get real visitor IP behind CloudFlare network
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];}
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP)){$ip = $client;}
    elseif(filter_var($forward, FILTER_VALIDATE_IP)){$ip = $forward;}
    else{$ip = $remote;}return $ip;
}

function getUserBrowser()
{
		$userAgent= strtolower($_SERVER['HTTP_USER_AGENT']);
		if(strpos($userAgent, 'msie') !== FALSE) $browser = 'Internet explorer';
			 elseif(strpos($userAgent, 'trident') !== FALSE) $browser = 'Internet explorer';
			 elseif(strpos($userAgent, 'firefox') !== FALSE) $browser =  'Mozilla Firefox';
			 elseif(strpos($userAgent, 'chrome') !== FALSE) $browser =  'Google Chrome';
			 elseif(strpos($userAgent, 'opera mini') !== FALSE) $browser =  "Opera Mini";
			 elseif(strpos($userAgent, 'opera') !== FALSE) $browser =  "Opera";
			 elseif(strpos($userAgent, 'safari') !== FALSE) $browser = "Safari";
			 else $browser = 'Navegador desconocido';
			return $browser;
}

function getUserOS()
{		
		$userAgent= strtolower($_SERVER['HTTP_USER_AGENT']);
		if(strpos($userAgent, 'windows nt 10') !== FALSE) $os = 'Windows 10';
			 elseif(strpos($userAgent, 'windows nt 6.3') !== FALSE) $os = 'Windows 8.1';
			 elseif(strpos($userAgent, 'windows nt 6.2') !== FALSE) $os = 'Wimdows 8';
			 elseif(strpos($userAgent, 'windows nt 6.1') !== FALSE) $os = 'Windows 7';
			 elseif(strpos($userAgent, 'windows nt 6.0') !== FALSE) $os = 'Windows Vista';
			 elseif(strpos($userAgent, 'windows nt 5.2') !== FALSE) $os = 'Windows Server';
			 elseif(strpos($userAgent, 'windows nt 5.1') !== FALSE) $os = 'Windows XP';
			 elseif(strpos($userAgent, 'windows xp') !== FALSE) $os = 'Windows XP';
			 elseif(strpos($userAgent, 'windows me') !== FALSE) $os =  'Windows ME';
			 elseif(strpos($userAgent, 'windows nt 5.0') !== FALSE) $os =  'Windows 2000';
			 elseif(strpos($userAgent, 'win98') !== FALSE) $os =  "Windows 98";
			 elseif(strpos($userAgent, 'win95') !== FALSE) $os =  "Windows 95";			
			 elseif(strpos($userAgent, 'macintosh') !== FALSE) $os =  "MacOS";
			 elseif(strpos($userAgent, 'mac os') !== FALSE) $os =  "MacOS";
			 elseif(strpos($userAgent, 'mac_powerpc') !== FALSE) $os =  "MacOS";			   			
			 elseif(strpos($userAgent, 'linux') !== FALSE) $os = "Linux";
			 elseif(strpos($userAgent, 'ubuntu') !== FALSE) $os = "Linux/Ubuntu";
			 elseif(strpos($userAgent, 'iphone') !== FALSE) $os = "iPhone";
			 elseif(strpos($userAgent, 'ipod') !== FALSE) $os = "iPod";
			 elseif(strpos($userAgent, 'ipad') !== FALSE) $os = "iPad";			   			
			 elseif(strpos($userAgent, 'android') !== FALSE) $os = "Android";
			 elseif(strpos($userAgent, 'blackberry') !== FALSE) $os = "Blackberry";
			 elseif(strpos($userAgent, 'webos') !== FALSE) $os = "Mobile";			   			
			 else $os = 'SO desconocido';
			 return $os;  	
}

?>