       
  <?php include_once 'conexion.php';
  $id_propuesta = $_GET['id'];
    


 $data = '<table>
          <tr><th width="40" style="text-align:center">VAL</th>
          <th width="80%">Comentario</th>
          <th width="20%">Autor</th></tr>';

 $queryVAL = "SELECT * FROM T_VALORACIONES WHERE id_propuesta = $id_propuesta ORDER BY fecha DESC";
 if (!$resultVAL = mysqli_query($con,$queryVAL)) {exit(mysqli_error($con));}
 while ($rowVAL = mysqli_fetch_assoc($resultVAL)) {
 $data .= '<tr><td style="text-align:center">'.$rowVAL['valoracion'].'</td><td>'.$rowVAL['comentario'].'</td><td>'.$rowVAL['email_nick'].'</td></tr>';
                }
     $data .= '</table>';
     echo $data;
    mysqli_close($con);

?>



