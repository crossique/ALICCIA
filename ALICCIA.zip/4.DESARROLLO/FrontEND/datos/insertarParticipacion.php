<!-- EJECUCION EN CASO DE OPINION A ENCUESTA -->
<?php
	error_reporting(E_ALL);
	ini_set('display_errors','1');
	include_once 'conexion.php';
	session_start();

	// INSERCION DE OPINION

	// Recuperación de valores del POST y calculo de algunas variables interesantes
	// Nivel 0 - sin ejecucion
	if (isset($_POST['participa']))
	{
		// Comienzo Nivel 1 - se ejecuta en cualquier caso (por formulario de opinion)

		$capt = $_POST['capt'];
		$texto = $_POST['texto'];
		$id_debate = $_POST['id_D'];
		$propuesta = $_POST['propuesta'];

		$nom_cookie='D'.$id_debate;
		echo "<script>alert('".$nom_cookie."');</script>";
		if(isset($_SESSION['email'])){$usnick=$_SESSION['email'];}else{
			if (isset($_COOKIE[$nom_cookie])){$usnick=$_COOKIE[$nom_cookie];}else{
				$usnick= $_POST['nick'];
				setcookie($nom_cookie,$usnick,time()+365*24*3600, '/');
				}
		}
		$ip = getUserIp();
		$nav = getUserBrowser();
		$so = getUserOS();
		$ip_term = $ip.'-'.$so.'-'.$nav;
		//$valor_cookie=$_COOKIE['$nom_cookie'];
		//echo "<script>alert('Permiso: '+'$permiso');</script>";	
		//echo "<script>alert('Valor Cookie: '+'$valor_cookie');</script>";	

		if ($capt==$_SESSION['cod_captcha'])
		{ // Comienzo Nivel 2 - Se ejecuta si esta bien el captcha 

			//Comprobamos duplicados en BD	
				$queryOP_a = "SELECT generacion_act, tipo_debate FROM T_DEBATES WHERE id_debate='$id_debate'"; 
				$resultOP_a = mysqli_query($con,$queryOP_a);
								while ($rowOP_a = mysqli_fetch_assoc($resultOP_a)) {$genact=$rowOP_a['generacion_act'];$tipo_deb=$rowOP_a['tipo_debate'];}

				$queryOP_d = "SELECT * FROM T_PROPUESTAS WHERE id_debate='$id_debate' AND ip_term='$ip_term' AND generacion=$genact UNION SELECT * FROM T_PROPUESTAS WHERE id_debate='$id_debate' AND user_nick='$usnick' AND generacion=$genact"  ; // aquí podemos cambiar las restricciones de duplicados
				$num_dup=0;

				$resultOP_dup = mysqli_query($con,$queryOP_d);
								while ($rowOP_dup = mysqli_fetch_assoc($resultOP_dup)) {$num_dup++;}

				//echo "<script>alert('Duplicados: '+'$num_dup');</script>";
				if($tipo_deb=='AP'){$propuesta=NULL;}				
				if ($num_dup == 0)
				{ // Comienzo Nivel 4 - Se ejecuta si no hay duplicados en BD

		
					$queryIO1="INSERT INTO T_PROPUESTAS
					(texto_propuesta,generacion,user_nick,id_debate,ip_term,fecha,valoracion,hija_de) VALUES(
					'$texto','$genact','$usnick','$id_debate','$ip_term',CURDATE(),2,'$propuesta')";

					$ejecutaIO1 = mysqli_query($con,$queryIO1);

					$queryIO2="SELECT MAX(id_propuesta)as maximid FROM T_PROPUESTAS";
					$ejecutaIO2 = mysqli_query($con,$queryIO2);

					$rowIO2 = mysqli_fetch_assoc($ejecutaIO2);
					$idr= $rowIO2['maximid'];

					$queryIO3="INSERT INTO T_VALORACIONES
					(id_debate,id_propuesta,email_nick,ip_term,fecha,valoracion,comentario) VALUES(  
					'$id_debate','$idr','$usnick','$ip_term',CURDATE(),2,'--- (valoración inicial del autor) ---')";

					$ejecutaIO3 = mysqli_query($con,$queryIO3);
					


					if(!$ejecutaIO1){
					echo "<script>alert('ERROR EN BD. No se inserta');</script>";
					echo "<script>alert('$queryIO1');</script>";}
					else
					{  // Comienzo Nivel 5 - Se ejecuta si se inserta la opinion
												
						
						echo '<br><h3 style="margin-left: 2em"><font face="verdana">Su propuesta ha quedado registrada, gracias. <a href="../debates.php"> Volver a debates</a>.</font></h3>';

					} // FIN Nivel 5 Ejecucion si se ha insertado la opinion

				} // FIN Nivel 4 Ejecucion si no hay duplicados

				else{echo '<br><h3 style="margin-left: 2em"><font face="verdana">Lo sentimos. Ya ha propuesto previamente en este debate en esta fase desde ese terminal. <a href="../debates.php"> Volver a debates</a>.</font></h3>';} 
			
		} // FIN Nivel 2 Ejecucion si va bien captcha y/o password 

		else{echo "<script>alert('Algo ha fallado. Revise el captcha (o asegurase de que no ha dejado campos vacíos');</script>";
			echo" <script> window.history.back(-1);</script>";}

	} // FIN Nivel 1 Ejecucion siempre por el formulario


// Nivel 0 - funciones
function getUserIp()
{
    // Get real visitor IP behind CloudFlare network
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];}
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP)){$ip = $client;}
    elseif(filter_var($forward, FILTER_VALIDATE_IP)){$ip = $forward;}
    else{$ip = $remote;}return $ip;
}

function getUserBrowser()
{
		$userAgent= strtolower($_SERVER['HTTP_USER_AGENT']);
		if(strpos($userAgent, 'msie') !== FALSE) $browser = 'Internet explorer';
			 elseif(strpos($userAgent, 'trident') !== FALSE) $browser = 'Internet explorer';
			 elseif(strpos($userAgent, 'firefox') !== FALSE) $browser =  'Mozilla Firefox';
			 elseif(strpos($userAgent, 'chrome') !== FALSE) $browser =  'Google Chrome';
			 elseif(strpos($userAgent, 'opera mini') !== FALSE) $browser =  "Opera Mini";
			 elseif(strpos($userAgent, 'opera') !== FALSE) $browser =  "Opera";
			 elseif(strpos($userAgent, 'safari') !== FALSE) $browser = "Safari";
			 else $browser = 'Navegador desconocido';
			return $browser;
}

function getUserOS()
{		
		$userAgent= strtolower($_SERVER['HTTP_USER_AGENT']);
		if(strpos($userAgent, 'windows nt 10') !== FALSE) $os = 'Windows 10';
			 elseif(strpos($userAgent, 'windows nt 6.3') !== FALSE) $os = 'Windows 8.1';
			 elseif(strpos($userAgent, 'windows nt 6.2') !== FALSE) $os = 'Wimdows 8';
			 elseif(strpos($userAgent, 'windows nt 6.1') !== FALSE) $os = 'Windows 7';
			 elseif(strpos($userAgent, 'windows nt 6.0') !== FALSE) $os = 'Windows Vista';
			 elseif(strpos($userAgent, 'windows nt 5.2') !== FALSE) $os = 'Windows Server';
			 elseif(strpos($userAgent, 'windows nt 5.1') !== FALSE) $os = 'Windows XP';
			 elseif(strpos($userAgent, 'windows xp') !== FALSE) $os = 'Windows XP';
			 elseif(strpos($userAgent, 'windows me') !== FALSE) $os =  'Windows ME';
			 elseif(strpos($userAgent, 'windows nt 5.0') !== FALSE) $os =  'Windows 2000';
			 elseif(strpos($userAgent, 'win98') !== FALSE) $os =  "Windows 98";
			 elseif(strpos($userAgent, 'win95') !== FALSE) $os =  "Windows 95";			
			 elseif(strpos($userAgent, 'macintosh') !== FALSE) $os =  "MacOS";
			 elseif(strpos($userAgent, 'mac os') !== FALSE) $os =  "MacOS";
			 elseif(strpos($userAgent, 'mac_powerpc') !== FALSE) $os =  "MacOS";			   			
			 elseif(strpos($userAgent, 'linux') !== FALSE) $os = "Linux";
			 elseif(strpos($userAgent, 'ubuntu') !== FALSE) $os = "Linux/Ubuntu";
			 elseif(strpos($userAgent, 'iphone') !== FALSE) $os = "iPhone";
			 elseif(strpos($userAgent, 'ipod') !== FALSE) $os = "iPod";
			 elseif(strpos($userAgent, 'ipad') !== FALSE) $os = "iPad";			   			
			 elseif(strpos($userAgent, 'android') !== FALSE) $os = "Android";
			 elseif(strpos($userAgent, 'blackberry') !== FALSE) $os = "Blackberry";
			 elseif(strpos($userAgent, 'webos') !== FALSE) $os = "Mobile";			   			
			 else $os = 'SO desconocido';
			 return $os;  	
}

?>