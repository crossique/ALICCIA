<?php include_once("conexion.php");?>    
<?php     // Diseño de tabla
   $data = '<table class="table table-bordered table-striped table-xtra-consensed">
                        <tr class="table-xtra-consensed">
                            <th width="40">ID</th>
                            <th>Nombre</th>
                            <th>Apellido(s)</th>
                            <th>Email</th>
                            <th width="40">DELETE</th>
                        </tr>';

    if (isset($_POST['filtro'])) {$filtro = $_POST['filtro'];}else{$filtro=01;}                        
 
    $query = "SELECT * FROM T_USUARIOS INNER JOIN T_USUARIOS_GRUPOS_DEBATE ON id=id_usuario WHERE id_gd = ".$filtro;

    //$query .= " ORDER BY tipo_usuario, apellidos";
   
    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
 
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
        while($row = mysqli_fetch_array($result))
        {


            $data .= '<tr class="table-xtra-consensed">
            
                <td>'.$row['id'].'</td>
                <td>'.$row['nombre'].'</td>
                <td>'.$row['apellidos'].'</td>
                <td>'.$row['email'].'</td>
                <td style="text-align:center;">
                    <button onclick="DeleteUserGD('.$row['id'].','.$filtro.')" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                </td>
            </tr>';
 
        }
    }
    else
    {
        // records now found 
        $data .= '<tr><td colspan="10">No hay registros</td></tr>';
    }
     $data .= '</table>';
     echo $data;
    mysqli_close($con);
?>