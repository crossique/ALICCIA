<?php
include_once("conexion.php");
if(isset($_POST['id']))
{
    $user_id = IntVal($_POST['id']);
    $valor = 1;
	$query = "SELECT estado FROM T_USUARIOS WHERE id = $user_id";
	$result = mysqli_query($con,$query);
	$row = mysqli_fetch_array($result);
    if($row['estado']==1){$valor=0;}
    $query = "UPDATE T_USUARIOS SET estado = '$valor' WHERE id = $user_id";
    if (!$result = mysqli_query($con,$query)) {
        exit(mysqli_error($con)); echo "<script type='text/javascript'>alert('ERROR MYSQL');</script>";
    }else{echo "<script type='text/javascript'>alert('CAMBIADO');</script>";}
}
echo "<script type='text/javascript'>alert('HAY FALLOS');</script>";
?>