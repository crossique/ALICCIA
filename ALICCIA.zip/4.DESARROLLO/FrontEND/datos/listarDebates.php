<?php include_once("conexion.php");
    session_start();?>
<div class="container-fluid">
    <div class="btn-group">   
      <a type="button" class="btn btn-success btn-sm text-white" data-target="#add_new_record_modal" data-toggle="modal"><i class='fas fa-share'></i> Añadir Debate </a>
    </div>
</div>
<br/>
<!-- Modal Actualización Debate -->
<div class="modal fade" id="update_debate_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <b><p>ACTUALIZAR DEBATE</p></b>
                <hr>
             </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label for="update_nombre">Título</label>
                            <input type="text" id="update_nombre" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="update_resumen">Resumen</label>
                            <textarea rows="2" class="form-control" id="update_resumen"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="update_texto">Pregunta / Texto Inicial</label>
                            <textarea rows="9" class="form-control" id="update_texto"></textarea>
                        </div>                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="form-group">
                            <label for="update_tipo">Tipo de debate</label>
                            <select name="update_tipo" class="form-control input-lg" id="update_tipo">
                            <option value="AP">Tipo Appgree</option>
                            <option value="IW">Tipo IWarsMaps</option>
                            <option value="VI">Tipo Vilfredo</option>
                            </select>
                        </div>
                    </div>    
                    <div class="col-md-6 col-sm-12">
                        <div class="form-group">
                          <label for="update_estado">Estado</label>
                            <select name="update_estado" class="form-control" id="update_estado" >
                              <option value="1P">1-En preparación</option>
                              <option value="2L">2-Listo</option>
                              <option value="3A">3-Activo</option>
                              <option value="4F">4-Finalizado</option>
                              <option value="5C">5-Cerrado</option>
                            </select>
                        </div>
                    </div>    
                </div>        
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-warning" onclick="UpdateDebate()"><i class='fas fa-pencil-alt'></i> Actualizar</button>
                <input type="hidden" id="hidden_debate_id">
            </div>
        </div>
    </div>
</div>
<!-- Fin Modal Actualización Debate -->
<?php     // Diseño de tabla
   $data = '<table class="table table-bordered table-striped table-xtra-consensed">
                        <tr class="table-xtra-consensed">
                            <th width="40">No.</th>
                            <th width="100">Nombre</th>
                            <th width="200">Resumen/Tema</th>
                            <th>Texto inicial (Se muestra solo el comienzo ...)</th>
                            <th width="40">Organiza</th>
                            <th width="40">Grupo</th>
                            <th width="40">TipoDeb</th>
                            <th width="40">ESTADO</th>
                            <th width="40">UPDATE</th>
                            <th width="40">GESTION</th>
                            <th width="40">DELETE</th>
                        </tr>';
    if($_SESSION["tipo"] == 0){$query = "SELECT * FROM T_DEBATES";}
    $organiza = $_SESSION["id"];
    if(($_SESSION["tipo"] > 0)&&($_SESSION["tipo"] < 3)){$query = "SELECT * FROM T_DEBATES INNER JOIN T_GRUPOS_DEBATE ON grupo= id_grupo_debate WHERE T_DEBATES.id_fac = '$organiza'";}
    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
    if(mysqli_num_rows($result) > 0)
    {
        $number = 1;
        while($row = mysqli_fetch_array($result))
        {
            if($row['tipo_debate']=='AP'){$tipo="Appgree";}
            if($row['tipo_debate']=='IW'){$tipo="IWarsMap";}
            if($row['tipo_debate']=='VI'){$tipo="Vilfredo";}
            $texto_ini = $row['texto_inicial'];
            if(strlen($texto_ini)>222){$texto_ini=substr($texto_ini, 0, 221).' ...';}
            $data .= '<tr class="table-xtra-consensed">
                <td>'.$row['id_debate'].'</td>
                <td>'.$row['nombre'].'</td>
                <td>'.$row['resumen'].'</td>
                <td>'.$texto_ini.'</td>
                <td>'.$row['id_fac'].'</td>
                <td>'.$row['nombre_gd'].'</td>
                <td>'.$tipo.'</td>
                <td style="text-align:center;">'.$row['estado'].'</td>
                <td style="text-align:center;vertical-align:middle;">
                    <button onclick="DetallesDebate('.$row['id_debate'].')" class="btn btn-warning btn-sm"><i class="fas fa-pencil-alt"></i></button>
                </td>
                <td style="text-align:center;vertical-align:middle;">
                    <a type="button" class="btn btn-primary btn-sm" href="gest_debate.php?debate='.$row['id_debate'].'"</a><i class="fas fa-list"></i>
                </td>
                <td style="text-align:center;vertical-align:middle;">
                    <button onclick="DeleteDebate('.$row['id_debate'].')" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                </td>
            </tr>';
            $number++;
        }
    }
    else
    {
        $data .= '<tr><td colspan="16">No hay debates a gestionar</td></tr>';
    }
     $data .= '</table>';
     echo $data;
    mysqli_close($con);
?>