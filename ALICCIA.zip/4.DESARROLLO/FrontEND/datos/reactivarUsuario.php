<!DOCTYPE html>
<html lang="es">
    <head>
<link rel="stylesheet" href="css/bootstrap.min.css" > <!-- carga del css de Bootstrap -->
<link rel="stylesheet" href="css/pfg.css" > <!-- carga del css propio -->

<script src="js/jquery-1.11.3.min.js"></script> <!-- carga de jquery general -->
<script src="js/jquery-ui.js"></script> <!-- carga de jquery para listas sortable -->
<script src="js/jquery.ui.touch-punch.min.js"></script> <!-- carga de jquery responsive -->
<script src="js/popper.min.js"></script> <!-- carga del popper  -->
<script src="js/bootstrap.min.js"></script> <!-- carga del js de Bootstrap  -->
<script src="js/fontawesome-all.min.js"></script> <!-- carga del js de fontawesome  -->
    </head>
    <body>
<?php include_once '../datos/conexion.php';
session_start();?>

        <div class="container-fluid">
            <h5>SERVICIO DE OLVIDO DE CONTRASEÑA</h5>
            <div class="row">
                <div class="col-md-5 col-sm-12 fondo2 pt-2 px-4">
                
                <form role="form" method="post">
                <div class="row">
                <div class="form-group input-group-sm col-md-6">
                Email: <input type="email" class="form-control" id="emailoo" name="emailoo" placeholder="email" required>
                </div>
                <div class="form-group input-group-sm col-md-6">
                Nueva Contraseña: <input type="password" class="form-control " id="password" name="password" placeholder="Contrase&ntilde;a" required>
                </div>
                <div class="form-group input-group-sm col-md-6">
                Confirmar contraseña: <input type="password" class="form-control " id="password2" name="password2" placeholder="Contraseña" required>
                </div>
                <div class="form-group input-group-sm col-md-6">
                Captcha: <img src="../base/captcha.php" alt="código" data-toggle="tooltip" title="Click para refrescar" id="captcha" onclick="document.getElementById('captcha').src = '../base/captcha.php?'+ Math.random(); return false"><br>
                <input type="text" class="form-control" name="capto" id="capto" placeholder="(introduzca el texto de la imagen)" required>
                </div>
                </div>
                <button type="submit" class="btn btn-info" name="react" id="react">Renovar contraseña</button>
                </form>
                </div>
            </div>
        </div>


<?php
if(isset($_POST['react'])){
    $capto=$_POST['capto'];
    $emailoo = $_POST['emailoo']; 
    $password = $_POST['password']; 
    $password2 = $_POST['password2']; 

if(isset($_GET['val'])&&($capto==$_SESSION['cod_captcha'])&&(validaPassword($password, $password2)))
{
    $user_token = $_GET['val'];
    $query = "SELECT * FROM T_USUARIOS WHERE token = '$user_token'";
    $result = mysqli_query($con,$query);
    $row = mysqli_fetch_array($result);
    $pass = hash("sha256", $password);
    $query = "UPDATE T_USUARIOS SET pass = '$pass' WHERE token = '$user_token' AND email = '$emailoo'";
    if (!$result = mysqli_query($con,$query)) {
        exit(mysqli_error($con)); echo "<script type='text/javascript'>alert('ERROR MYSQL');</script>";
    }else{
   	echo '<br><h3 style="margin-left: 2em"><font face="verdana">   '.$emailoo.', BIENVENIDO/A A <a href="../alta_login.php">DEMOCRACIA AVANZADA</a>, Su usuario ha sido validado. Entre con su email y nueva contraseña .</font></h3>';
    }
}
else
{
echo "<script type='text/javascript'>alert('HAY DISCREPANCIAS O FALTAN DATOS');</script>";
}
    
}


    function validaPassword($var1, $var2)
    {
        if (strcmp($var1, $var2) !== 0){
            return false;
            } else {
            return true;
        }
    }
?>


   </body>
</html>