<?php
include_once("conexion.php");
if(isset($_POST['id']))
{
    $id_deb = $_POST['id'];
	$query = "SELECT estado_fase FROM T_DEBATES WHERE id_debate = '$id_deb'";
	$result = mysqli_query($con,$query);
	$row = mysqli_fetch_array($result);
    if($row['estado_fase']==1){$valor=0;}else{$valor=1;}
    $query = "UPDATE T_DEBATES SET estado_fase = '$valor' WHERE id_debate = '$id_deb'";
    if (!$result = mysqli_query($con,$query)) {
        exit(mysqli_error($con)); echo "<script type='text/javascript'>alert('ERROR MYSQL');</script>";
    }else{echo "<script type='text/javascript'>alert('CAMBIADO');</script>";}
}
echo "<script type='text/javascript'>alert('HAY FALLOS');</script>";
?>