<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include '../base/head.php';?>
     	<script src="../js/jquery-1.11.3.min.js"></script>
		<script src="../js/popper.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="../css/bootstrap.min.css" >
	</head>
	<body>
	   	<?php include_once 'conexion.php';?>

	   	<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->


<?php
session_start();
$idd= $_SESSION["idd"];
$fondo_body=$_SESSION["ColorF"];
$idO = $_GET["idO"];
$dir="";
if (strlen($idO)==3){$dir="../img/debates/";}
// el id del objeto
?>
<style> body {background-color: <?php echo $fondo_body;?>;}</style>
<div class="container">
	    <div class="panel-dialog" role="document">
	        <div class="panel-content">
	            <div class="panel-header pt-5">
	                <b><p>CAMBIAR/SUBIR IMAGEN Y ACTUALIZAR DESDE AJAX</p></b>
	                <hr>
		            </div>
		            <div class="panel-body">
		            	<p>La imagen debe ser un .jpg, con relacion de aspecto 2:1 (recomendacion 200x100 píxeles) y no debe de exceder los 100KB de tamaño, de otra manera la imagen no se subirá al servidor.</p>
						<form enctype="multipart/form-data" method="POST">
						<input name="uploadedfile" type="file" />
						<input type="submit" id="subir" name="subir" />
						</form>
					</div>
	            </div>
	            <div class="panel-footer">
	            </div>
	    </div>
</div>

<?php
$uploadedfileload="true";
if(isset($_POST['subir'])){
	echo "<script>alert('CHEQUEO2');</script>";

$uploadedfile_size=$_FILES['uploadedfile']['size'];
echo $_FILES['uploadedfile']['name'];
if ($_FILES['uploadedfile']['size']>100000)
{$uploadedfileload="false";}

if (!($_FILES['uploadedfile']['type'] =="image/jpeg"))
{$uploadedfileload="false";}

$file_name=$_FILES['uploadedfile']['name'];
$file_name=$idO.".jpg";

if(($uploadedfileload=="true")&&(strlen($dir)>0)){     
    
    //comprobamos si el archivo ha subido
    if ($file_name && move_uploaded_file($_FILES['uploadedfile']['tmp_name'],$dir.$file_name))
    {

	include_once("conexion.php");


    if (strlen($idO)==3){$query = "UPDATE T_DEBATES SET imagen = '$file_name' WHERE id_debate = '$idO'";}


    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
	echo" <script type='text/javascript'> alert('Imagen subida');</script>";
	header("Location: ../gest_debate.php?debate=".$idd."");
    }
    else{echo "Error al subir el archivo";}


}else{echo" <script type='text/javascript'> alert('Imagen inválida (Por tamaño, tipo o inexistente)');</script>";
header("Location: ../gest_debate.php?debate=".$idd."");}

}
?>
   </body>
</html>