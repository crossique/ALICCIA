<?php include_once("conexion.php");


// check request
if(isset($_POST['id']) && isset($_POST['id']) != "")
{

    $user_id = $_POST['id'];
    $queryGJ1 = "SELECT nombre, tipo_debate FROM T_DEBATES WHERE id_debate = '$user_id'";
    if (!$resultGJ1 = mysqli_query($con,$queryGJ1)) {
        exit(mysqli_error($con));
    }
    $rowGJ1 = mysqli_fetch_assoc($resultGJ1);

    $data =  '<b>Árbol de propuestas del debate: "'.$rowGJ1['nombre'].'"</b><br><br>';


    $queryGJ2 = "SELECT generacion, user_nick, texto_respuesta, hija_de FROM T_RESPUESTAS WHERE id_debate = '$user_id'";
    if (!$resultGJ2 = mysqli_query($con,$queryGJ2)) {
        exit(mysqli_error($con));
    }



    $data .= '

<div id="myDiagramDiv"
style="width:750px; height:500px; border: 1px solid black; background-color: #FFFFEE;">
</div>      
<script type="text/javascript">

var $ = go.GraphObject.make;
var myDiagram = $(go.Diagram, "myDiagramDiv");

var nodeDataArray =[';

$data .= '{ key: "PROPUESTA INICIAL", color: "lightblue"},';

while ($rowGJ2 = mysqli_fetch_assoc($resultGJ2)) {
$texto=$rowGJ2['texto_respuesta'];
if (strlen($texto)>20){$texto=SUBstr($texto,0,20).' ...';}    
$key = 'G'.$rowGJ2['generacion'].'-'.$rowGJ2['user_nick'];
$parent = 
$name = $key.": ".$texto;


$data .= '{ key: "'.$name.'", color: "cyan"},';
}

$data .= '
];

var linkDataArray =[';

    if (!$resultGJ3 = mysqli_query($con,$queryGJ2)) {
        exit(mysqli_error($con));
    }


while ($rowGJ3 = mysqli_fetch_assoc($resultGJ3)) {
$texto=$rowGJ3['texto_respuesta'];
if (strlen($texto)>20){$texto=SUBstr($texto,0,20).' ...';}    
$key = 'G'.$rowGJ3['generacion'].'-'.$rowGJ3['user_nick'];
$parent = 
$name = $key.": ".$texto;


$data .= '{ to: "'.$name.'", from: "PROPUESTA INICIAL"},';
}

$data .= '
];

myDiagram.model=new go.GraphLinksModel(nodeDataArray, linkDataArray);

myDiagram.nodeTemplate =
  $(go.Node, "Auto",
    $(go.Shape, "RoundedRectangle", {fill: "black"},
      new go.Binding("fill", "color")
    ),  
    $(go.TextBlock, "text", {margin: 10, stroke: "black", font: "bold 12px sans-serif" },
      new go.Binding("text", "key")
    )
  );

</script>
    ';

    
    echo $data;

}    
?>