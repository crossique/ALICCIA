<?php
// include Database connection file
include_once("conexion.php");

// check request
if(isset($_POST['id']) && isset($_POST['id']) != "")
{
    $user_id = $_POST['id'];
    $query = "SELECT id_debate, T_DEBATES.nombre, texto_inicial, tipo_debate, email AS fac FROM T_DEBATES INNER JOIN T_USUARIOS ON id_fac=id WHERE id_debate = '$user_id'";
    if (!$result = mysqli_query($con,$query)) {
        exit(mysqli_error($con));
    }

    $response = array();
    if(mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            if($row['tipo_debate']=='AP'){$row['tipo_debate']="Appgree";}
            if($row['tipo_debate']=='IW'){$row['tipo_debate']="IWarsMap";}
            if($row['tipo_debate']=='VI'){$row['tipo_debate']="Vilfredo";}
            $response = $row;
        }
    }
    else
    {
        $response['status'] = 200;
        $response['message'] = "Data not found!";
    }
    // display JSON data
    echo json_encode($response);
}
else
{
    $response['status'] = 200;
    $response['message'] = "Invalid Request!";
}