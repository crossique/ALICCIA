<?php
include_once("conexion.php");
if(isset($_POST['id']))
{
    $user_id = $_POST['id'];
    $query = "DELETE FROM T_GRUPOS_DEBATE WHERE (id_grupo_debate = '$user_id' AND id_grupo_debate > 1)";
    if (!$result = mysqli_query($con,$query)) {
        exit(mysqli_error($con)); echo "<script type='text/javascript'>alert('ERROR MYSQL');</script>";
    }else{echo "<script type='text/javascript'>alert('SE BORRÓ');</script>";}
}
echo "<script type='text/javascript'>alert('HAY FALLOS');</script>";
?>