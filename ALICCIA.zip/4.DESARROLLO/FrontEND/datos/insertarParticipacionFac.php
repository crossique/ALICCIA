<!-- EJECUCION EN CASO DE INSERCION DE PROPUESTA POR EL FACILITADOR -->
<?php
	if(isset($_POST['texto']) && isset($_POST['debate']))
	{
		include_once("conexion.php");
		// get values
		session_start(); 
		$texto = $_POST['texto'];
		$debate = $_POST['debate'];
		$generacion = $_POST['generacion'];
		$fac = $_SESSION['email'].'\n(como facilitador)';
		$hija_de = $_POST['hija_de'];
		$fecha =strftime("%Y-%m-%d", time() );

    	$queryI = "INSERT INTO T_PROPUESTAS (texto_propuesta,generacion,estado,valoracion,user_nick,id_debate,ip_term,fecha) VALUES
    	('$texto','$generacion',1,0, '$fac', '$debate', '-servidor-', '$fecha')";
		$a = mysqli_query($con,$queryI);

		if(!$a){echo "<script>alert('ERROR EN BD. No se inserta');</script>";
				echo "<script>alert(".$queryI.");</script>";}

	}
?>