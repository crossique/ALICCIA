<?php include_once("conexion.php");?>    

<?php     // Diseño de tabla
   session_start(); 
   $data = '<table class="table table-bordered table-striped table-xtra-consensed">
                        <tr class="table-xtra-consensed">
                            <th width="40">ID</th>
                            <th>Nombre</th>
                            <th width="40">DELETE</th>
                        </tr>';
    $queryGD = "SELECT * FROM T_GRUPOS_DEBATE WHERE id_fac=".$_SESSION['id'];
     if (!$result = mysqli_query($con, $queryGD)) {
        exit(mysqli_error($con));
    }
 
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
        while($row = mysqli_fetch_array($result))
        {
            $data .= '<tr class="table-xtra-consensed">
            
                <td>'.$row['id_grupo_debate'].'</td>
                <td>'.$row['nombre_gd'].'</td>
                <td style="text-align:center;">
                    <button onclick="DeleteGD('.$row['id_grupo_debate'].')" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                </td>
            </tr>';
        }
    }
    else
    {
        // records now found 
        $data .= '<tr><td colspan="10">No hay registros</td></tr>';
    }
     $data .= '</table>';
     echo $data;
    mysqli_close($con);
?>