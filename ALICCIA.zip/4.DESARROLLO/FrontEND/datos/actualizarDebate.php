<?php
include_once("conexion.php");

// chequeo del control
if(isset($_POST['id']))
{
    // tomar los valores del formulario
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $resumen = $_POST['resumen'];
    $texto = $_POST['texto'];
    $tipo = $_POST['tipo'];
    $estado = $_POST['estado'];
    // Comprobaciones y ajustes de coherencia

    $query = "UPDATE T_DEBATES SET nombre = '$nombre', resumen = '$resumen', texto_inicial = '$texto', tipo_debate = '$tipo', estado = '$estado' WHERE id_debate = '$id'";

    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
}