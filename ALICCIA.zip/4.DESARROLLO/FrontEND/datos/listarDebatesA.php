<?php include_once("conexion.php");?>

<!-- Modal para ver los detalles del Debate -->
<div class="modal fade" id="update_debate_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Detalles del debate</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label for="update_nombre">Nombre</label>
                            <input type="text" id="update_nombre" class="form-control" disabled>
                        </div>
                        <div class="form-group">
                            <label for="update_texto">Pregunta / Texto Inicial</label>
                            <textarea rows="12" class="form-control" id="update_texto" disabled></textarea>
                        </div>                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="form-group">
                            <label for="update_tipo">Tipo</label>
                            <input type="text" id="update_tipo" class="form-control" disabled>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="form-group">
                            <label for="update_fac">Facilitador</label>
                            <input type="text" id="update_fac" class="form-control" disabled>
                        </div> 
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
                <input type="hidden" id="hidden_user_id">
            </div>
        </div>
    </div>
</div>

<?php     // Diseño de tabla
   $data = '<table class="table table-bordered table-striped table-xtra-consensed">
                        <tr class="table-xtra-consensed">
                            <th width="40">IMAGEN</th>
                            <th width="100">Nombre</th>
                            <th width="200">Resumen</th>
                            <th>Pregunta / Texto inicial (Se muestra solo el comienzo ...)</th>
                            <th width="100">Grupo</th>
                            <th width="40">Tipo</th>
                            <th width="40">Estado</th>
                            <th width="40">Detalles</th>
                            <th width="40">Desarrollo</th>
                            <th width="40">ENTRAR</th>
                        </tr>';
    session_start();
    if(!isset($_SESSION['email'])){$usuario=null;}else{$usuario = $_SESSION['email'];}
    $query = "

    SELECT id_debate,imagen,T_DEBATES.nombre,resumen,texto_inicial, tipo_debate, nombre_gd, T_DEBATES.estado FROM T_DEBATES INNER JOIN T_GRUPOS_DEBATE ON grupo=id_grupo_debate WHERE (T_DEBATES.estado='3A' AND grupo=01)
    UNION
    SELECT id_debate,imagen,T_DEBATES.nombre,resumen,texto_inicial, tipo_debate, nombre_gd, T_DEBATES.estado FROM T_DEBATES INNER JOIN T_GRUPOS_DEBATE ON grupo=id_grupo_debate INNER JOIN T_USUARIOS_GRUPOS_DEBATE ON id_grupo_debate= id_gd INNER JOIN T_USUARIOS ON id=id_usuario WHERE ( T_DEBATES.estado='3A' AND email= '$usuario')

    ";

    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
 
    // if query results contains rows then fetch those rows 
    if(mysqli_num_rows($result) > 0)
    {
        $number = 1;
        while($row = mysqli_fetch_array($result))
        {
            
            $numdeb=$row['id_debate'];
            while(strlen($numdeb)<3){$numdeb='0'.$numdeb;}
            if($row['tipo_debate']=='AP'){$tipo="Appgree";}
            if($row['tipo_debate']=='IW'){$tipo="IWarsMap";}
            if($row['tipo_debate']=='VI'){$tipo="Vilfredo";}
            if($row['estado']=='3A'){$est="ACTIVO";}
            $texto_ini = $row['texto_inicial'];
            if(strlen($texto_ini)>200){$texto_ini=substr($texto_ini, 0, 199).' ...';}            
            $data .= '<tr class="table-xtra-consensed">
                <td><img src="img/debates/'.$row["imagen"].'" height="50px" width="100px" class="d-inline-block align-middle align-center"></td>
                <td>'.$row['nombre'].'</td>
                <td>'.$row['resumen'].'</td>
                <td>'.$texto_ini.'</td>
                <td>'.$row['nombre_gd'].'</td>                
                <td>'.$tipo.'</td>
                <td>'.$est.'</td>
                <td style="text-align:center;vertical-align:middle;">
                    <button onclick="DetallesDebateA('.$row['id_debate'].')" class="btn btn-dark btn-sm"><i class="fas fa-eye"></i></button>
                </td>
                <td style="text-align:center;vertical-align:middle;">
                    <button onclick="DesarrolloDebateA('.$row['id_debate'].')" class="btn btn-warning btn-sm"><i class="fas fa-list"></i></button>
                </td>
                <td style="text-align:center;vertical-align:middle;">
                    <a type="button" class="btn btn-success btn-sm" href="participa.php?debate='.$numdeb.'"</a><i class="fas fa-comment-alt"></i>
                </td>
            </tr>';
            $number++;
        }
    }
    else
    {
        // records now found 
        $data .= '<tr><td colspan="16">No hay debates activos para este usuario</td></tr>';
    }
     $data .= '</table>';
     echo $data;
    mysqli_close($con);
?>