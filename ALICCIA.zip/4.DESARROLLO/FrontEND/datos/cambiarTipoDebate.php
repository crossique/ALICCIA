<?php
include_once("conexion.php");
if(isset($_POST['id']))
{
    $id_deb = $_POST['id'];
    $query = "SELECT tipo_debate FROM T_DEBATES WHERE id_debate = '$id_deb'";
    $result = mysqli_query($con,$query);
    $row = mysqli_fetch_array($result);
    if($row['tipo_debate']=='AP'){$valor='IW';}
    if($row['tipo_debate']=='IW'){$valor='VI';}
    if($row['tipo_debate']=='VI'){$valor='AP';}

    $query = "UPDATE T_DEBATES SET tipo_Debate = '$valor' WHERE id_debate = '$id_deb'";
    if (!$result = mysqli_query($con,$query)) {
        exit(mysqli_error($con)); echo "<script type='text/javascript'>alert('ERROR MYSQL');</script>";
    }else{echo "<script type='text/javascript'>alert('CAMBIADO');</script>";}
}
echo "<script type='text/javascript'>alert('HAY FALLOS');</script>";
?>