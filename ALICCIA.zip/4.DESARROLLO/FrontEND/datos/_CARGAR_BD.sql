-- Estas dos lineas pueden quitarse si no se quiere hacer el reset general
-- DROP DATABASE IF EXISTS BD_DEBATES;
-- CREATE DATABASE BD_DEBATES;

USE BD_DEBATES;

-- Borrado de tablas linkadas con usuarios, del subsistema debates
DROP TABLE IF EXISTS T_USUARIOS_GRUPOS_DEBATE;
DROP TABLE IF EXISTS T_VALORACIONES;
DROP TABLE IF EXISTS T_PROPUESTAS;
DROP TABLE IF EXISTS T_DEBATES;
DROP TABLE IF EXISTS T_GRUPOS_DEBATE;
-- Borrado de tablas generales de usuarios
DROP TABLE IF EXISTS T_USUARIOS;
DROP TABLE IF EXISTS T_TIPOS_USUARIO;
DROP TABLE IF EXISTS T_CONFIG;

-- DDL de tablas de usuarios con populación de usuarios ejemplo
CREATE TABLE IF NOT EXISTS T_USUARIOS (
  id int(6) unsigned zerofill AUTO_INCREMENT PRIMARY KEY, 
  nombre tinytext COLLATE utf8_general_ci NOT NULL,  
  apellidos tinytext COLLATE utf8_general_ci NOT NULL,  
  email varchar(35) COLLATE utf8_general_ci NOT NULL UNIQUE,  
  pass varchar(64) COLLATE utf8_general_ci NOT NULL,
  token varchar(40) NOT NULL DEFAULT 'abc',
  comentario tinytext COLLATE utf8_general_ci NOT NULL,
  tipo_usuario int(2) NOT NULL,
  estado int(1) NOT NULL DEFAULT 0,
  estado_pass int(1) NOT NULL DEFAULT 0,
  estado_val int(1) NOT NULL DEFAULT 0,
  id_insert int(6) unsigned zerofill NOT NULL DEFAULT 000001,
  KEY fk_tipo_usuario_idx (tipo_usuario),
  KEY fk_insert_usuario_idx (id_insert)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci COMMENT='Tabla donde se listan los usuarios registrados';

CREATE TABLE IF NOT EXISTS T_TIPOS_USUARIO (
  id int(1) NOT NULL,  
  tipo_usuario tinytext COLLATE utf8_general_ci NOT NULL,  
  PRIMARY KEY (id)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci COMMENT='Tabla donde se reflejan los tipos de usuario';

ALTER TABLE T_USUARIOS
  ADD CONSTRAINT fk_tipo_usuario_idx FOREIGN KEY (tipo_usuario) REFERENCES T_TIPOS_USUARIO (id) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT fk_insert_usuario_idx FOREIGN KEY (id_insert) REFERENCES T_USUARIOS (id) ON DELETE CASCADE ON UPDATE CASCADE;

INSERT INTO T_TIPOS_USUARIO (id,tipo_usuario) VALUES
(0,'ADMINISTRADOR'),
(2,'Facilitador'),
(7,'Participante'),
(9,'Invitado');  

INSERT INTO T_USUARIOS (nombre, apellidos, email, comentario,pass,tipo_usuario,estado,estado_pass,estado_val) VALUES
('Carlos', 'Rossique', 'crossique@yahoo.es', 'Creador','17aa6fda6f7b243e6f4c625e209cc76f9488cf05c1f534ad0b65d566e0a6f6df',0,1,1,1),
('Héctor', 'Barrón', 'directorTFM@es', 'Probar perfil admin','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',0,1,1,1),
('Facilitador', 'Random', 'facilitador@es', 'Probar perfil facilitador','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',2,1,1,1),
('Participante', 'Random1', 'participante1@es', 'Probar perfil participante','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',7,1,1,1),
('Participante', 'Random2', 'participante2@es', 'Probar perfil participante','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',7,1,1,1),
('Participante', 'Random3', 'participante3@es', 'Probar perfil participante','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',7,1,1,1),
('Participante', 'Random4', 'participante4@es', 'Probar perfil participante','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',7,1,1,1),
('Participante', 'Random5', 'participante5@es', 'Probar perfil participante','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',7,1,1,1),
('Participante', 'Random6', 'participante6@es', 'Probar perfil participante','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',7,1,1,1),
('Participante', 'Random7', 'participante7@es', 'Probar perfil participante','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',7,1,1,1),
('Participante', 'Random8', 'participante8@es', 'Probar perfil participante','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',7,1,1,1),
('Participante', 'Random9', 'participante9@es', 'Probar perfil participante','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',7,1,1,1),
('Invitado', 'Random', 'invitado@es', 'Probar perfil invitado','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',9,1,1,1);

-- DDL de T_CONFIG (uniregistro) con populación
DROP TABLE IF EXISTS T_CONFIG;
CREATE TABLE T_CONFIG (
  ROWID int(1) NOT NULL,
  titulo varchar(60) NOT NULL,
  explicacion text NOT NULL,
  email varchar(35) NOT NULL,
  fondo varchar(7) NOT NULL,
  fondoB varchar(7) NOT NULL,
  votaciones bit(1) NOT NULL,
  encuestas bit(1) NOT NULL,
  debates bit(1) NOT NULL,
  documentos bit(1) NOT NULL,
  ayuda bit(1) NOT NULL,
  usuario bit(1) NOT NULL,
  PRIMARY KEY (ROWID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla donde se listan los usuarios registrados';
-- populación
LOCK TABLES T_CONFIG WRITE;
INSERT INTO T_CONFIG VALUES (1,'ALICCIA 1.0','TFM de Carlos Rossique en el Máster IA en UNIR titulado \"Investigación y desarrollo de facilitadores de deliberación y decisión colectivas basado en IA". Es una herramienta de prueba y apoyo a nuevos acercamientos respecto a la facilitación apoyada en IA de decisiones colectivas elaboradas y consensuadas y servir como guía, muestra, laboratorio y plataforma para otros avances futuros en este campo.','crossique@yahoo.es','#0275d8','#f3f3ff','\0','\0','\0','','\0','\0');
UNLOCK TABLES;

-- DDL de T_GRUPOS_DEBATE con populación
DROP TABLE IF EXISTS T_GRUPOS_DEBATE;
CREATE TABLE T_GRUPOS_DEBATE (
  id_grupo_debate int(2) unsigned zerofill NOT NULL AUTO_INCREMENT,
  nombre_gd varchar(50) NOT NULL,
  id_fac int(6) unsigned zerofill NOT NULL DEFAULT '000001',
  PRIMARY KEY (id_grupo_debate),
  KEY fk_usgd_usfac_idx (id_fac),
  CONSTRAINT fk_usgd_usfac_idx FOREIGN KEY (id_fac) REFERENCES T_USUARIOS (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Tabla de grupos de debate';
-- populación
LOCK TABLES T_GRUPOS_DEBATE WRITE;
INSERT INTO T_GRUPOS_DEBATE VALUES (01,'ABIERTO',000001),(02,'Tecnoutopías',000001);
UNLOCK TABLES;

-- DDL de T_TIPOS_DEBATES con populacion
DROP TABLE IF EXISTS T_TIPOS_DEBATE;
CREATE TABLE T_TIPOS_DEBATE (
  id_tipo_debate char(2) NOT NULL,
  nombre_td varchar(40) NOT NULL,
  PRIMARY KEY (id_tipo_debate)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla de los tipos de debates';
-- populacion
LOCK TABLES T_TIPOS_DEBATE WRITE;
INSERT INTO T_TIPOS_DEBATE VALUES ('AP','Debate tipo Appgree'),('IW','Debate tipo IWarsMaps'),('VI','Debate tipo Vilfredo');
UNLOCK TABLES;

-- DDL de T_DEBATES con populacion
DROP TABLE IF EXISTS T_DEBATES;
CREATE TABLE T_DEBATES (
  id_debate int(3) unsigned zerofill NOT NULL AUTO_INCREMENT,
  nombre varchar(50) NOT NULL,
  resumen varchar(250) NOT NULL,
  texto_inicial text NOT NULL,
  imagen varchar(25) NOT NULL DEFAULT 'd_default.jpg',
  id_fac int(6) unsigned zerofill NOT NULL DEFAULT '000001',
  grupo int(2) unsigned zerofill NOT NULL DEFAULT '01',
  tipo_debate char(2) NOT NULL DEFAULT 'AP',
  estado char(2) NOT NULL DEFAULT '1P',
  generacion_act int(2) unsigned NOT NULL DEFAULT '1',
  estado_fase int(1) NOT NULL DEFAULT '0',
  texto_resultado text,
  PRIMARY KEY (id_debate),
  KEY fk_debate_gd_idx (grupo),
  KEY fk_tipo_debate_idx (tipo_debate),
  KEY fk_id_fac_idx (id_fac),
  CONSTRAINT fk_debate_gd_idx FOREIGN KEY (grupo) REFERENCES T_GRUPOS_DEBATE (id_grupo_debate),
  CONSTRAINT fk_id_fac_idx FOREIGN KEY (id_fac) REFERENCES T_USUARIOS (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_tipo_debate_idx FOREIGN KEY (tipo_debate) REFERENCES T_TIPOS_DEBATE (id_tipo_debate) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Tabla de debates';
-- populación
LOCK TABLES T_DEBATES WRITE;
INSERT INTO T_DEBATES VALUES (001,'Debate público de PRUEBA',' Texto propuesta inicial para un debate público de prueba ','Aquí iría el texto propuesta inicial, o pregunta de lanzamiento, para un debate público de prueba en el que podrá participar cualquier usuario. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem nam temporibus voluptates repellat voluptatum suscipit et asperiores omnis fugiat laborum iste, quasi facilis ab, sit quod magni. Rerum eos, iure.','d_default.jpg',000001,01,'AP','3A',1,0,NULL),(002,'Debate privado de PRUEBA',' Texto propuesta inicial para un debate privado de prueba ','Aquí iría el texto propuesta inicial, o pregunta de lanzamiento, para un debate privado de prueba en el que solo podrán participar los integrantes de un determinado grupo privado de debate','d_default.jpg',000001,01,'AP','3A',1,0,NULL);
UNLOCK TABLES;

-- DDL de T_PROPUESTAS con populacion
DROP TABLE IF EXISTS T_PROPUESTAS;
CREATE TABLE T_PROPUESTAS (
  id_propuesta int(4) unsigned zerofill NOT NULL AUTO_INCREMENT,
  texto_propuesta text NOT NULL,
  generacion int(2) DEFAULT '1',
  estado int(1) DEFAULT '1',
  hija_de int(4) unsigned zerofill DEFAULT NULL,
  valoracion double DEFAULT '0',
  user_nick varchar(50) DEFAULT NULL,
  id_debate int(3) unsigned zerofill NOT NULL,
  ip_term varchar(50) NOT NULL,
  fecha varchar(10) NOT NULL,
  PRIMARY KEY (id_propuesta),
  KEY fk_id_debate_idx (id_debate),
  KEY fk_hija_de_idx (hija_de),
  CONSTRAINT fk_hija_de_idx FOREIGN KEY (hija_de) REFERENCES T_PROPUESTAS (id_propuesta),
  CONSTRAINT fk_id_debate_idx FOREIGN KEY (id_debate) REFERENCES T_DEBATES (id_debate) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Tabla de las propuestas/respuestas';
-- populación
LOCK TABLES T_PROPUESTAS WRITE;
INSERT INTO T_PROPUESTAS VALUES (0001,'Propuesta de PRUEBA',1,1,NULL,0.5,'Kepler',001,'localhost','2022-08-08'),(0002,'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat blanditiis quibusdam nesciunt iure dignissimos minus ea commodi unde debitis quo, autem, pariatur, incidunt distinctio aliquam in cupiditate libero, similique non.',1,1,NULL,0.7,'Usuario_Random_1',001,'localhost','2022-08-08'),(0003,'Quaerat blanditiis quibusdam nesciunt iure dignissimos minus ea commodi unde debitis quo, autem, pariatur, incidunt distinctio aliquam in cupiditate libero, similique non.',1,1,0001,0.7,'Usuario_Random_2',001,'localhost','2022-08-08');
UNLOCK TABLES;

-- DDL de T_VALORACIONES con populacion
DROP TABLE IF EXISTS T_VALORACIONES;
CREATE TABLE T_VALORACIONES (
  id_debate int(3) unsigned zerofill NOT NULL,
  id_propuesta int(4) unsigned zerofill NOT NULL,
  email_nick varchar(50) NOT NULL,
  ip_term varchar(35) NOT NULL,
  fecha varchar(10) NOT NULL,
  valoracion int(11) NOT NULL,
  comentario varchar(256) DEFAULT NULL,
  PRIMARY KEY (id_debate,id_propuesta,email_nick),
  -- ojo mirar esa constraint unique
  UNIQUE KEY fk_val_unq_idx (id_propuesta,email_nick),
  CONSTRAINT fk_val_deb_idx FOREIGN KEY (id_debate) REFERENCES T_DEBATES (id_debate) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_val_res_idx FOREIGN KEY (id_propuesta) REFERENCES T_PROPUESTAS (id_propuesta) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla valoraciones de debate';
-- populación
LOCK TABLES T_VALORACIONES WRITE;
INSERT INTO T_VALORACIONES VALUES (001,0001,'usuario creador','localhost','20220807',2,'--- (valoración inicial del autor) ---'),(001,0001,'usuario random 1','localhost','2022-08-08',1,'comentario random'),(001,0001,'usuario random 2','localhost','2022-08-08',0,'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti accusantium magnam doloremque tempora, minus? Deleniti explicabo ex qui quidem deserunt magnam, repellendus, rem nemo doloribus esse iste. Sit, quaerat, eius.'),(001,0002,'usuario creador','localhost','20220807',2,'--- (valoración inicial del autor) ---');
UNLOCK TABLES;

-- DDL de T_USUARIOS_GRUPOS_DEBATE con populacion
DROP TABLE IF EXISTS T_USUARIOS_GRUPOS_DEBATE;
CREATE TABLE T_USUARIOS_GRUPOS_DEBATE (
  id_gd int(2) unsigned zerofill NOT NULL,
  id_usuario int(6) unsigned zerofill NOT NULL,
  PRIMARY KEY (id_gd,id_usuario),
  KEY fk_usgd_usuario_idx (id_usuario),
  CONSTRAINT fk_usgd_gd_idx FOREIGN KEY (id_gd) REFERENCES T_GRUPOS_DEBATE (id_grupo_debate) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_usgd_usuario_idx FOREIGN KEY (id_usuario) REFERENCES T_USUARIOS (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla de relación de grupos de debate';
-- populación
LOCK TABLES T_USUARIOS_GRUPOS_DEBATE WRITE;
INSERT INTO T_USUARIOS_GRUPOS_DEBATE VALUES (01,000001);
UNLOCK TABLES;

