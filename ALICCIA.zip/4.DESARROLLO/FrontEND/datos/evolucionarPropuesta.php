<?php
// include Database connection file
include_once("conexion.php");

// check request
if(isset($_POST['id']) && isset($_POST['id']) != "")
{
    $prop_id = $_POST['id'];
    $response = array();
    $query = "SELECT id_debate,generacion,texto_propuesta FROM T_PROPUESTAS WHERE id_propuesta = '$prop_id'";
    if (!$result = mysqli_query($con,$query)) {
        exit(mysqli_error($con));
    }
    $row = mysqli_fetch_assoc($result);
    $debate = $row['id_debate'];
    $gen_prop = $row['generacion'];
    $texto_propuesta = $row['texto_propuesta'];
    if(strlen($texto_propuesta)>50){$texto_propuesta=substr($texto_propuesta, 0, 49).' ...';}
    $query2 = "SELECT generacion_act, estado_fase,tipo_debate FROM T_DEBATES WHERE id_debate = '$debate'";
    if (!$result2 = mysqli_query($con,$query2)) {
        exit(mysqli_error($con));
    }
    $row2 = mysqli_fetch_assoc($result2);
    $genactual = $row2['generacion_act'];
    $estado_deb = $row2['estado_fase'];
    $tipo = $row2['tipo_debate'];

    if ($tipo =="AP"){
    $response['valor'] = "Un debate tipo Appgree solo permite propuestas en la primera fase \n\n";
    $response['valor'] .= "Pero puede insertar una nueva propuesta en esta generación, si aún no ha propuesto nada, en el espacio inferior de esta página donde dice 'Inserte una nueva propuesta o evolucione una anterior'";
    }
    else{
    $response['valor'] = "Una propuesta puede evolucionarse si la generacion actual del debate con algoritmo genético está activada por parte de su facilitador \n\n";

    if (($estado_deb==1)&&($gen_prop==$genactual-1)){
    $response['valor'] .= "En este caso particular puede usted evolucionar la propuesta en el espacio inferior de esta página donde dice 'Inserte una nueva propuesta o evolucione una anterior' indicando cual es el encabezado de la propuesta a que la nueva mejorará, en este caso:\n '".$texto_propuesta."'"; 
    }
    else{
    $response['valor'] .= "En este caso el debate aún no ha evolucionado de fase o bien la propuesta ha quedado desfasada o pertenece ya a la fase actual, por lo que no se puede evolucionar esta propuesta.\n\n"; 
    $response['valor'] .= "Pero puede insertar una nueva propuesta en esta generación, si aún no ha propuesto nada, en el espacio inferior de esta página donde dice 'Inserte una nueva propuesta o evolucione una anterior', o bien puede esperar a que avance el debate a la proxima generacion";    
    }
    }
    $response['tipo'] = $tipo;

    echo json_encode($response);
}
else
{
    $response['status'] = 200;
    $response['valor'] = "No se ha pasado el valor de la propuesta";
}