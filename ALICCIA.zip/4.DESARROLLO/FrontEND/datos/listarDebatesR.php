<?php include_once("conexion.php");?>

<!-- Modal para ver los detalles del Debate -->
<div class="modal fade" id="update_debate_modalR" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Detalles del debate</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label for="update_nombreR">Nombre</label>
                            <input type="text" id="update_nombreR" class="form-control" disabled>
                        </div>
                        <div class="form-group">
                            <label for="update_resumenR">Resumen</label>
                            <textarea rows="2" class="form-control" id="update_resumenR" disabled></textarea>
                        </div>
                        <div class="form-group">
                            <label for="update_textoR">Pregunta / Texto Inicial</label>
                            <textarea rows="9" class="form-control" id="update_textoR" disabled></textarea>
                        </div>                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="form-group">
                            <label for="update_tipoR">Tipo</label>
                            <input type="text" id="update_tipoR" class="form-control" disabled>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="form-group">
                            <label for="update_estadoR">Estado</label>
                            <input type="text" id="update_estadoR" class="form-control" disabled>
                        </div> 
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
                <input type="hidden" id="hidden_user_idR">
            </div>
        </div>
    </div>
</div>
<!-- Modal para ver las preguntas --- ¿Quitar? -->
<div class="modal fade" id="update_preguntas_modalR" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Preguntas del debate</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <p class= "pl-4"></p>

                    <div class="col-12">
                        <div class="form-group">
                            <textarea rows="12" class="form-control" id="update_preguntas" rows="25" disabled></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
                <input type="hidden" id="hidden_preguntas_id">
            </div>
        </div>
    </div>
</div>


<?php     // Diseño de tabla
   $data = '<table class="table table-bordered table-striped table-xtra-consensed">
                        <tr class="table-xtra-consensed">
                            <th width="40">IMAGEN</th>
                            <th width="100">Nombre</th>
                            <th width="200">Resumen</th>
                            <th>Pregunta / Texto inicial (Se muestra solo el comienzo ...)</th>
                            <th width="40">Grupo</th>
                            <th width="40">Tipo</th>
                            <th width="40">Estado</th>
                            <th width="40">Detalles</th>
                            <th width="40">Preguntas</th>
                            <th width="40">VER</th>
                        </tr>';
 
    if(!isset($_SESSION['email'])){$usuario=null;}else{$usuario = $_SESSION['email'];}
    $query = "

    SELECT id_debate,imagen,T_DEBATES.nombre,resumen,texto_inicial, tipo_debate, nombre_gd, T_DEBATES.estado FROM T_DEBATES INNER JOIN T_GRUPOS_DEBATE ON grupo=id_grupo_debate WHERE (T_DEBATES.estado='5C' AND grupo=01)
    UNION
    SELECT id_debate,imagen,T_DEBATES.nombre,resumen,texto_inicial, tipo_debate, nombre_gd, T_DEBATES.estado FROM T_DEBATES INNER JOIN T_GRUPOS_DEBATE ON grupo=id_grupo_debate INNER JOIN T_USUARIOS_GRUPOS_DEBATE ON id_grupo_debate= id_gd INNER JOIN T_USUARIOS ON id=id_usuario WHERE ( T_DEBATES.estado='3A' AND email= '$usuario')

    ";

    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
 
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
        $number = 1;
        while($row = mysqli_fetch_array($result))
        {
            
            $numenc=$row['id_debate'];
            while(strlen($numenc)<3){$numenc='0'.$numenc;}
            if($row['tipo_debate']=='AP'){$tipo="Appgree";}
            if($row['tipo_debate']=='IW'){$tipo="IWarsMap";}
            if($row['tipo_debate']=='VI'){$tipo="Vilfredo";}
            if($row['estado']=='5C'){$est="CERRADO";}
            $texto_ini = $row['texto_inicial'];
            if(strlen($texto_ini)>222){$texto_ini=substr($texto_ini, 0, 221).' ...';}            
            $data .= '<tr class="table-xtra-consensed">
                <td><img src="img/debates/'.$row["imagen"].'" height="50px" width="100px" class="d-inline-block align-middle align-center"></td>
                <td>'.$row['nombre'].'</td>
                <td>'.$row['resumen'].'</td>
                <td>'.$texto_ini.'</td>
                <td>'.$row['nombre_gd'].'</td>
                <td>'.$tipo.'</td>
                <td>'.$est.'</td>
                <td style="text-align:center;vertical-align:middle;">
                    <button onclick="DetallesDebateR('.$row['id_debate'].')" class="btn btn-dark btn-sm"><i class="fas fa-eye"></i></button>
                </td>
                <td style="text-align:center;vertical-align:middle;">
                    <button onclick="PreguntasDebateR('.$row['id_debate'].')" class="btn btn-warning btn-sm"><i class="fas fa-list"></i></button>
                </td>
                <td style="text-align:center;vertical-align:middle;">
                    <a type="button" class="btn btn-success btn-sm" href="resultadosD.php?debate='.$numenc.'"</a><i class="fas fa-poll"></i>
                </td>
            </tr>';
            $number++;
        }
    }
    else
    {
        // records now found 
        $data .= '<tr><td colspan="16">No hay debates cerrados visibles para este usuario</td></tr>';
    }
     $data .= '</table>';
     echo $data;
    mysqli_close($con);
?>