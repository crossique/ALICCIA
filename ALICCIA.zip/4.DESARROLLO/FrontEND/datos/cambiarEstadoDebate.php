<?php
include_once("conexion.php");
if(isset($_POST['id']))
{
    $id_deb = $_POST['id'];
    $query = "SELECT estado FROM T_DEBATES WHERE id_debate = '$id_deb'";
    $result = mysqli_query($con,$query);
    $row = mysqli_fetch_array($result);
    if($row['estado']=='1P'){$valor='2L';}
    if($row['estado']=='2L'){$valor='3A';}
    if($row['estado']=='3A'){$valor='4F';}
    if($row['estado']=='4F'){$valor='5C';}
    if($row['estado']=='5C'){$valor='1P';}

    $query = "UPDATE T_DEBATES SET estado = '$valor' WHERE id_debate = '$id_deb'";
    if (!$result = mysqli_query($con,$query)) {
        exit(mysqli_error($con)); echo "<script type='text/javascript'>alert('ERROR MYSQL');</script>";
    }else{echo "<script type='text/javascript'>alert('CAMBIADO');</script>";}
}
echo "<script type='text/javascript'>alert('HAY FALLOS');</script>";
?>