<?php
include_once("conexion.php");

// chequeo del control
if(isset($_POST['id']))
{
    // tomar los valores del formulario
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $comm = $_POST['comm'];
    $tipo = $_POST['tipo'];
    $estado = $_POST['estado'];

     // UPDATE. Hay que mirar si se ha cambiado o no la password
    if (strlen($pass)>0)
    {
    $pass = hash("sha256", $pass);
    $query = "UPDATE T_USUARIOS SET nombre = '$nombre', apellidos = '$apellidos', email = '$email', comentario = '$comm', tipo_usuario = '$tipo', estado = '$estado', pass= '$pass' WHERE id = '$id'";
    }
    else{
    $query = "UPDATE T_USUARIOS SET nombre = '$nombre', apellidos = '$apellidos', email = '$email', comentario = '$comm', tipo_usuario = '$tipo', estado = '$estado' WHERE id = '$id'";    
    }
    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
}