<?php
	if(isset($_POST['nombre']) && isset($_POST['resumen']))
	{
		include_once("conexion.php");
		// get values
		session_start(); 
		$nombre = $_POST['nombre'];
		$resumen = $_POST['resumen'];
		$texto = $_POST['texto'];
		$id_fac = $_SESSION['id'];
		$tipo = $_POST['tipo'];
		$filtro = $_POST['filtro'];
		$estado = $_POST['estado'];
		if (strlen($estado)==0){$estado='1P';}
		
    	$queryI = "INSERT INTO T_DEBATES (nombre, resumen, texto_inicial, tipo_debate, id_fac, grupo, estado) 
		VALUES('$nombre','$resumen', '$texto', '$tipo', '$id_fac', '$filtro', '$estado')";
		$a = mysqli_query($con,$queryI);

		if(!$a){echo "<script>alert('ERROR EN BD. No se inserta');</script>";
				echo "<script>alert(".$queryI.");</script>";}

	}
?>