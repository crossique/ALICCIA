<?php include_once("conexion.php");?>    

<!-- MODAL para update -->
<div class="modal fade" id="update_user_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <b><p>ACTUALIZAR USUARIO</p></b>
                <hr>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="update_nombre">Nombre</label>
                    <input type="text" id="update_nombre" placeholder="Nombre" class="form-control">
                </div>
                <div class="form-group">
                    <label for="update_apellidos">Apellido/s</label>
                    <input type="text" id="update_apellidos" placeholder="Apellidos" class="form-control">
                </div>
                <div class="form-group">
                    <label for="update_email">Email</label>
                    <input type="text" id="update_email" placeholder="Dirección de correo" readonly="readonly" class="form-control"/>
                </div>
                <div class="form-group">
                    <label for="update_pass">NUEVA Contraseña (dejar en blanco si no se cambia)</label>
                    <input type="text" id="update_pass" class="form-control">
                </div>
                <div class="form-group">
                    <label for="update_comm">Comentario</label>
                    <input type="text" id="update_comm"  placeholder="Comentario" class="form-control">
                </div>
                <div class="form-group">
                    <label for="update_tipo">Tipo</label>
                          <select name="update_tipo" id="update_tipo" style="width: 220px" class="w66 form-control border border-info rounded input-lg">
                          <option value=0>Administrador</option>
                          <option value=2>Facilitador</option>
                          <option value=7>Participante</option>
                          <option value=9>Invitado</option>
                          </select>
                </div>
                <div class="form-group">
                    <label for="update_estado">Estado</label>
                    <input type="text" id="update_estado" placeholder="Estado(0 ó 1)" class="form-control">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-warning" onclick="UpdateUser()"><i class='fas fa-pencil-alt'></i> Actualizar</button>
                <input type="hidden" id="hidden_user_id">
            </div>
        </div>
    </div>
</div>
<!-- FIN MODAL para update -->

<?php     // Diseño de tabla
   $data = '<table class="table table-bordered table-striped table-xtra-consensed">
                        <tr class="table-xtra-consensed">
                            <th width="40">ID</th>
                            <th>Nombre</th>
                            <th>Apellido(s)</th>
                            <th>Email</th>
                            <th>Comentario</th>
                            <th width="40">TipoU</th>
                            <th width="40">Estado</th>
                            <th width="40">Valida</th>
                            <th width="40">UPDATE</th>
                            <th width="40">DELETE</th>
                        </tr>';

    if (isset($_POST['filtro'])) {$filtro = $_POST['filtro'];}else{$filtro=7;}                        
 
    $query = "SELECT * FROM T_USUARIOS";

    if ($filtro==7){$condicion="";}
    if ($filtro==1){$condicion=" WHERE tipo_usuario = 0";}
    if ($filtro==4){$condicion=" WHERE tipo_usuario = 2";}    
    if ($filtro==5){$condicion=" WHERE tipo_usuario = 7";}

    $query .= $condicion;

    //$query .= " ORDER BY tipo_usuario, apellidos";
   
    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
 
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
        $number = 1;
        while($row = mysqli_fetch_array($result))
        {
            if ($row['tipo_usuario']==0){$tip="Administrador";}
            if ($row['tipo_usuario']==2){$tip="Facilitador";}
            if ($row['tipo_usuario']==7){$tip="Participante";}
            if ($row['tipo_usuario']==9){$tip="Invitado";}


            $data .= '<tr class="table-xtra-consensed">
            
                <td>'.$row['id'].'</td>
                <td>'.$row['nombre'].'</td>
                <td>'.$row['apellidos'].'</td>
                <td>'.$row['email'].'</td>
                <td>'.$row['comentario'].'</td>
                <td>'.$tip.'</td>
                <td style="text-align:center;">'.$row['estado'].'</td>
                <td style="text-align:center;">
                    <button onclick="ValidateUser('.IntVal($row['id']).')" class="btn btn-dark btn-sm"><i class="fas fa-thumbs-up"></i></button>
                </td>
                <td style="text-align:center;">
                    <button onclick="DetailsUser('.IntVal($row['id']).')" class="btn btn-warning btn-sm"><i class="fas fa-pencil-alt"></i></button>
                </td>
                <td style="text-align:center;">
                    <button onclick="DeleteUser('.IntVal($row['id']).')" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                </td>
            </tr>';
 
        }
    }
    else
    {
        // records now found 
        $data .= '<tr><td colspan="10">No hay registros</td></tr>';
    }
     $data .= '</table>';
     echo $data;
    mysqli_close($con);
?>