<?php
	if(isset($_POST['emailUGD']))
	{
		include_once("conexion.php");
		// get values 
		$emailUGD = $_POST['emailUGD'];
		$gd = $_POST['filtroGD'];
    	if (strlen($gd)<2){$gd='0'.$gd;}


    	$querySeleccion = "SELECT id FROM T_USUARIOS WHERE email = '$emailUGD'";

        $resultS = mysqli_query($con, $querySeleccion);
        while($rowS = mysqli_fetch_array($resultS)){
		$us = $rowS['id'];
        }	

    	$queryInsercion = "INSERT INTO T_USUARIOS_GRUPOS_DEBATE VALUES ($gd, $us)";
			$a = mysqli_query($con, $queryInsercion);

		if(!$a){echo "<script>alert('ERROR EN BD. Quizás la combinacion ya exista. No se inserta');</script>";
    			echo "<script>alert(".$queryInsercion.");</script>";}

	}
?>