<?php ?>
<!DOCTYPE html>
<html lang="es">
	<head>
<?php include 'base/head.php';?>
	</head>
	<body>
<?php include 'base/cabecera.php';?>
		<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->
		<div class="container-fluid pt-1">

		<div class="row">
		<h3 class= "px-3 pt-1"></h3>	
		</div>

		<div class="container-fluid">
			<h4>AUTENTICACIÓN</h4>
			<div class="row">


				<div class="col-md-5 col-sm-12 fondo2 pt-2 px-4">
				<h5>Esta página es para autenticación de administradores y facilitadores de debates. </h5>
				<h5>Tambíén necesita autenticarse si tiene permiso para participar en un debate privado.</h5>
				<h5>Como usuario invitado, no necesita registrase ni autenticarse en esta página.</h5>
				
				</div>

				<div class="col-md-1 col-sm-12 px-4 py-2">
				</div>

				<div class="col-md-3 col-sm-12 fondo1 py-2 px-4">
				<h5>USUARIOS REGISTRADOS</h5>
				<h6>Login</h6>
				<form role="form" name="login" method="post" action="base/login.php">
				<div class="form-group">
				Usuario: <input type="email" class="form-control" id="emailU" name="emailU" placeholder="Usuario" required onfocus="this.removeAttribute('readonly');" readonly>
				Contraseña: <input type="password" class="form-control" id="passwordU" name="passwordU" placeholder="Contraseña" required>
				ROL con el que entrará:
				<select name="tipoU" id="tipoU" class="form-control input-lg" required>
				<option value=null>(Escoja un ROL de acuerdo a su usuario)</option>
				<option value=0>Administrador</option>
				<option value=2>Facilitador</option>
				<option value=7>Participante</option>
				</select>
				</div>
				<button type="submit" class="btn btn-info" name="login" id="login">Acceder</button>
				</form>
				<hr/>

				</div>
				<div class="col-md-3 col-sm-12 fondo1 py-2 px-4">
				<h6 class = "pt-1">Cerrar Sesión</h6>
				<form role="form" name="logout" action="base/logout.php" method="post">
				<div class="form-group">
				</div>
				<button type="submit" class="btn btn-warning">Salir</button>
				</form>
				<hr/>

				</div>
			</div>
		</div>
			<div class="row px-2 pt-4 pb-3">
		</div>
	</div>
	<!-- EJECUCION EN CASO DE REGISTRO -->
	<?php
	include 'datos/conexion.php';
	$errors="";
	// ALTA - REGISTRO




	?>
		<!-- FIN CONTENIDO ESPECÍFICO -->
		<?php include 'base/pie.php';?>
	</body>
</html>