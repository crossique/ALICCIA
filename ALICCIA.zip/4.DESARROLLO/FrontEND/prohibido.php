<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
	</head>
	<body>
	   	<?php include 'base/cabecera.php';?>

	   	<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->
   	   <div class="container-fluid px-5 pt-2">

	    <div class="row">
	    	<h3 class= "px-3 pt-3"></h3>	
	    </div>

		<div class="row px-2 pt-2">
			<img src="img/general/prohibido.png" height="200px" width="200px" class="d-inline-block align-middle">	
		</div>

		<div class="row px-2 pt-2 pb-1">
		<h5><b>NO TIENE PERMISO PARA ENTRAR EN LA PÁGINA A LA QUE INTENTA ACCEDER</b></h5>
		</div>
		<div class="row px-2 ">
		<p>SIGA EXLUSIVAMENTE LOS ENLACES,Y SI ES ADMINISTRADOR O FACILITADOR HAGA LOGIN EN <a href="./alta_login.php">ESTA PAGINA</a></p>
		</div>
	  </div>
   	
		<!-- FIN CONTENIDO ESPECÍFICO -->

		<?php include 'base/pie.php';?>
   </body>
</html>