#!/usr/bin/env python3
import sys
import json
import itertools
import numpy as np
from io import BytesIO
import base64
import networkx as nx
import matplotlib.pyplot as plt

# --- Leer y decodificar entrada base64 desde argv ---
if len(sys.argv) != 2:
    print(json.dumps({'error': 'Uso: planificador.py <input_base64>'}))
    sys.exit(1)
input_b64 = sys.argv[1]
inp = json.loads(base64.b64decode(input_b64))
data = inp.get('data', {})
cl   = inp.get('closeness', {})

proposals = list(data.keys())
n = len(proposals)

# --- Construir matriz de cercanía NxN ---
cm = np.eye(n)
pairs = {
    '12': (0,1), '13': (0,2), '14': (0,3),
    '23': (1,2), '24': (1,3), '34': (2,3)
}
for key, (i, j) in pairs.items():
    if key in cl:
        cm[i, j] = cm[j, i] = float(cl[key])

# Parámetros de coste
epsilon = 0.01
alpha   = 1.0
beta    = 3.0

# --- Conjuntos originales de apoyos y rechazos ---
orig_sup = { p: set(u for u in lst if u.startswith('U')) for p, lst in data.items() }
orig_rec = { p: set('U'+e[1:] for e in lst if e.startswith('R')) for p, lst in data.items() }

# --- Simulación de una secuencia de transiciones ---
def simulate_sequence(sequence):
    dynamic = { p: set(orig_sup[p]) for p in proposals }
    transitions = []
    total_cost = 0.0
    for a, b in sequence:
        movers = dynamic[a] - dynamic[b]
        movedUaR = sum(1 for u in movers if u in orig_rec.get(b, set()))
        movedU   = len(movers) - movedUaR
        idx_a, idx_b = proposals.index(a), proposals.index(b)
        base = 1.0 / (cm[idx_a, idx_b] + epsilon)
        cost = alpha * base * movedU + beta * base * movedUaR
        # actualizar estado dinámico
        dynamic[b] |= movers
        dynamic[a] -= movers
        # solo registrar si hay movimiento
        if movedU + movedUaR > 0:
            transitions.append((f"{a}->{b}", cost, movedU, movedUaR))
        total_cost += cost
    return transitions, total_cost

# --- Generar rutas: serie, paralelo y mixta ---
routes = []
# 1) Serie: permutaciones completas (n nodos, n-1 transiciones)
for perm in itertools.permutations(proposals, n):
    seq = list(zip(perm, perm[1:]))
    trans, cost = simulate_sequence(seq)
    routes.append(('serie', seq, trans, cost))
# 2) Paralelo: cada propuesta destino, fuentes todas las demás
for dest in proposals:
    sources = [p for p in proposals if p != dest]
    seq = [(s, dest) for s in sources]
    trans, cost = simulate_sequence(seq)
    routes.append(('paralelo', seq, trans, cost))
# 3) Mixta: cadena de n-1 + salto de resto
for chain in itertools.permutations(proposals, n-1):
    rest = [p for p in proposals if p not in chain]
    end = chain[-1]
    for src in rest:
        seq = list(zip(chain, chain[1:])) + [(src, end)]
        trans, cost = simulate_sequence(seq)
        routes.append(('mixta', seq, trans, cost))

# --- Ordenar rutas por coste creciente ---
routes.sort(key=lambda x: x[3])
best_kind, best_seq, best_trans, best_cost = routes[0]

# --- Filtrar transiciones con coste > 0 para descripción y grafo ---
filtered_edges = [(edge, cost) for edge, cost, _, _ in best_trans if cost > 0]

# --- Generar descripción en lenguaje natural ---
if best_kind == 'serie':
    path = '→'.join(edge for edge, _ in filtered_edges)
    description = f"La ruta óptima integra {path} (coste {best_cost:.2f})."
elif best_kind == 'paralelo':
    desc_edges = ', '.join(edge for edge, _ in filtered_edges)
    description = f"La ruta óptima integra en paralelo {desc_edges} (coste {best_cost:.2f})."
else:
    desc_edges = ', '.join(edge for edge, _ in filtered_edges)
    description = f"Ruta mixta: {desc_edges} (coste {best_cost:.2f})."

# --- Construir grafo con solo aristas de coste > 0 ---
G = nx.DiGraph()
for edge, cost in filtered_edges:
    a, b = edge.split('->')
    G.add_edge(a, b, weight=cost)

# Posicionamiento según tipo de ruta
pos = {}
if best_kind == 'serie':
    nodes = [e.split('->')[0] for e, _ in filtered_edges] + [filtered_edges[-1][0].split('->')[1]]
    pos = {nodes[i]:(i,0) for i in range(len(nodes))}
elif best_kind == 'paralelo':
    sources = [e.split('->')[0] for e, _ in filtered_edges]
    for i, s in enumerate(sources):
        pos[s] = (0, len(sources)-1-i)
    dest = filtered_edges[0][0].split('->')[1]
    pos[dest] = (1, (len(sources)-1)/2)
else:  # mixta
    chain_nodes = []
    for e, _ in filtered_edges[:-1]:
        chain_nodes.append(e.split('->')[0])
    chain_nodes.append(filtered_edges[-2][0].split('->')[1])
    for i, n in enumerate(chain_nodes):
        pos[n] = (i,1)
    rest = filtered_edges[-1][0].split('->')[0]
    pos[rest] = (len(chain_nodes)-1,0)

# Dibujar y codificar gráfico
buf = BytesIO()
plt.figure(figsize=(6,4))
nx.draw(G, pos, with_labels=True, arrows=True, node_size=1800, node_color='#00AADD')
edgelabels = {(u, v): f"{d['weight']:.2f}" for u, v, d in G.edges(data=True)}
nx.draw_networkx_edge_labels(G, pos, edge_labels=edgelabels)
plt.axis('off')
plt.savefig(buf, format='png', bbox_inches='tight')
img_b64 = base64.b64encode(buf.getvalue()).decode()

# --- Preparar Top 10 rutas en bloque de texto ---
top10 = []
for kind, seq, trans, cost in routes[:10]:
    label = kind.upper()
    details = ', '.join(f"{e}(c={c:.2f},u={u},r={r})" for e, c, u, r in trans)
    top10.append(f"{label}: ({details})  Coste total: {cost:.2f}")

# --- Salida final en JSON ---
print(json.dumps({
    'description': description,
    'graph': img_b64,
    'top10': top10
}))
