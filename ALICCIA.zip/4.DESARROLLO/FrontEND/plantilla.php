<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
	</head>
	<body>
	   <?php include 'base/cabecera.php';?>
		<div class="container-fluid barra2 px-5 py-7 align-middle">
			<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->
			<!-- FIN CONTENIDO ESPECÍFICO -->	
		</div>
	<?php include 'base/pie.php';?>
   </body>
</html>