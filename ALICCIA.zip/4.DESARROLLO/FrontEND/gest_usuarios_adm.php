<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
     	<script src="js/script_usuarios.js"></script>
	</head>
	<body>
	   	<?php include 'base/cabecera.php';?>
	   	<?php include 'base/control_sesion_adm.php';?>

	   	<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->
	<div class="container-fluid px-5">
		<div class="row pt-3">
			<div class="col-md-12">
			<h5><i class="fas fa-user-friends color:#0077AA"></i> Gestión de usuarios</h5>
			</div>
		</div>
		<div class="container-fluid">
    <div class="btn-group">   
      <a type="button" class="btn btn-success btn-sm text-white" data-target="#add_new_record_modal" data-toggle="modal"><i class='fas fa-share'></i> Añadir Usuario Manualmente </a>
    </div>
    <br>
    <form>
    <div class="btn-group">   
      <a type="button" class="btn btn-info btn-sm text-white" onclick="SelectUsers()"> <i class='fas fa-filter'></i> Filtrar </a>
    </div>
    <div class="btn-group">   
      <select name="filtro" id="filtro" style="width: 220px" class="w66 form-control border border-info rounded input-lg" value=7>
      <option value=7>Todos los usuarios</option>
      <option value=1>Administradores</option>
      <option value=4>Facilitadores</option>
      <option value=5>Participantes</option>
      </select>
    </div>
    </form>
</div>
		<div class="row pt-2">
			<div class="col-md-12">
			<div class="records_content"></div>
			</div>
		</div>
	</div>	
	<!-- Modal -->
	<div class="modal fade" id="add_new_record_modal" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
					<h4 class="modal-title" id="myModalLabel">Añadir Usuario</h4>
				</div>
				<div class="modal-body">
				 <div class="form-group">
			      Nombre: <input type="text" class="form-control" id="nombre" placeholder="Nombre">
			      Apellido(s):<input type="text" class="form-control" id="apellidos" placeholder="Apellidos">
			      Email: <input type="email" class="form-control" id="email" placeholder="email">
			      Tipo: <select name="tipo" id="tipo" style="width: 250px" class="w66 form-control border border-info rounded input-lg" value=9>
                          <option value=0>Administrador</option>
                          <option value=2>Facilitador</option>
                          <option value=7>Participante</option>
                          <option value=9>Invitado</option>
                          </select>
			      Comentario:<input type="text" class="form-control" id="comm" placeholder="(objetivo, interés)">
			      Contraseña: <input type="password" class="form-control" id="pass" placeholder="Contraseña">
			      Confirmar contraseña: <input type="password" class="form-control" id="pass2" placeholder="Contraseña">
			     </div>
				</div>	
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-success " onclick="InsertUser()"><span class="fas fa-share"></span> Insertar</button>
				</div>
			</div>
		</div>
	</div>

	</div>
		<!-- FIN CONTENIDO ESPECÍFICO -->
		<?php include 'base/pie.php';?>
		<script>
		$(document).ready(function () {
    	SelectUsers(); // llama a la función para refrescar el listado de usuarios
		});</script>
   </body>
</html>