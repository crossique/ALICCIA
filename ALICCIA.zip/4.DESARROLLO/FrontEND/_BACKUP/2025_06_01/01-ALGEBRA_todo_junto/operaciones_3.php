<?php
$resultado = '';
$log = '';

function llamarOpenAI($prompt, $apiKey) {
    $data = [
        "model" => "gpt-4o",
        "messages" => [["role" => "user", "content" => $prompt]],
        "temperature" => 0.2
    ];
    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            "Authorization: Bearer $apiKey"
        ],
        CURLOPT_POSTFIELDS => json_encode($data)
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    $json = json_decode($response, true);
    return trim($json['choices'][0]['message']['content'] ?? 'Sin respuesta');
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $apiKey = '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'; // Sustituye con tu clave real
    $tema = trim($_POST['tema']);
    $p1 = trim($_POST['propuestaA']);
    $p2 = trim($_POST['propuestaB']);
    $operacion = $_POST['operacion'] ?? '';
    $chequear = $_POST['chequear'] ?? '';

    if ($chequear == 'p1') {
        $wordCount = str_word_count(strip_tags($p1));
        if ($wordCount < 50) {
            $log = "Propuesta demasiado corta";
        } elseif ($wordCount > 300) {
            $log = "Propuesta demasiado extensa";
        } else {
            $prompt = <<<EOT
Evalúa si esta propuesta está relacionada con el siguiente tema: "$tema".

Propuesta: "$p1"

Si no guarda relación temática, responde: "Propuesta sin relación con el tema/problema".
Si sí guarda relación temática, responde: "Propuesta válida".
Solo responde con una de esas dos frases exactas.
EOT;
            $log = llamarOpenAI($prompt, $apiKey);
        }
    } elseif ($chequear == 'p2') {
        $wordCount = str_word_count(strip_tags($p2));
        if ($wordCount < 50) {
            $log = "Propuesta demasiado corta";
        } elseif ($wordCount > 300) {
            $log = "Propuesta demasiado extensa";
        } else {
            $prompt = <<<EOT
Evalúa si esta propuesta está relacionada con el siguiente tema: "$tema".

Propuesta: "$p2"

Si no guarda relación temática, responde: "Propuesta sin relación con el tema/problema".
Si sí guarda relación temática, responde: "Propuesta válida".
Solo responde con una de esas dos frases exactas.
EOT;
            $log = llamarOpenAI($prompt, $apiKey);
        }
    } else {
        switch ($operacion) {
            case 'union':
                $prompt = "Fusiona estas dos propuestas de forma coherente:\n\nTema: \"$tema\"\nPropuesta A: \"$p1\"\nPropuesta B: \"$p2\"";
                $resultado = llamarOpenAI($prompt, $apiKey);
                break;
            case 'interseccion':
                $prompt = "Extrae solo los elementos comunes entre estas dos propuestas:\n\nTema: \"$tema\"\nPropuesta A: \"$p1\"\nPropuesta B: \"$p2\"";
                $resultado = llamarOpenAI($prompt, $apiKey);
                break;
            case 'cercania':
                $prompt = "Evalúa la similitud entre estas dos propuestas en relación al tema \"$tema\". Devuelve solo un número entre 0 y 1.\n\nPropuesta A: \"$p1\"\nPropuesta B: \"$p2\"";
                $log = llamarOpenAI($prompt, $apiKey);
                break;
            case 'simplificar_p1':
                $prompt = "Simplifica esta propuesta sin perder su sentido:\n\nTema: \"$tema\"\nPropuesta A: \"$p1\"";
                $resultado = llamarOpenAI($prompt, $apiKey);
                break;
            case 'simplificar_p2':
                $prompt = "Simplifica esta propuesta sin perder su sentido:\n\nTema: \"$tema\"\nPropuesta B: \"$p2\"";
                $resultado = llamarOpenAI($prompt, $apiKey);
                break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<?php include 'base/head.php';?>
</head>
<body>
<?php include 'base/cabecera.php';?>

<div class="container mt-4">
    <h2 class="mb-4">Operaciones de Álgebra Deliberativa</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="tema" class="form-label">Tema / Problema</label>
			<textarea class="form-control" name="tema" rows="3" required><?= htmlspecialchars($_POST['tema'] ?? '') ?></textarea>
        </div>

        <div class="mb-3">
            <label for="propuestaA" class="form-label">Propuesta A</label>
            <textarea class="form-control" name="propuestaA" rows="3" required><?= htmlspecialchars($_POST['propuestaA'] ?? '') ?></textarea>
            <button name="chequear" value="p1" class="btn btn-sm btn-outline-secondary mt-1">Chequear validez</button>
        </div>

        <div class="mb-3">
            <label for="propuestaB" class="form-label">Propuesta B</label>
            <textarea class="form-control" name="propuestaB" rows="3" required><?= htmlspecialchars($_POST['propuestaB'] ?? '') ?></textarea>
            <button name="chequear" value="p2" class="btn btn-sm btn-outline-secondary mt-1">Chequear validez</button>
        </div>

        <div class="mb-3 d-flex align-items-end">
            <div class="flex-grow-1 me-2">
                <label for="operacion" class="form-label">Operación</label>
                <select class="form-select" name="operacion" required>
                    <option value="union" <?= ($operacion == 'union') ? 'selected' : '' ?>>Unión</option>
                    <option value="interseccion" <?= ($operacion == 'interseccion') ? 'selected' : '' ?>>Intersección</option>
                    <option value="cercania" <?= ($operacion == 'cercania') ? 'selected' : '' ?>>Cercanía</option>
                    <option value="simplificar_p1" <?= ($operacion == 'simplificar_p1') ? 'selected' : '' ?>>Simplificar Propuesta A</option>
                    <option value="simplificar_p2" <?= ($operacion == 'simplificar_p2') ? 'selected' : '' ?>>Simplificar Propuesta B</option>
                </select>
            </div>
            <div>
                <label class="form-label d-block invisible">Ejecutar</label>
                <button type="submit" class="btn btn-primary">Ejecutar operación</button>
            </div>
        </div>

        <div class="mb-3">
            <label for="resultado" class="form-label">Propuesta resultado</label>
            <textarea class="form-control" name="resultado" rows="3" readonly><?= htmlspecialchars($resultado) ?></textarea>
        </div>

        <div class="mb-3">
            <label for="log" class="form-label">Salida de consola</label>
            <textarea class="form-control" name="log" rows="2" readonly><?= htmlspecialchars($log) ?></textarea>
        </div>
    </form>
</div>

<?php include 'base/pie.php';?>
</body>
</html>
