import sys
import io
import os
import json
import re
from datetime import datetime
from dotenv import load_dotenv
import openai

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

LOG_FILE = os.path.join(os.path.dirname(__file__), "debug_py.log")

def log(msg):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now()} | {msg}\n")

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
openai.api_key = api_key

if not api_key:
    log("[ERROR] Clave de API no disponible")
    print("[ERROR: clave OpenAI no disponible]")
    sys.exit(1)

try:
    raw_input = sys.stdin.read()
    log(f"[DEBUG] JSON recibido:\n{raw_input}")
    input_data = json.loads(raw_input)
except Exception as e:
    log(f"[ERROR] JSON inválido: {e}")
    print("[ERROR: entrada JSON no válida]")
    sys.exit(1)

tema = input_data.get("tema", "").strip()
p1 = input_data.get("p1", "").strip()
p2 = input_data.get("p2", "").strip()
op = input_data.get("op", "").strip()

if not tema or not op:
    log("[ERROR] Faltan datos")
    print("[ERROR: datos incompletos]")
    sys.exit(1)

log(f"[OK] Operación solicitada: {op}")

# PROMPTS según operación
if op == "union":
    prompt = f"""Fusiona estas dos propuestas en una sola, sin encabezados ni listas:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """
elif op == "interseccion":
    prompt = f"""Redacta una única propuesta que represente las ideas comunes entre las siguientes dos. No uses listas ni encabezados:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """
elif op == "cercania":
    prompt = f"""Evalúa la similitud entre estas propuestas sobre el tema "{tema}". Responde solo con un número entre 0 y 1:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """
elif op == "simplificar_p1":
    prompt = f"""Simplifica esta propuesta sin perder su sentido. Solo la propuesta simplificada:
{p1}"""
elif op == "simplificar_p2":
    prompt = f"""Simplifica esta propuesta sin perder su sentido. Solo la propuesta simplificada:
{p2}"""
elif op == "chequear_p1":
    prompt = f"""Responde solo con una de estas frases:
- "Propuesta válida"
- "Propuesta sin relación con el tema/problema"
Tema: {tema}
Propuesta: {p1}"""
elif op == "chequear_p2":
    prompt = f"""Responde solo con una de estas frases:
- "Propuesta válida"
- "Propuesta sin relación con el tema/problema"
Tema: {tema}
Propuesta: {p2}"""
else:
    log(f"[ERROR] Operación desconocida: {op}")
    print(f"[ERROR: operación desconocida: {op}]")
    sys.exit(1)

# Llamar a OpenAI
try:
    respuesta = openai.ChatCompletion.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2
    )
    contenido = respuesta.choices[0].message.content.strip()

    if op == "cercania":
        match = re.search(r"\b(0(?:\.\d+)?|1(?:\.0)?)\b", contenido)
        contenido = match.group(1) if match else "[ERROR: no se encontró un número]"

    log(f"[OK] Respuesta generada ({len(contenido)} caracteres)")
    print(contenido)

except Exception as e:
    log(f"[ERROR] OpenAI falló: {e}")
    print(f"[ERROR: fallo en llamada OpenAI] {e}")
    sys.exit(1)

