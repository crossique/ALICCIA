<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$resultado = '';
$log = '';
$tema = '';
$p1 = '';
$p2 = '';
$operacion = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tema = $_POST['tema'] ?? '';
    $p1 = $_POST['propuestaA'] ?? '';
    $p2 = $_POST['propuestaB'] ?? '';
    $operacion = $_POST['operacion'] ?? '';
    $chequear = $_POST['chequear'] ?? '';

    // Mapear chequear p1/p2 a operaciones válidas
    $op = $chequear === "p1" ? "chequear_p1" : ($chequear === "p2" ? "chequear_p2" : $operacion);

    $data = json_encode([
        "tema" => $tema,
        "p1" => $p1,
        "p2" => $p2,
        "op" => $op
    ], JSON_UNESCAPED_UNICODE);

    // Guardar entrada temporal
    file_put_contents("py/temp_input.json", $data);

    // Ejecutar script Python con entorno correcto
    $salida = shell_exec("/usr/src/Python-3.9.18/venv_openai/bin/python3 py/operaciones_4.py < py/temp_input.json 2>&1");

    // Guardar traza de salida
    file_put_contents("debug.log", "OP: $op\nENTRADA:\n$data\nSALIDA:\n$salida\n", FILE_APPEND);

    if ($chequear) {
        $log = trim($salida ?: '[ERROR: script no devolvió salida]');
    } else {
        $resultado = trim($salida ?: '[ERROR: script no devolvió salida]');
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<?php include 'base/head.php'; ?>
</head>
<body>
<?php include 'base/cabecera.php'; ?>

<div class="container mt-4">
    <h2>Operaciones de Álgebra Deliberativa (con LLM)</h2>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Tema / Problema</label>
            <input type="text" class="form-control" name="tema" required value="<?= htmlspecialchars($tema) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Propuesta A</label>
            <textarea name="propuestaA" class="form-control" rows="3" required><?= htmlspecialchars($p1) ?></textarea>
            <button name="chequear" value="p1" class="btn btn-sm btn-outline-secondary mt-1">Chequear validez</button>
        </div>

        <div class="mb-3">
            <label class="form-label">Propuesta B</label>
            <textarea name="propuestaB" class="form-control" rows="3" required><?= htmlspecialchars($p2) ?></textarea>
            <button name="chequear" value="p2" class="btn btn-sm btn-outline-secondary mt-1">Chequear validez</button>
        </div>

        <div class="mb-3 d-flex align-items-end">
            <div class="flex-grow-1 me-2">
                <label class="form-label">Operación</label>
                <select name="operacion" class="form-select" required>
                    <option value="union" <?= $operacion === 'union' ? 'selected' : '' ?>>Unión</option>
                    <option value="interseccion" <?= $operacion === 'interseccion' ? 'selected' : '' ?>>Intersección</option>
                    <option value="cercania" <?= $operacion === 'cercania' ? 'selected' : '' ?>>Cercanía</option>
                    <option value="simplificar_p1" <?= $operacion === 'simplificar_p1' ? 'selected' : '' ?>>Simplificar Propuesta A</option>
                    <option value="simplificar_p2" <?= $operacion === 'simplificar_p2' ? 'selected' : '' ?>>Simplificar Propuesta B</option>
                </select>
            </div>
            <div>
                <label class="form-label d-block invisible">Ejecutar</label>
                <button type="submit" class="btn btn-primary">Ejecutar operación</button>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Propuesta resultado</label>
            <textarea class="form-control" rows="3" readonly><?= htmlspecialchars($resultado) ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Salida de consola</label>
            <textarea class="form-control" rows="2" readonly><?= htmlspecialchars($log) ?></textarea>
        </div>
    </form>
</div>

<?php include 'base/pie.php'; ?>
</body>
</html>
