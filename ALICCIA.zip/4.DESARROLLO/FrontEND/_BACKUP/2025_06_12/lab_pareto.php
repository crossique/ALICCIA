<?php
/* --------------------------------------------------------------
   pareto.php – 9×9 · Drag & Drop · con botón Reset
   -------------------------------------------------------------- */
$usuarios   = ["U1","U2","U3","U4","U5","U6","U7","U8","U9"];
$propuestas = [
    "Propuesta1","Propuesta2","Propuesta3",
    "Propuesta4","Propuesta5","Propuesta6",
    "Propuesta7","Propuesta8","Propuesta9"
];

$pareto = $grafico = $error = null;

/* ---------- Procesar formulario ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datos = [];
    foreach ($propuestas as $p) {
        $datos[$p] = $_POST[$p] ?? [];
    }

    /* Ruta a python y script */
    $b64    = base64_encode(json_encode($datos));
    $python = '/usr/bin/python3';                       // ajusta si es distinto
    $script = __DIR__ . '/py/pareto.py';

    putenv('PATH=/usr/bin:' . getenv('PATH'));         // asegura que dot esté en PATH

    $cmd   = escapeshellarg($python) . ' ' .
             escapeshellarg($script) . ' ' .
             escapeshellarg($b64) . ' 2>&1';

    $out   = shell_exec($cmd);
    if ($out && ($res = json_decode($out, true))) {
        $pareto  = $res['pareto'];
        $grafico = $res['image'];
    } else {
        $error = "Error al ejecutar py/pareto.py:<br><pre>" .
                  htmlspecialchars($cmd . PHP_EOL . $out) . "</pre>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include 'base/head.php'; ?>
    <style>
        /* ---------- Grid 3×3 ó 1×9 ---------- */
        .propuesta-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;
        }
        @media (min-width: 992px) {
            .propuesta-grid { grid-template-columns: repeat(9, 1fr); }
        }
        /* ---------- Cajas y badges ---------- */
        .proposal-box {
            min-height: 90px;
            border: 2px dashed #ced4da;
            border-radius: .5rem;
            padding: .4rem;
            background: #f8f9fa;
        }
        .proposal-box.drag-over { background: #e2e6ea; }
        .user-badge    { cursor: move; font-size: 1.15rem; }
        .support-badge { cursor: pointer; font-size: 1.25rem; } /* más grande */
    </style>
</head>
<body>
<?php include 'base/cabecera.php'; ?>

<div class="container-fluid barra2 px-5 py-7">
    <h1 class="mb-4">Asignación de apoyos (Drag &amp; Drop)</h1>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" id="paretoForm">
        <!-- Cuadrícula de propuestas -->
        <div class="propuesta-grid my-3">
            <?php foreach ($propuestas as $p): ?>
                <div>
                    <h5 class="text-center mb-1"><?= $p ?></h5>
                    <div class="proposal-box" data-propuesta="<?= $p ?>">
                        <?php
                        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST[$p])) {
                            foreach ($_POST[$p] as $u) {
                                echo "<span class='badge rounded-pill text-bg-success me-1 mb-1 support-badge'
                                           data-user='{$u}'>{$u} ×</span>";
                                echo "<input type='hidden' name='{$p}[]' value='{$u}'>";
                            }
                        }
                        ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Paleta de usuarios -->
        <div class="text-center mt-4">
            <h4>Usuarios</h4>
            <div id="userPalette" class="d-flex flex-wrap gap-2 justify-content-center fs-5">
                <?php foreach ($usuarios as $u): ?>
                    <span class="badge rounded-pill text-bg-primary user-badge"
                          draggable="true" data-user="<?= $u ?>"><?= $u ?></span>
                <?php endforeach; ?>
            </div>
            <p class="mt-2 text-muted">
                Arrastra usuarios a las propuestas que apoyen.
                Pulsa en un badge verde para quitarlo.
            </p>
        </div>

        <button class="btn btn-primary mt-4" type="submit">Calcular Frente de Pareto</button>
        <button type="button" id="resetBtn" class="btn btn-secondary mt-4 ms-2">Resetear apoyos</button>
    </form>

    <?php if ($pareto !== null): ?>
        <hr class="my-5">
        <h2>Resultado</h2>
        <p><strong>Propuestas en el Frente de Pareto:</strong>
           <?= empty($pareto) ? 'Ninguna' : implode(', ', $pareto) ?></p>
        <?php if (is_file($grafico)): ?>
            <img src="<?= htmlspecialchars($grafico) ?>?v=<?= time() ?>"
                 class="img-fluid border" alt="Grafo de dominación">
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php include 'base/pie.php'; ?>

<script>
/* ---------- Drag & Drop ---------- */
(() => {
    /* util: habilitar borrado */
    function attachDelete(span) {
        span.addEventListener('click', () => {
            const next = span.nextElementSibling;
            if (next && next.tagName === 'INPUT') next.remove();
            span.remove();
        });
    }

    /* Drag start */
    document.querySelectorAll('.user-badge').forEach(badge =>
        badge.addEventListener('dragstart',
            e => e.dataTransfer.setData('text/plain', badge.dataset.user)));

    /* añado badge verde + input */
    function addSupport(box, user) {
        const span = document.createElement('span');
        span.className = 'badge rounded-pill text-bg-success me-1 mb-1 support-badge';
        span.dataset.user = user;
        span.textContent  = user + ' ×';
        attachDelete(span);

        const input = document.createElement('input');
        input.type  = 'hidden';
        input.name  = box.dataset.propuesta + '[]';
        input.value = user;

        box.appendChild(span);
        box.appendChild(input);
    }

    /* eventos en cada caja */
    document.querySelectorAll('.proposal-box').forEach(box => {
        box.addEventListener('dragover',  e => { e.preventDefault(); box.classList.add('drag-over'); });
        box.addEventListener('dragleave', () => box.classList.remove('drag-over'));
        box.addEventListener('drop',      e => {
            e.preventDefault(); box.classList.remove('drag-over');
            const user = e.dataTransfer.getData('text/plain');
            if (user && !box.querySelector(`[data-user=\"${user}\"]`))
                addSupport(box, user);
        });
    });

    /* reactivar borrado en badges reconstruidos por PHP */
    document.querySelectorAll('.support-badge').forEach(attachDelete);

    /* botón Reset */
    document.getElementById('resetBtn').addEventListener('click', () => {
        document.querySelectorAll('.support-badge').forEach(b => b.remove());
        document.querySelectorAll('.proposal-box input[type="hidden"]').forEach(i => i.remove());
    });
})();
</script>
</body>
</html>
