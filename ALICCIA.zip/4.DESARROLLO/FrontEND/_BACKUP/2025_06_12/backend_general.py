# -*- coding: utf-8 -*-
import sys
import json
from algebra_client_4 import resolver_operacion

try:
    entrada = sys.argv[1]
    datos = json.loads(entrada)

    operacion = datos.get("operacion")
    p1 = datos.get("p1", "").strip()
    p2 = datos.get("p2", "").strip()
    valoracion = datos.get("valoracion", "").strip()
    tema = datos.get("tema", "").strip()

    resultado = resolver_operacion(
        operacion=operacion,
        p1=p1,
        p2=p2,
        valoracion=valoracion,
        tema=tema
    )

    print(json.dumps(resultado))

except Exception as e:
    print(json.dumps({
        "resultado": "",
        "consola": f"Error al procesar: {str(e)}"
    }))
