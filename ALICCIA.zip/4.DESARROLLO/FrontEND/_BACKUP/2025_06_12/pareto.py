#!/usr/bin/env python3
"""
pareto.py  · 9×9  ·  layout por niveles + líneas punteadas de equivalencia
Uso: python3 py/pareto.py <base64_json>
Salida JSON: {"pareto":[...], "image":"pareto.png"}
"""
import sys, json, base64, warnings, itertools
from pathlib import Path
import networkx as nx
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")        # silenciar avisos de matplotlib

# ––– 1. Leer argumento ——————————————————————————
if len(sys.argv) != 2:
    sys.exit('{"error":"Falta argumento base64"}')

try:
    data = json.loads(base64.b64decode(sys.argv[1]).decode())
except Exception as e:
    sys.exit(json.dumps({"error": f"JSON inválido: {e}"}))

# Filtrar propuestas sin apoyos  (requisito C)
propuestas = {k: set(v) for k, v in data.items() if v}

if not propuestas:
    sys.exit(json.dumps({"pareto": [], "image": ""}))

# ––– 2. Aristas de dominación y equivalencia ————————————
G = nx.DiGraph()
G.add_nodes_from(propuestas.keys())

domination_edges = []
equiv_edges      = []        # líneas punteadas azules

for a, b in itertools.combinations(propuestas, 2):
    setA, setB = propuestas[a], propuestas[b]
    if setA == setB:
        equiv_edges.append((a, b))
    elif setB.issubset(setA):
        domination_edges.append((a, b))
    elif setA.issubset(setB):
        domination_edges.append((b, a))

G.add_edges_from(domination_edges)

# ––– 3. Frente de Pareto ——————————————————————————
pareto = [n for n in G if G.in_degree(n) == 0]

# ––– 4. Calcular “profundidad” (nivel) para layout ————————
depth = {}

def nivel(n):
    if n in depth:
        return depth[n]
    preds = list(G.predecessors(n))
    depth[n] = 0 if not preds else max(nivel(p) for p in preds) + 1
    return depth[n]

for nodo in G:
    nivel(nodo)

# Asegurar mismo nivel para propuestas equivalentes
for a, b in equiv_edges:
    mismo = min(depth[a], depth[b])
    depth[a] = depth[b] = mismo

# ––– 5. Coordenadas manuales —————————————————————————
orden = sorted(G)                          # para estabilidad
x_step = 1 / max(len(orden) - 1, 1)
pos = {n: (i * x_step, -depth[n]) for i, n in enumerate(orden)}

# ––– 6. Dibujar ——————————————————————————————————————
node_colors = ["lightgreen" if n in pareto else "lightgray" for n in G]

plt.figure(figsize=(4, 3))
nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=2500)
nx.draw_networkx_labels(G, pos, font_size=9)

# Aristas de dominación (negras con flecha)
nx.draw_networkx_edges(G, pos, edgelist=domination_edges,
                       arrows=True, arrowstyle='-|>', edge_color='black')

# Líneas de equivalencia (azul punteado, sin flecha) – requisito B
if equiv_edges:
    nx.draw_networkx_edges(G, pos, edgelist=equiv_edges,
                           arrows=False, style='dashed', edge_color='blue')

plt.title("Dominación de propuestas (verde = Pareto)")
plt.axis("off")
plt.margins(0.30)             # requisito D: margen alrededor
plt.tight_layout()

# ––– 7. Guardar PNG y salida JSON ————————————————
output = Path(__file__).resolve().parent.parent / "pareto.png"
plt.savefig(output, dpi=150)
plt.close()

print(json.dumps({"pareto": pareto, "image": output.name}))
