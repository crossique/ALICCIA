<?php include 'base/head.php'; ?>
<body>
<?php include 'base/cabecera.php'; ?>
<div class="container mt-4">
  <h2>Álgebra de Propuestas - Operaciones</h2>

  <?php
    $tema = $_POST['tema'] ?? '';
    $p1 = $_POST['p1'] ?? '';
    $p2 = $_POST['p2'] ?? '';
    $valoracion = $_POST['valoracion'] ?? '';
    $op = $_POST['operacion'] ?? '';
    $resultado = "";
    $consola = "";

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      if (isset($_POST['intercambiar'])) {
        $tmp = $p1;
        $p1 = $p2;
        $p2 = $tmp;
      }

      if (isset($_POST['ejecutar'])) {
        function contar_palabras($texto) {
          return str_word_count(strip_tags($texto));
        }

        $errores = [];

        if (in_array($op, ['UNION', 'INTERSECCION', 'CONSENSO', 'CERCANIA'])) {
          $p1_len = contar_palabras($p1);
          $p2_len = contar_palabras($p2);

          if (empty(trim($p1))) $errores[] = "Propuesta A está vacía.";
          elseif ($p1_len < 50) $errores[] = "Propuesta A es demasiado corta.";
          elseif ($p1_len > 300) $errores[] = "Propuesta A es demasiado larga.";

          if (empty(trim($p2))) $errores[] = "Propuesta B está vacía.";
          elseif ($p2_len < 50) $errores[] = "Propuesta B es demasiado corta.";
          elseif ($p2_len > 300) $errores[] = "Propuesta B es demasiado larga.";
        }

        elseif (in_array($op, ['ENMIENDA_PLUS', 'ENMIENDA_MINUS', 'SIMPLIFICAR', 'GENERALIZAR'])) {
          $p1_len = contar_palabras($p1);
          if (empty(trim($p1))) $errores[] = "Propuesta A está vacía.";
          elseif ($p1_len < 50) $errores[] = "Propuesta A es demasiado corta.";
          elseif ($p1_len > 300) $errores[] = "Propuesta A es demasiado larga.";

          if (in_array($op, ['ENMIENDA_PLUS', 'ENMIENDA_MINUS'])) {
            $val_len = contar_palabras($valoracion);
            if (empty(trim($valoracion))) $errores[] = "La valoración está vacía.";
            elseif ($val_len < 25) $errores[] = "La valoración es demasiado corta.";
            elseif ($val_len > 100) $errores[] = "La valoración es demasiado larga.";
          }
        }

        if (!empty($errores)) {
          $consola = implode("<br>", $errores);
        } else {
          $data = [
            "tema" => $tema,
            "p1" => $p1,
            "p2" => $p2,
            "valoracion" => $valoracion,
            "operacion" => $op
          ];
          $json_args = escapeshellarg(json_encode($data));
          $comando = "/usr/local/bin/python3.9-tfm py/backend_general.py $json_args 2>&1";
          $salida = shell_exec($comando);

          $json = json_decode($salida, true);
          if ($json) {
            $resultado = $json["resultado"];
            $consola = $json["consola"];
          } else {
            $resultado = "";
            $consola = "<strong>Error:</strong> No se pudo decodificar JSON<br><pre>$salida</pre>";
          }
        }
      }
    }
  ?>

  <form method="post">
    <div class="form-group">
      <label>Tema / Problema / Pregunta</label>
      <textarea name="tema" class="form-control"><?= htmlspecialchars($tema) ?></textarea>
    </div>
    <div class="form-group">
      <label>Propuesta A</label>
      <textarea name="p1" class="form-control"><?= htmlspecialchars($p1) ?></textarea>
    </div>
    <div class="form-group">
      <label>Propuesta B (opcional)</label>
      <textarea name="p2" class="form-control"><?= htmlspecialchars($p2) ?></textarea>
	  <button type="submit" name="intercambiar" class="btn btn-secondary">Intercambiar</button>

    </div>
    <div class="form-group">
      <label>Valoración (opcional)</label>
      <textarea name="valoracion" class="form-control"><?= htmlspecialchars($valoracion) ?></textarea>
    </div>
    <div class="form-group">
      <label>Operación</label>
      <select name="operacion" class="form-control">
        <?php
          $ops = ['UNION', 'INTERSECCION', 'CONSENSO', 'ENMIENDA_PLUS', 'ENMIENDA_MINUS', 'CERCANIA', 'SIMPLIFICAR', 'GENERALIZAR'];
          foreach ($ops as $item) {
            $selected = $item === $op ? 'selected' : '';
            echo "<option value=\"$item\" $selected>$item</option>";
          }
        ?>
      </select>
	  <button type="submit" name="ejecutar" class="btn btn-primary">Ejecutar</button>
    </div>
  </form>

  <hr>
  <div class="form-group">
    <label>Resultado</label>
    <textarea readonly class="form-control" rows="5"><?= htmlspecialchars($resultado) ?></textarea>
  </div>
  <div class="form-group">
    <label>Salida de consola</label>
    <div class="form-control" style="color:red; background:#f8d7da; border-color:#f5c6cb;">
      <?= $consola ?>
    </div>
  </div>
</div>
<?php include 'base/pie.php'; ?>
