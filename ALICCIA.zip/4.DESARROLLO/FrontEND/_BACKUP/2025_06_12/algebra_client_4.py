import os
import requests
from dotenv import load_dotenv

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

def construir_prompt(operacion, *, p1, p2=None, valoracion=None, tema=None):
    if operacion == "UNION":
        return f"Une estas dos propuestas de forma coherente en una sola, respetando el tema '{tema}':\nPropuesta A: {p1}\nPropuesta B: {p2}"
    elif operacion == "INTERSECCION":
        return f"Extrae las ideas comunes entre estas dos propuestas sobre '{tema}':\nPropuesta A: {p1}\nPropuesta B: {p2}"
    elif operacion == "CONSENSO":
        return f"Redacta una propuesta de consenso entre las siguientes, respetando el tema '{tema}':\nPropuesta A: {p1}\nPropuesta B: {p2}"
    elif operacion == "CERCANIA":
        return f"¿Qué grado de similitud hay entre estas dos propuestas sobre '{tema}'? Proporciona un número entre 0 (nada similares) y 100 (idénticas):\nPropuesta A: {p1}\nPropuesta B: {p2}"
    elif operacion == "SIMPLIFICAR":
        return f"Simplifica la siguiente propuesta manteniendo su significado esencial:\n{p1}"
    elif operacion == "GENERALIZAR":
        return f"Reescribe la siguiente propuesta en términos más generales:\n{p1}"
    elif operacion == "ENMIENDA_PLUS":
        return f"Mejora la siguiente propuesta teniendo en cuenta esta valoración:\nPropuesta: {p1}\nValoración: {valoracion}"
    elif operacion == "ENMIENDA_MINUS":
        return f"Corrige o atenúa la siguiente propuesta teniendo en cuenta esta crítica:\nPropuesta: {p1}\nCrítica: {valoracion}"
    else:
        return "Operación no reconocida."

def resolver_operacion(operacion, *, p1, p2=None, valoracion=None, tema=None):
    prompt = construir_prompt(
        operacion=operacion,
        p1=p1,
        p2=p2,
        valoracion=valoracion,
        tema=tema
    )

    try:
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {OPENAI_API_KEY}",
            },
            json={
                "model": "gpt-4",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.7
            },
            timeout=30
        )

        if response.status_code == 200:
            data = response.json()
            contenido = data['choices'][0]['message']['content'].strip()
            return {"resultado": contenido, "consola": ""}
        else:
            return {
                "resultado": "",
                "consola": f"Error {response.status_code}: {response.text}"
            }

    except Exception as e:
        return {
            "resultado": "",
            "consola": f"Error al contactar con OpenAI: {str(e)}"
        }
