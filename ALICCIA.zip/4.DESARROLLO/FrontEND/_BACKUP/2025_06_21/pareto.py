#!/usr/bin/env python3
"""
pareto.py  · 9×9  ·  layout por niveles + líneas punteadas de equivalencia
Uso: python3 py/pareto.py <base64_json>
Salida JSON: {"pareto":[...], "image":"pareto.png"}
"""
import sys, json, base64, warnings, itertools
import numpy as np
from pathlib import Path
import networkx as nx
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")        # silenciar avisos de matplotlib

# ––– 1a. Leer argumento ——————————————————————————
if len(sys.argv) != 2:
    sys.exit('{"error":"Falta argumento base64"}')
try:
    data = json.loads(base64.b64decode(sys.argv[1]).decode())
except Exception as e:
    sys.exit(json.dumps({"error": f"JSON inválido: {e}"}))

# ––– 1b. Aqui divido los datos entre los que tienen apoyos y los que tienen rechazos	
dataU = {
    clave: [x for x in lista if x.startswith("U")]
    for clave, lista in data.items()}

dataR = {
    clave: [x for x in lista if x.startswith("R")]
    for clave, lista in data.items()}


# -----------------------------		
# CALCULO DEL FRENTE DE PARETO		
# -----------------------------		
# ––– 1. Filtrar propuestas sin apoyos  (requisito C)
propuestas = {k: set(v) for k, v in dataU.items() if v}  # No tengo en cuenta rechazos para el frente de pareto
if not propuestas:
    sys.exit(json.dumps({"pareto": [], "image": "", "image2": ""}))

# ––– 2. Aristas de dominación y equivalencia ————————————
G = nx.DiGraph()
G.add_nodes_from(propuestas.keys())
domination_edges = []
equiv_edges      = []        # líneas punteadas azules
for a, b in itertools.combinations(propuestas, 2):
    setA, setB = propuestas[a], propuestas[b]
    if setA == setB:
        equiv_edges.append((a, b))
    elif setB.issubset(setA):
        domination_edges.append((a, b))
    elif setA.issubset(setB):
        domination_edges.append((b, a))
G.add_edges_from(domination_edges)

# ––– 3. Frente de Pareto ——————————————————————————
pareto = [n for n in G if G.in_degree(n) == 0]

# ––– 4. Calcular “profundidad” (nivel) para layout ————————
depth = {}
def nivel(n):
    if n in depth:
        return depth[n]
    preds = list(G.predecessors(n))
    depth[n] = 0 if not preds else max(nivel(p) for p in preds) + 1
    return depth[n]
for nodo in G:
    nivel(nodo)

# ––– Asegurar mismo nivel para propuestas equivalentes
for a, b in equiv_edges:
    mismo = min(depth[a], depth[b])
    depth[a] = depth[b] = mismo

# ––– 5. Coordenadas manuales —————————————————————————
levels = {}
for n, lvl in depth.items():
    levels.setdefault(lvl, []).append(n)
pos = {}
for lvl, nodes in levels.items():
    nodes = sorted(nodes)         # opcional, para orden determinista
    N = len(nodes)
    # Usamos N+1 “intervalos” y colocamos en 1/(N+1), 2/(N+1), …, N/(N+1)
    step = 1 / max(N-1,1)
    for i, n in enumerate(nodes):
        if N == 1:
            # Si hay un solo nodo, centrarlo en x = 0.5
            x = 0.5
        else:
            # Si hay varios nodos, repartirlos en (1/(N+1), ..., N/(N+1))
            x = (i + 1) / (N + 1)
        pos[n] = (x, -lvl)

# ––– 6. Dibujar ——————————————————————————————————————
node_colors = ["lightgreen" if n in pareto else "lightgray" for n in G]
plt.figure(figsize=(8, 5))
nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=1800)
nx.draw_networkx_labels(G, pos, font_size=10)

# ––– Aristas de dominación (negras con flecha)
nx.draw_networkx_edges(G, pos, edgelist=domination_edges,
                       arrows=True, arrowstyle='-|>', edge_color='black')

# ––– Líneas de equivalencia (azul punteado, sin flecha) – requisito B
if equiv_edges:
    nx.draw_networkx_edges(G, pos, edgelist=equiv_edges,
                           arrows=False, style='dashed', edge_color='blue')
plt.title("Dominación de propuestas (verde = Pareto)")
plt.axis("off")
plt.margins(0.2)             # requisito D: margen alrededor
plt.tight_layout()

# ––– 7. Guardar el PNG de Pareto ————————————————
output = Path(__file__).resolve().parent.parent / "pareto.png"
plt.savefig(output, dpi=100)
plt.close()


# PREPARACION DE MATRICES PARA LAS MÉTRICAS
# propuestas_all = np.array(['Prop1','Prop2','Prop3','Prop4','Prop5','Prop6','Prop7','Prop8','Prop9'])
propuestas_all = sorted(data.keys())
usuarios = np.array(['U1','U2','U3','U4','U5','U6','U7','U8','U9','U10','U11','U12'])
rechazos = np.array(['R1','R2','R3','R4','R5','R6','R7','R8','R9','R10','R11','R12'])
# CONSTRUCCION DE LAS MATRICES DE APOYOS Y RECHAZOS
matriz_U = np.zeros((len(propuestas_all), len(usuarios)), dtype=int) # matriz a ceros
matriz_R = np.zeros((len(propuestas_all), len(usuarios)), dtype=int) # matriz a ceros
for i, prop in enumerate(propuestas_all):
    for usuario in dataU[prop]:
        j = np.where(usuarios == usuario)[0]
        if j.size > 0:
            matriz_U[i, j[0]] = 1
    for usuario in dataR[prop]:
        j = np.where(rechazos == usuario)[0]
        if j.size > 0:
            matriz_R[i, j[0]] = 1
# DEFINICION DE LAS FUNCIONES DE INCLUSION Y COMPARTICIÓN			
def inclusion(propA, propB, dataU):
    # Devuelve el porcentaje de usuarios de propA que también apoyan propB, si no hay apoyos a propA --> 0
    usuariosA = set(dataU.get(propA, []))
    usuariosB = set(dataU.get(propB, []))
    if not usuariosA:
        return 0.0
    interseccion = usuariosA & usuariosB
    return len(interseccion) / len(usuariosA)
def comparticion(propA, propB, dataU):
    return (inclusion(propA, propB, dataU) + inclusion(propB, propA, dataU))/2
# CONSTRUCCION DE LAS MATRICES DE INCLUSION Y COMPARTICION			
matriz_I = np.zeros((len(propuestas_all), len(propuestas_all)), dtype=float) # matriz a ceros
for i in range(len(propuestas_all)):
    for j in range(len(propuestas_all)):
        matriz_I[i,j]=format(inclusion(propuestas_all[i],propuestas_all[j],dataU), '.2f')
matriz_C = np.zeros((len(propuestas_all), len(propuestas_all)), dtype=float) # matriz a ceros
for i in range(len(propuestas_all)):
    for j in range(len(propuestas_all)):
        matriz_C[i,j]=format(comparticion(propuestas_all[i],propuestas_all[j],dataU), '.2f')
dataP = { key: dataU[key] for key in pareto if key in dataU }		
matriz_CP = np.zeros((len(pareto), len(pareto)), dtype=float) # matriz a ceros
for i in range(len(pareto)):
    for j in range(len(pareto)):
        matriz_CP[i,j]=format(inclusion(pareto[j],pareto[i],dataP), '.2f')		
# FUNCION PARA PINTAR LA MATRIZ		
c = plt.get_cmap('RdYlGn') # Parto del RdYlGn original
cols = c(np.linspace(0,1,256)) # Sustituyo el verde del valor máximo por uno más claro:
cols[-1] = mpl.colors.to_rgba('lightgreen')
cmap_mod = mpl.colors.ListedColormap(cols, name='RdYlGn_light') # Nuevo colormap
def dibujar_matriz(M, props, users, cmap=cmap_mod, figsize=(8, 5), dpi=100):
    fig, ax = plt.subplots(figsize=figsize, dpi=dpi)
    im = ax.imshow(M, cmap=cmap, aspect='equal', origin='upper')     # Mostrar la matriz
    ax.set_xticks(np.arange(len(users)))     # Ticks y etiquetas
    ax.set_yticks(np.arange(len(props)))
    ax.set_xticklabels(users)
    ax.set_yticklabels(props)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")
    for i in range(M.shape[0]): # Anotar cada celda con su valor
        for j in range(M.shape[1]):
            ax.text(j, i, f"{M[i, j]:.2f}",
                    ha="center", va="center")
    ax.set_xticks(np.arange(-.5, M.shape[1], 1), minor=True)     # Cuadrícula ligera
    ax.set_yticks(np.arange(-.5, M.shape[0], 1), minor=True)
    ax.grid(which="minor", color="w", linestyle='-', linewidth=2)
    ax.tick_params(which="minor", bottom=False, left=False)
    plt.tight_layout()
    output2 = Path(__file__).resolve().parent.parent / "matriz.png"
    plt.savefig(output2, dpi=100)
    plt.close()


# ––– 8. Guardar el PNG de la matriz ————————————————
output2 = Path(__file__).resolve().parent.parent / "matriz.png"
dibujar_matriz(matriz_CP, pareto, pareto) 

# ––– 9. Exportar el JSON ————————————————
print(json.dumps({"pareto": pareto, "image": output.name, "image2": output2.name}))
