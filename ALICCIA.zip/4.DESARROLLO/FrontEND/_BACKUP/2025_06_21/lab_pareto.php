<?php
/* --------------------------------------------------------------
   pareto.php – 9×9 · Drag & Drop · con botón Reset
   Versión modificada con Apoyos y Rechazos de usuarios
   -------------------------------------------------------------- */
$usuarios   = ["U1","U2","U3","U4","U5","U6","U7","U8","U9","U10","U11","U12"];
$rechazos   = ["R1","R2","R3","R4","R5","R6","R7","R8","R9","R10","R11","R12"];
$propuestas = [
    "Prop1","Prop2","Prop3",
    "Prop4","Prop5","Prop6",
    "Prop7","Prop8","Prop9"
];

$pareto = $grafico = $error = null;

/* ---------- Procesar formulario ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datos = [];
    foreach ($propuestas as $p) {
        $datos[$p] = $_POST[$p] ?? [];
    }
    // var_dump($datos); 
    /* Ruta a python y script */
    $json = json_encode($datos);
    // var_dump($json); (idea de JR para mostrar el JSON)
    $b64    = base64_encode($json);
    // var_dump($b64);
    
$python = '/usr/bin/python3';                       // ajusta si es distinto
    $script = __DIR__ . '/py/pareto.py';

    putenv('PATH=/usr/bin:' . getenv('PATH'));         // asegura que dot esté en PATH

    $cmd   = escapeshellarg($python) . ' ' .
             escapeshellarg($script) . ' ' .
             escapeshellarg($b64) . ' 2>&1';

    $out   = shell_exec($cmd);
    if ($out && ($res = json_decode($out, true))) {
        $pareto  = $res['pareto'];
        $grafico = $res['image'];
		$grafico2 = $res['image2'];
    } else {
        $error = "Error al ejecutar py/pareto.py:<br><pre>" .
                  htmlspecialchars($cmd . PHP_EOL . $out) . "</pre>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include 'base/head.php'; ?>
    <style>
        /* ---------- Grid 3×3 ó 1×9 ---------- */
        .propuesta-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;
        }
        @media (min-width: 992px) {
            .propuesta-grid { grid-template-columns: repeat(9, 1fr); }
        }
        /* ---------- Cajas y badges ---------- */
        .proposal-box {
            min-height: 90px;
            border: 2px dashed #ced4da;
            border-radius: .5rem;
            padding: .4rem;
            background: #f8f9fa;
        }
        .proposal-box.drag-over { background: #e2e6ea; }
        .user-badge    { cursor: move; font-size: 1.15rem; color: green;}
        .reject-badge  { cursor: move; font-size: 1.15rem; color: red;}
        .support-badge { cursor: pointer; font-size: 1.25rem; color: green;} /* más grande */
        .rejection-badge { cursor: pointer; font-size: 1.25rem; color: red;} /* más grande */
    </style>
</head>
<body>
<?php include 'base/cabecera.php'; ?>

<div class="container-fluid px-5 pt-2">
	    <div class="row pt-12">
			<h4 class= "px-2 pt-2">Lab: FRENTE DE PARETO</h4>
		</div>
		<div class="row pt-12">
			<p class= "px-2 pt-2"> En este ejemplo de laboratorio se presentan 9 propuestas a las cuales un grupo de debate de 12 usuarios puede darles su apoyo o rechazo. <br>(El apoyo/rechazo se da arrastrando las marcas U1, U2, (apoyo) o R1, R2, (rechazo) a la caja/propuesta en cuestión) (en las x se retira el apoyo/rechazo) (el rechazo retira el apoyo automáticamente y viceversa) <p>
		</div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" id="paretoForm">
        <!-- Cuadrícula de propuestas -->
        <div class="propuesta-grid my-3">
            <?php foreach ($propuestas as $p): ?>
                <div>
                    <h5 class="text-center mb-1"><?= $p ?></h5>
                    <div class="proposal-box" data-propuesta="<?= $p ?>">
                        <?php
                        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST[$p])) {
                            foreach ($_POST[$p] as $u) {
                                // Determinar si es apoyo (U) o rechazo (R)
                                $isReject = strpos($u, 'R') === 0;
                                $badgeClass = $isReject ? 'text-bg-danger rejection-badge' : 'text-bg-success support-badge';
                                echo "<span class='badge rounded-pill {$badgeClass} me-1 mb-1'
                                           data-user='{$u}' data-type='" . ($isReject ? 'reject' : 'support') . "'>{$u} ×</span>";
                                echo "<input type='hidden' name='{$p}[]' value='{$u}'>";
                            }
                        }
                        ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Paleta de apoyos de usuarios -->
        <div class="text-center mt-4">
            <h4>Apoyos de usuarios</h4>
            <div id="userPalette" class="d-flex flex-wrap gap-2 justify-content-center fs-5">
                <?php foreach ($usuarios as $u): ?>
                    <span class="badge rounded-pill text-bg-primary user-badge"
                          draggable="true" data-user="<?= $u ?>" data-type="support"><?= $u ?></span>
                <?php endforeach; ?>
            </div>
            <p class="mt-2 text-muted">
                Arrastra usuarios a las propuestas que apoyen.
                Pulsa en un badge verde para quitarlo.
            </p>
        </div>

        <!-- Paleta de rechazos de usuarios -->
        <div class="text-center mt-4">
            <h4>Rechazos de usuarios</h4>
            <div id="rejectPalette" class="d-flex flex-wrap gap-2 justify-content-center fs-5">
                <?php foreach ($rechazos as $r): ?>
                    <span class="badge rounded-pill text-bg-danger reject-badge"
                          draggable="true" data-user="<?= $r ?>" data-type="reject"><?= $r ?></span>
                <?php endforeach; ?>
            </div>
            <p class="mt-2 text-muted">
                Arrastra rechazos a las propuestas que rechacen.
                Pulsa en una X para quitarlo.
            </p>
        </div>

        <button class="btn btn-primary mt-4" type="submit">Calcular Frente de Pareto</button>
        <button type="button" id="resetBtn" class="btn btn-secondary mt-4 ms-2">Resetear apoyos y rechazos</button>
    </form>
	
	<!-- ESTE BLOQUE PHP ES EL QUE PINTA LOS RESULTADOS -->
    <?php if ($pareto !== null): ?>
        <hr class="my-5">
        <h4>Resultado</h4>
        <p><strong>Propuestas en el Frente de Pareto:</strong>
           <?= empty($pareto) ? 'Ninguna' : implode(', ', $pareto) ?></p>
        <?php if (is_file($grafico)): ?>
            <img src="<?= htmlspecialchars($grafico) ?>?v=<?= time() ?>"
                 class="img-fluid border" alt="Grafo de dominación">
        <?php endif; ?>
		<br><br><br><p><strong>Matriz de compartición entre propuestas:</strong></p>
	    <?php if (is_file($grafico2)): ?>
            <img src="<?= htmlspecialchars($grafico2) ?>?v=<?= time() ?>"
                 class="img-fluid border" alt="Matriz de compartición">
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php include 'base/pie.php'; ?>

<script>
/* ---------- Drag & Drop con exclusividad mutua ---------- */
(() => {
    /* util: habilitar borrado */
    function attachDelete(span) {
        span.addEventListener('click', () => {
            const next = span.nextElementSibling;
            if (next && next.tagName === 'INPUT') next.remove();
            span.remove();
        });
    }

    /* Drag start */
    document.querySelectorAll('.user-badge, .reject-badge').forEach(badge =>
        badge.addEventListener('dragstart', e => {
            e.dataTransfer.setData('text/plain', badge.dataset.user);
            e.dataTransfer.setData('text/type', badge.dataset.type);
        }));

    /* Función para obtener el número de usuario (U1->1, R1->1) */
    function getUserNumber(user) {
        return user.substring(1);
    }

    /* Función para remover apoyo/rechazo existente del mismo usuario */
    function removeExistingUserBadge(box, userNumber) {
        const existingBadges = box.querySelectorAll('[data-user]');
        existingBadges.forEach(badge => {
            if (getUserNumber(badge.dataset.user) === userNumber) {
                const nextInput = badge.nextElementSibling;
                if (nextInput && nextInput.tagName === 'INPUT') nextInput.remove();
                badge.remove();
            }
        });
    }

    /* añadir badge de apoyo (verde) + input */
    function addSupport(box, user) {
        const userNumber = getUserNumber(user);
        removeExistingUserBadge(box, userNumber);

        const span = document.createElement('span');
        span.className = 'badge rounded-pill text-bg-success me-1 mb-1 support-badge';
        span.dataset.user = user;
        span.dataset.type = 'support';
        span.textContent  = user + ' ×';
        attachDelete(span);

        const input = document.createElement('input');
        input.type  = 'hidden';
        input.name  = box.dataset.propuesta + '[]';
        input.value = user;

        box.appendChild(span);
        box.appendChild(input);
    }

    /* añadir badge de rechazo (rojo) + input */
    function addReject(box, user) {
        const userNumber = getUserNumber(user);
        removeExistingUserBadge(box, userNumber);

        const span = document.createElement('span');
        span.className = 'badge rounded-pill text-bg-danger me-1 mb-1 rejection-badge';
        span.dataset.user = user;
        span.dataset.type = 'reject';
        span.textContent  = user + ' ×';
        attachDelete(span);

        const input = document.createElement('input');
        input.type  = 'hidden';
        input.name  = box.dataset.propuesta + '[]';
        input.value = user;

        box.appendChild(span);
        box.appendChild(input);
    }

    /* eventos en cada caja */
    document.querySelectorAll('.proposal-box').forEach(box => {
        box.addEventListener('dragover',  e => { e.preventDefault(); box.classList.add('drag-over'); });
        box.addEventListener('dragleave', () => box.classList.remove('drag-over'));
        box.addEventListener('drop',      e => {
            e.preventDefault(); 
            box.classList.remove('drag-over');
            
            const user = e.dataTransfer.getData('text/plain');
            const type = e.dataTransfer.getData('text/type');
            
            if (user) {
                if (type === 'support') {
                    addSupport(box, user);
                } else if (type === 'reject') {
                    addReject(box, user);
                }
            }
        });
    });

    /* reactivar borrado en badges reconstruidos por PHP */
    document.querySelectorAll('.support-badge, .rejection-badge').forEach(attachDelete);

    /* botón Reset */
    document.getElementById('resetBtn').addEventListener('click', () => {
        document.querySelectorAll('.support-badge, .rejection-badge').forEach(b => b.remove());
        document.querySelectorAll('.proposal-box input[type="hidden"]').forEach(i => i.remove());
    });
})();
</script>
</body>
</html>

