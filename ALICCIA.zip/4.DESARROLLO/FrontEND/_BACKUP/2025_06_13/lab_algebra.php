<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
	</head>
	<body>
	   <?php include 'base/cabecera.php';?>
<div class="container-fluid px-5 pt-2">
	    <div class="row pt-12">
			<h4 class= "px-2 pt-2">Lab: ÁLGEBRA DE PROPUESTAS</h4>
		</div>
  <?php
    $tema = $_POST['tema'] ?? '';
    $p1 = $_POST['p1'] ?? '';
    $p2 = $_POST['p2'] ?? '';
    $valoracion = $_POST['valoracion'] ?? '';
    $op = $_POST['operacion'] ?? '';
    $modelo = $_POST['modelo'] ?? 'gpt-4.1-mini';
    $temperatura = $_POST['temperatura'] ?? 0.5;
    $modo = $_POST['modo'] ?? 'prompting';
    $resultado = "";
    $consola = "";

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      if (isset($_POST['intercambiar'])) {
        $tmp = $p1;
        $p1 = $p2;
        $p2 = $tmp;
      }

      if (isset($_POST['ejecutar'])) {
        function contar_palabras($texto) {
          return str_word_count(strip_tags($texto));
        }

        $errores = [];

        if (!is_numeric($temperatura) || $temperatura < 0 || $temperatura > 2) {
          $errores[] = "La temperatura debe estar entre 0 y 2.";
        }

        if (in_array($op, ['UNION', 'INTERSECCION', 'CONSENSO', 'CERCANIA'])) {
          $p1_len = contar_palabras($p1);
          $p2_len = contar_palabras($p2);

          if (empty(trim($p1))) $errores[] = "Propuesta A está vacía.";
          elseif ($p1_len < 50) $errores[] = "Propuesta A es demasiado corta.";
          elseif ($p1_len > 300) $errores[] = "Propuesta A es demasiado larga.";

          if (empty(trim($p2))) $errores[] = "Propuesta B está vacía.";
          elseif ($p2_len < 50) $errores[] = "Propuesta B es demasiado corta.";
          elseif ($p2_len > 300) $errores[] = "Propuesta B es demasiado larga.";
        }

        elseif (in_array($op, ['ENMIENDA_PLUS', 'ENMIENDA_MINUS', 'SIMPLIFICAR', 'GENERALIZAR'])) {
          $p1_len = contar_palabras($p1);
          if (empty(trim($p1))) $errores[] = "Propuesta A está vacía.";
          elseif ($p1_len < 50) $errores[] = "Propuesta A es demasiado corta.";
          elseif ($p1_len > 300) $errores[] = "Propuesta A es demasiado larga.";

          if (in_array($op, ['ENMIENDA_PLUS', 'ENMIENDA_MINUS'])) {
            $val_len = contar_palabras($valoracion);
            if (empty(trim($valoracion))) $errores[] = "La valoración está vacía.";
            elseif ($val_len < 25) $errores[] = "La valoración es demasiado corta.";
            elseif ($val_len > 100) $errores[] = "La valoración es demasiado larga.";
          }
        }

        if (!empty($errores)) {
          $consola = implode("<br>", $errores);
        } else {
          $data = [
            "tema" => $tema,
            "p1" => $p1,
            "p2" => $p2,
            "valoracion" => $valoracion,
            "operacion" => $op,
            "model" => $modelo,
            "temperature" => floatval($temperatura),
            "modo" => $modo
          ];
          $json_args = escapeshellarg(json_encode($data));
          $comando = "/usr/local/bin/python3.9-tfm py/algebra.py $json_args 2>&1";
          $salida = shell_exec($comando);

          $json = json_decode($salida, true);
          if ($json) {
            $resultado = $json["resultado"];
            $consola = $json["consola"];
          } else {
            $resultado = "";
            $consola = "<strong>Error:</strong> No se pudo decodificar JSON<br><pre>$salida</pre>";
          }
        }
      }
    }
  ?>

  <form method="post">
  <div class="row">
  <div class="col-12 col-lg-6">
    <div class="form-group">
      <label>Tema / Problema / Pregunta</label>
      <textarea name="tema" class="form-control"><?= htmlspecialchars($tema) ?></textarea>
    </div>
    <div class="form-group">
      <label>Propuesta A</label>
      <textarea name="p1" class="form-control"><?= htmlspecialchars($p1) ?></textarea>
    </div>
    <div class="form-group">
      <label>Propuesta B (opcional)</label>
      <textarea name="p2" class="form-control"><?= htmlspecialchars($p2) ?></textarea>
	  <button type="submit" name="intercambiar" class="btn btn-secondary">Intercambiar</button>
    </div>
    <div class="form-group">
      <label>Valoración (opcional)</label>
      <textarea name="valoracion" class="form-control"><?= htmlspecialchars($valoracion) ?></textarea>
    </div>
</div>
	<div class="col-12 col-lg-6">
    <div class="form-group">
      <label>Operación</label>
      <select name="operacion" class="form-control">
        <?php
          $ops = ['UNION', 'INTERSECCION', 'CONSENSO', 'ENMIENDA_PLUS', 'ENMIENDA_MINUS', 'CERCANIA', 'SIMPLIFICAR', 'GENERALIZAR'];
          foreach ($ops as $item) {
            $selected = $item === $op ? 'selected' : '';
            echo "<option value=\"$item\" $selected>$item</option>";
          }
        ?>
      </select>
	  <button type="submit" name="ejecutar" class="btn btn-primary">Ejecutar</button>
	  <div class="form-inline float-right">
		<select name="modelo" class="form-control ml-2">
		  <option value="gpt-4" <?= $modelo === 'gpt-4' ? 'selected' : '' ?>>gpt-4</option>
		  <option value="gpt-4-turbo" <?= $modelo === 'gpt-4-turbo' ? 'selected' : '' ?>>gpt-4-turbo</option>
		  <option value="gpt-4.1-mini" <?= $modelo === 'gpt-4.1-mini' ? 'selected' : '' ?>>gpt-4.1-mini</option>
		  <option value="gpt-4.1-nano" <?= $modelo === 'gpt-4.1-nano' ? 'selected' : '' ?>>gpt-4.1-nano</option>
		  <option value="o4-mini" <?= $modelo === 'o4-mini' ? 'selected' : '' ?>>o4-mini</option>
		  <option value="o1-pro" <?= $modelo === 'o1-pro' ? 'selected' : '' ?>>o1-pro</option>
		</select>
		<input type="number" name="temperatura" value="<?= htmlspecialchars($temperatura) ?>" step="0.1" min="0" max="2" class="form-control ml-2" style="width:120px;" placeholder="Temperatura">
		<select name="modo" class="form-control ml-2">
		  <option value="prompting" <?= $modo === 'prompting' ? 'selected' : '' ?>>prompting</option>
		  <option value="asistente" <?= $modo === 'asistente' ? 'selected' : '' ?>>asistente</option>
		  <option value="RAG" <?= $modo === 'RAG' ? 'selected' : '' ?>>RAG</option>
		</select>
	  </div>
    </div>

  </form>

  <hr>
  <div class="form-group">
    <label>Resultado</label>
    <textarea readonly class="form-control" rows="5"><?= htmlspecialchars($resultado) ?></textarea>
  </div>
  <div class="form-group">
    <label>Salida de consola</label>
    <div class="form-control" style="color:red; background:#f8d7da; border-color:#f5c6cb;">
      <?= $consola ?>
    </div>
  </div>
  	</div>
	</div>
</div>
<?php include 'base/pie.php'; ?>
   </body>
</html>