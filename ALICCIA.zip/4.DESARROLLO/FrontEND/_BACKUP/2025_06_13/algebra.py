# -*- coding: utf-8 -*-
import sys
import json
import os
import requests
from dotenv import load_dotenv

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

def construir_prompt(operacion, *, p1, p2=None, valoracion=None, tema=None):
    if operacion == "UNION":
        return f"Construye una nueva propuesta que incluye los elementos esenciales de estas dos propuestas, de acuerdo al tema '{tema}':\nPropuesta A: {p1}\nPropuesta B: {p2} (No incluyas cabeceras, ni bullets, ni metalenguaje)"
    elif operacion == "INTERSECCION":
        return f"Construye una nueva propuesta que incluya solo los elementos que consideres que son comunes a estas dos propuestas, de acuerdo al tema '{tema}':\nPropuesta A: {p1}\nPropuesta B: {p2} (No incluyas cabeceras, ni bullets, ni metalenguaje)"
    elif operacion == "CONSENSO":
        return f"Redacta una nueva propuesta que consideres podría ser una propuesta de consenso entre estas dos propuestas, de acuerdo al tema '{tema}':\nPropuesta A: {p1}\nPropuesta B: {p2} (No incluyas cabeceras, ni bullets, ni metalenguaje). Si ves que están muy alejadas simplemente responde 'Consenso difícil' "
    elif operacion == "CERCANIA":
        return f"¿Qué grado de similitud hay entre estas dos propuestas sobre '{tema}'? Proporciona un número entre 0 (nada similares) y 1 (idénticas) y con dos decimales:\nPropuesta A: {p1}\nPropuesta B: {p2}"
    elif operacion == "SIMPLIFICAR":
        return f"Simplifica y acorta la siguiente propuesta manteniendo su significado esencial:\n{p1} (No incluyas cabeceras, ni bullets, ni metalenguaje)"
    elif operacion == "GENERALIZAR":
        return f"Reescribe la siguiente propuesta en términos más generales:\n{p1} (No incluyas cabeceras, ni bullets, ni metalenguaje)"
    elif operacion == "ENMIENDA_PLUS":
        return f"Mejora la siguiente propuesta teniendo en cuenta esta valoración:\nPropuesta: {p1}\nValoración: {valoracion} (No incluyas cabeceras, ni bullets, ni metalenguaje)"
    elif operacion == "ENMIENDA_MINUS":
        return f"Corrige o atenúa la siguiente propuesta teniendo en cuenta esta crítica:\nPropuesta: {p1}\nCrítica: {valoracion} (No incluyas cabeceras, ni bullets, ni metalenguaje)"
    else:
        return "Operación no reconocida."

def resolver_operacion(operacion, *, p1, p2=None, valoracion=None, tema=None, model="gpt-4.1-mini", temperature=0.7):
    prompt = construir_prompt(
        operacion=operacion,
        p1=p1,
        p2=p2,
        valoracion=valoracion,
        tema=tema
    )

    try:
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {OPENAI_API_KEY}",
            },
            json={
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": temperature
            },
            timeout=30
        )

        if response.status_code == 200:
            data = response.json()
            contenido = data['choices'][0]['message']['content'].strip()
            return {"resultado": contenido, "consola": ""}
        else:
            return {
                "resultado": "",
                "consola": f"Error {response.status_code}: {response.text}"
            }

    except Exception as e:
        return {
            "resultado": "",
            "consola": f"Error al contactar con OpenAI: {str(e)}"
        }

if __name__ == "__main__":
    try:
        entrada = sys.argv[1]
        datos = json.loads(entrada)

        operacion = datos.get("operacion")
        p1 = datos.get("p1", "").strip()
        p2 = datos.get("p2", "").strip()
        valoracion = datos.get("valoracion", "").strip()
        tema = datos.get("tema", "").strip()
        model = datos.get("model", "gpt-4.1-mini")
        temperature = datos.get("temperature", 0.7)

        resultado = resolver_operacion(
            operacion=operacion,
            p1=p1,
            p2=p2,
            valoracion=valoracion,
            tema=tema,
            model=model,
            temperature=temperature
        )

        print(json.dumps(resultado))

    except Exception as e:
        print(json.dumps({
            "resultado": "",
            "consola": f"Error al procesar: {str(e)}"
        }))
