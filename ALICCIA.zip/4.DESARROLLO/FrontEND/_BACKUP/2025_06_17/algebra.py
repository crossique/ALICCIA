# -*- coding: utf-8 -*-
import sys
import json
import os
import time
import requests
from dotenv import load_dotenv

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_ASSISTANT_ID = os.getenv("OPENAI_ASSISTANT_ID")

def run_assistant_http(assistant_id, user_input):
    try:
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {OPENAI_API_KEY}",
            "OpenAI-Beta": "assistants=v2"
        }

        # Crear thread vacío
        t_resp = requests.post("https://api.openai.com/v1/threads", headers=headers, json={}, timeout=75)
        if t_resp.status_code != 200:
            return f"Error al crear thread: {t_resp.status_code} - {t_resp.text}"
        t_id = t_resp.json().get("id")

        # Añadir mensaje del usuario
        m_resp = requests.post(
            f"https://api.openai.com/v1/threads/{t_id}/messages",
            headers=headers,
            json={"role": "user", "content": user_input},
            timeout=75
        )
        if m_resp.status_code != 200:
            return f"Error al crear mensaje: {m_resp.status_code} - {m_resp.text}"

        # Lanzar el asistente
        r_resp = requests.post(
            f"https://api.openai.com/v1/threads/{t_id}/runs",
            headers=headers,
            json={"assistant_id": assistant_id},
            timeout=75
        )
        if r_resp.status_code != 200:
            return f"Error al lanzar run: {r_resp.status_code} - {r_resp.text}"

        r_id = r_resp.json().get("id")

        # Esperar a que termine
        while True:
            time.sleep(1)
            status_resp = requests.get(
                f"https://api.openai.com/v1/threads/{t_id}/runs/{r_id}",
                headers=headers,
                timeout=75
            )
            status_data = status_resp.json()
            if status_data.get("status") == "completed":
                break
            elif status_data.get("status") == "failed":
                return f"Ejecución fallida: {status_data}"

        # Obtener mensaje final
        msgs_resp = requests.get(
            f"https://api.openai.com/v1/threads/{t_id}/messages",
            headers=headers,
            timeout=75
        )
        mensajes = msgs_resp.json().get("data", [])
        for msg in mensajes:
            if msg.get("role") == "assistant":
                bloques = msg.get("content", [])
                if bloques and bloques[0].get("type") == "text":
                    return bloques[0]["text"]["value"]

        return "Sin respuesta del asistente."

    except Exception as e:
        return f"Error en ejecución: {str(e)}"

def construir_prompt(operacion, p1, p2=None, valoracion=None, tema=None):
    if operacion == "UNION":
        return f"Construye una nueva propuesta que incluye los elementos esenciales de estas dos propuestas, de acuerdo al tema '{tema}':\nPropuesta A: {p1}\nPropuesta B: {p2} (No incluyas cabeceras, ni bullets, ni referencias a las propuestas de origen y mantén en lo posible la redacción y estilo de las propuestas originales, no inventando nuevos términos, ni sinónimos, ni giros, ni apreciaciones que no estén en las propuestas originales)"
    elif operacion == "INTERSECCION":
        return f"Construye una nueva propuesta que incluya solo los elementos que consideres que son comunes a estas dos propuestas, de acuerdo al tema '{tema}':\nPropuesta A: {p1}\nPropuesta B: {p2} (No incluyas cabeceras, ni bullets, ni referencias a las propuestas de origen  y mantén en lo posible la redacción y estilo de las propuestas originales, no inventando nuevos términos, ni sinónimos, ni giros, ni apreciaciones que no estén en las propuestas originales)"
    elif operacion == "CONSENSO":
        return f"Redacta una nueva propuesta que consideres podría ser una propuesta de consenso entre estas dos propuestas, de acuerdo al tema '{tema}':\nPropuesta A: {p1}\nPropuesta B: {p2} (No incluyas cabeceras, ni bullets, ni referencias a las propuestas de origen y mantén en lo posible la redacción y estilo de las propuestas originales, no inventando nuevos términos ni giros ni apreciaciones que no estén en las propuestas originales). Si ves que están muy alejadas simplemente responde 'Consenso difícil' "
    elif operacion == "CERCANIA":
        return f"¿Qué grado de similitud hay entre estas dos propuestas sobre '{tema}'? Proporciona un número entre 0 (nada similares) y 1 (idénticas) y con dos decimales:\nPropuesta A: {p1}\nPropuesta B: {p2}"
    elif operacion == "SIMPLIFICAR":
        return f"Simplifica, resume y acorta la siguiente propuesta manteniendo su significado esencial:\n{p1} (No incluyas cabeceras, ni bullets, ni referencias a la propuesta de origen y mantén en lo posible la redacción y estilo de la propuesta original, no inventando nuevos términos, ni sinónimos, ni giros, ni apreciaciones que no estén en la propuestas originales)"
    elif operacion == "GENERALIZAR":
        return f"Reescribe la siguiente propuesta en términos más amplios y generales:\n{p1} (No incluyas cabeceras, ni bullets, ni referencias a la propuesta de origen y mantén en lo posible la redacción y estilo de la propuesta original)"
    elif operacion == "ENMIENDA+":
        return f"Mejora la siguiente propuesta teniendo en cuenta esta valoración:\nPropuesta: {p1}\nValoración: {valoracion} (No incluyas cabeceras, ni bullets, ni referencias a la propuesta de origen y mantén en lo posible la redacción y estilo de la propuesta original, no inventando nuevos términos, ni sinónimos, ni giros, ni apreciaciones que no estén en la propuesta original)"
    elif operacion == "ENMIENDA-":
        return f"Corrige o atenúa la siguiente propuesta teniendo en cuenta esta crítica:\nPropuesta: {p1}\nCrítica: {valoracion} (No incluyas cabeceras, ni bullets, ni referencias a la propuesta de origen y mantén en lo posible la redacción y estilo de la propuesta original, no inventando nuevos términos, ni sinónimos, ni giros, ni apreciaciones que no estén en la propuesta original)"
    else:
        return "Operación no reconocida."

def resolver_operacion(operacion, p1, p2=None, valoracion=None, tema=None, model="gpt-4", temperature=0.5, modo="prompting"):
    inicio = time.time()
    if modo == "asistente":
        try:
            if not OPENAI_ASSISTANT_ID:
                raise ValueError("OPENAI_ASSISTANT_ID no está definido en .env")

            user_input = json.dumps({
                "operacion": operacion,
                "p1": p1,
                "p2": p2,
                "valoracion": valoracion,
                "tema": tema
            }, ensure_ascii=False)

            contenido = run_assistant_http(OPENAI_ASSISTANT_ID, user_input)
            duracion = time.time() - inicio
            return {"resultado": contenido.strip(), "consola": f"Tiempo de ejecución: {duracion:.2f} segundos"}

        except Exception as e:
            return {
                "resultado": "",
                "consola": f"Error de red o HTTP al contactar con OpenAI: {str(e)}"
            }

    else:
        prompt = construir_prompt(operacion, p1, p2, valoracion, tema)
        try:
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {OPENAI_API_KEY}"
                },
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": temperature
                },
                timeout=75
            )
            duracion = time.time() - inicio
            if response.status_code == 200:
                data = response.json()
                contenido = data['choices'][0]['message']['content'].strip()
                return {"resultado": contenido, "consola": f"Tiempo de ejecución: {duracion:.2f} segundos"}
            else:
                return {"resultado": "", "consola": f"Error {response.status_code}: {response.text}"}
        except Exception as e:
            return {"resultado": "", "consola": f"Error al contactar con OpenAI: {str(e)}"}

if __name__ == "__main__":
    try:
        entrada = sys.argv[1]
        datos = json.loads(entrada)

        resultado = resolver_operacion(
            operacion=datos.get("operacion"),
            p1=datos.get("p1"),
            p2=datos.get("p2"),
            valoracion=datos.get("valoracion"),
            tema=datos.get("tema"),
            model=datos.get("model", "gpt-4"),
            temperature=datos.get("temperature", 0.5),
            modo=datos.get("modo", "prompting")
        )

        print(json.dumps(resultado))

    except Exception as e:
        print(json.dumps({"resultado": "", "consola": f"Error general: {str(e)}"}))
