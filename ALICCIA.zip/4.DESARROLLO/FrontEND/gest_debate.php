<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
     	<script src="js/script_debate.js"></script>
	</head>
	<body>
	   	<?php include 'base/cabecera.php';?>
	   	<?php include 'base/control_sesion_fac.php';?>
	
	<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->




	<!-- TITULO Y DATOS DEL DEBATE -->

	<div class="container-fluid px-5">
		<div class="row pt-3">
		<?php $id_debate = $_GET['debate'];
		$_SESSION["idd"] = $id_debate;?>
		<div class="col-md-12">
			<h5><i class="fas fa-comments color:#0077AA"></i> Gestión del debate <?php echo $id_debate;?> </h5>
		</div>
		<hr>

		<hr>	
		<div class="col-md-12">
		<table class="table table-bordered table-striped table-xtra-consensed">
                        <tr class="table-xtra-consensed">
                            <th width="100">Nombre</th>
                            <th width="200">Resumen</th>
                            <th>TEXTO INICIAL (se muestra solo el comienzo ...) </th>
                            <th width="100">GRUPO</th>
                            <th width="40">Img</th>
                            <th width="60">Cambiar</th> 
                            <th width="40">Tipo</th>
                            <th width="40">Estado</th>
                            <th width="40">GEN</th>
                            <th width="40">Est/F</th>
                            <th width="40">NºRes</th>
                        </tr>

		<?php $query = "SELECT T_DEBATES.id_debate,nombre,resumen,texto_inicial,imagen,tipo_debate,T_DEBATES.estado,generacion_act,nombre_gd,count(*) as cuenta,estado_fase FROM T_DEBATES LEFT JOIN T_PROPUESTAS ON T_DEBATES.id_debate = T_PROPUESTAS.id_debate INNER JOIN T_GRUPOS_DEBATE ON grupo=id_grupo_debate WHERE T_DEBATES.id_debate = '$id_debate' GROUP BY T_DEBATES.id_debate";
		if (!$result = mysqli_query($con,$query)) {exit(mysqli_error($con));}
		while ($row = mysqli_fetch_assoc($result)) {
		$nombre=$row['nombre'];
		$resumen=$row['resumen'];
		$gen=$row['generacion_act'];
        if($row['tipo_debate']=='AP'){$tipo="Appgree";}
        if($row['tipo_debate']=='IW'){$tipo="IWarsMap";}
        if($row['tipo_debate']=='VI'){$tipo="Vilfredo";}
		$estado=$row['estado'];
        $texto_ini = $row['texto_inicial'];
        if(strlen($texto_ini)>222){$texto_ini=substr($texto_ini, 0, 221).' ...';}		
		echo "<tr>
		<td bgcolor='#E0FFF0' style='vertical-align:middle; padding: 15px;'><b>".$nombre."</b></td>
		<td bgcolor='#E0FFF0' style='vertical-align:middle;'><b>".$resumen."</b></td>
		<td bgcolor='#E0FFF0' style='vertical-align:middle;'>".$texto_ini."</td>
		<td bgcolor='#E0FFF0' style='vertical-align:middle;'>".$row['nombre_gd']."</td>
		<td bgcolor='#E0FFF0'><img src='img/debates/".$row['imagen']."' height='75px' width='150px' class='d-inline-block align-middle align-center'></td>
		<td bgcolor='#E0FFF0' style='text-align:center;vertical-align:middle;'>
                    <a href='datos/uploadFileD.php?idO=".$row['id_debate']."' class='btn btn-info '><i class='fas fa-image'></i></a></td>
		<td bgcolor='#E0FFF0' style='text-align:center;vertical-align:middle;'><b>".$tipo."</b></td>
		<td bgcolor='#E0FFF0' style='text-align:center;vertical-align:middle;'><b>".$estado."</b></td>
		<td bgcolor='#E0FFF0' style='text-align:center;vertical-align:middle;'>".$gen."</td>
		<td bgcolor='#E0FFF0' style='text-align:center;vertical-align:middle;'>".$row['estado_fase']."</td>
		<td bgcolor='#E0FFF0' style='text-align:center;vertical-align:middle;'>".$row['cuenta']."</td>
		</tr>";
		}?>
		</table>
		</div>

		<div class="col-md-12">
			NUEVA PROPUESTA INSERTADA POR EL FACILITADOR:  
		<div class="btn-group">   
      		<a type="button" class="btn btn-success btn-sm text-white" data-target="#add_new_record_modal" data-toggle="modal" data-toggle="tooltip" title="Inserta una nueva respuesta/propuesta por parte del facilitador"><i class='fas fa-share'></i> Añadir Respuesta/Propuesta</a>
    	</div>
    	</div>
		&nbsp
		<div class="col-md-12">
			ESTADO DEL DEBATE: 
		<div class="btn-group">   
      		<a type="button" onclick="CambiarEstadoDebate('<?php echo $id_debate;?>')" name="genlist" id="genlist" class="btn btn-warning btn-sm" data-toggle="tooltip" title="Bascula el estado siguiendo el ciclo 1P-2L-3A-4F-5C"><i class='fas fa-recycle'></i> Cambiar estado del debate </a>
    	</div>
    		ESTADO DE LA FASE: 
		<div class="btn-group">   
      		<a type="button" onclick="CambiarEstadoFaseDebate('<?php echo $id_debate;?>')" name="genlist" id="genlist" class="btn btn-warning btn-sm" data-toggle="tooltip" title="Bascula el estado entre 0 y 1. 0 significa que está bloqueada las propuestas para la generacion actual"><i class='fas fa-traffic-light'></i> Cambiar estado de la fase </a>
    	</div>
    	</div>
    	&nbsp
    	<div class="col-md-12">
    	    TIPO DEL DEBATE: 
		<div class="btn-group">   
      		<a type="button" onclick="CambiarTipoDebate('<?php echo $id_debate;?>')" name="genlist" id="genlist" class="btn btn-warning btn-sm" data-toggle="tooltip" title="Cambia el tipo de debate siguendo el ciclo AP-IW-VI. Actúese con lógica. Solo puede hacerse en estado no activo"><i class='fab fa-tumblr'></i> Cambiar Tipo </a>
    	</div>	
    		GENERACION: 
		<div class="btn-group">   
      		<a type="button" onclick="AvanzarGEN('<?php echo $id_debate;?>')" name="genlist" id="genlist" class="btn btn-success btn-sm" data-toggle="tooltip" title="Avanza una generación. Actúese con lógica"><i class='fas fa-plus'></i> Avanzar generación </a>
    	</div>
    	<div class="btn-group">   
      		<a type="button" onclick="RetrasarGEN('<?php echo $id_debate;?>')" name="genlist" id="genlist" class="btn btn-danger btn-sm" data-toggle="tooltip" title="Retrasa una generación. Actúese con lógica, solo debería usarse para corregir errores"><i class='fas fa-minus'></i> Retrasar generación </a>
    	</div>
    	</div>


</div>
</div>

	<!-- Modal INSERCION RESPUESTA/PROPUESTA -->
	<div class="modal fade" id="add_new_record_modal" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title" id="myModalLabel">Añadir Respuesta/Propuesta</h4>
					<hr><br>
					
				</div>
				<p class="pl-3">Solo pueden añadirse respuestas/propuestas a la generacion activa y solo si el debate está activo</p>
				<div class="modal-body">
				 <div class="form-group">
				  Debate: (Bloqueado )<input type="text" class="form-control" value='<?php echo $id_debate ?>' id="idD" name="idD" disabled>
				  Generacion: (ojo a la lógica)<input type="text" class="form-control" value='<?php echo $gen ?>' id="idGen" name="idGen">
			      En respuesta a (Dejar en blanco para la 1ª generacion, ojo a la lógica):
				    <select name="propuesta" id="propuesta" class="form-control input-lg">
					<option value=null>(Escoja una de las respuestas/propuestas)</option>
					<?php include_once("datos/conexion.php");
    				$queryB = "SELECT * FROM T_PROPUESTAS WHERE id_debate = '$id_debate' AND generacion='$gen'";
					$resultB = mysqli_query($con, $queryB);
					while($rowB = mysqli_fetch_array($resultB)){
					$text=$rowB['user_nick'].': '.$rowB['texto_propuesta'];
					if(strlen($text)>90){$text=substr($text, 0, 89).' ...';}	
					echo "<option value='".$rowB['id_propuesta']."'>"."G".$rowB['generacion']."- ".$text."</option>";
					} ?>
					</select>
			      TEXTO: <textarea rows="12" class="form-control" id="texto" name="texto"></textarea>
			      </div>
				</div>	
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-success" onclick="InsertPropuestaFac()"><span class="fas fa-share"></span> Insertar</button>
				</div>
			</div>
		</div>
	</div>


	</br>
	</br>
	<!-- FIN CONTENIDO ESPECÍFICO -->
	<?php include 'base/pie.php';?>
   </body>
</html>