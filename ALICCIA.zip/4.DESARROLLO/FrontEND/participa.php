<!DOCTYPE html>
<html lang="es">
	<head>
	<?php include 'base/head.php';?>
	<script src="js/script_deb_particip.js"></script>

	</head>
	<body>
	<?php include 'base/cabecera.php';?>

	<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->

	<!-- Recogida de datos del -->

	<?php $id_debate = $_GET['debate'];
	$_SESSION['idd'] = $id_debate;
	$query = "SELECT T_DEBATES.nombre as nom_d, resumen, texto_inicial, generacion_act, imagen, tipo_debate, estado_fase, T_USUARIOS.nombre as nom_u, apellidos, nombre_gd FROM T_DEBATES LEFT JOIN T_USUARIOS 
	ON id_fac = id LEFT JOIN T_GRUPOS_DEBATE ON grupo=id_grupo_debate WHERE id_debate = '$id_debate'";
	if (!$result = mysqli_query($con,$query)) {exit(mysqli_error($con));}
	while ($row = mysqli_fetch_assoc($result)) {
	$nombre=$row['nom_d'];
	$resumen=$row['resumen'];
	$imagen=$row['imagen'];
	$texto_inicial=$row['texto_inicial'];
	$estado_fase=$row['estado_fase'];
	$nom_gd=$row['nombre_gd'];
	$genact=$row['generacion_act'];
	if($nom_gd=='ABIERTO'){$gd1="ABIERTO";$gd2="";}else{$gd1="";$gd2=" para el grupo ".$nom_gd;}
	$facilitador = $row['nom_u']." ".$row['apellidos'];
	if($row['tipo_debate']=='AP'){$tipo_d="Appgree";}
	if($row['tipo_debate']=='IW'){$tipo_d="IWarsMap";}
	if($row['tipo_debate']=='VI'){$tipo_d="Vilfredo";}
	}
	//aquí miramos si el usuario tiene ya alguna aportación a la generación
	$nom="";
	$nom_cookie='D'.$id_debate;
	if (isset($_COOKIE[$nom_cookie])){$nom=$_COOKIE[$nom_cookie];}
	if (isset($_SESSION['email'])){$nom=$_SESSION['email'];}
	
	$queryOP = "SELECT * FROM T_PROPUESTAS WHERE id_debate='$id_debate' AND user_nick='$nom' AND generacion=$genact"; // aquí podemos cambiar las restricciones de duplicados
	$num_dup=0;
	$resultOP = mysqli_query($con,$queryOP);
		while ($rowOP = mysqli_fetch_assoc($resultOP)) {$num_dup++;}

	?>


	<!-- Modal Ver Texto Propuesta -->
    <div class="modal fade" id="texto_modal" role="dialog" aria-labelledby="myModalLabel3">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <b><p>TEXTO COMPLETO</p></b>
                </div>
                <div class="modal-body">
	                <textarea rows="12" class="form-control" id="update_texto_P" disabled></textarea>
                </div> 
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                <input type="hidden" id="hidden_propuesta_id">     
                </div>
            </div>
        </div>
    </div>


    <!-- Modal Evolución -->
    <div class="modal fade" id="evolucion_modal" role="dialog" aria-labelledby="myModalLabel4">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <b><p>EVOLUCIONAR UNA PROPUESTA</p></b>
                </div>
                <div class="modal-body">
	                <textarea rows="12" class="form-control" id="update_texto_EV" name="update_texto_EV"disabled></textarea>
                </div> 
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Entendido</button>
                <input type="hidden" id="hidden_propuesta2_id">     
                </div>
            </div>
        </div>
    </div>


   <!-- Modal Insertar Valoracion -->
    <div class="modal fade" id="valoracion_modal" role="dialog" aria-labelledby="myModalLabel1">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div><b>VALORAR PROPUESTA</b><br><small>Tenga en cuenta que no se puede valorar más una vez la misma propuesta ni podrán introducirse comentarios por el propio autor de la propuesta</small></div>
                </div>
                <div class="modal-body">
                 <div class="form-group">
                  DEBATE: (Bloqueado)
                  <input type="text" class="form-control" id="vm_debate" name="vm_debate" 
                    <?php echo' value = "'.$_SESSION['idd'].'" disabled>';?>
                  EMAIL/NICK: 
                  <input type="text" class="form-control" id="vm_email_nick" name="vm_email_nick" 
                    <?php
                    //control si hay email 
                    $nom="";
                    $nom_cookie='D'.$_SESSION['idd'];
                    if (isset($_COOKIE[$nom_cookie])){$nom=$_COOKIE[$nom_cookie];}
                    if (isset($_SESSION['email'])){$nom=$_SESSION['email'];}
                    if ((isset($_COOKIE[$nom_cookie]))||(isset($_SESSION['email'])))
                    {echo' value = "'.$nom.'" disabled>';}
                    else{echo'>';}
                    ?>

                  VALORACION:
                  <select name="vm_valor" id="vm_valor" class="form-control input-lg" required>
                  <option value=null>(Escoja una opción)</option>
                  <option value=2>Totalmente de acuerdo</option>
                  <option value=1>De acuerdo pero con algún matiz...</option>
                  <option value=0>No tengo opinión formada o me es indiferente</option>
                  <option value=-1>En desacuerdo, a no ser que...</option>
                  <option value=-2>Radicalmente en desacuerdo</option>
                  </select>
                  COMENTARIO: (Opcional)
                  <textarea rows="4" class="form-control" id="vm_comentario" name="vm_comentario"></textarea>
                  </div>
                </div>  
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-warning " onclick="InsertarValoracion()"><span class="fas fa-pencil-alt"></span> Aceptar </button>
                <input type="hidden" id="hidden_propuesta_id">    
                </div>
            </div>
        </div>
    </div>

	<!-- Modal Ver Valoraciones -->
    <div class="modal fade" id="valoraciones_modal" role="dialog" aria-labelledby="myModalLabel2">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <b><p>VALORACIONES Y COMENTARIOS</p></b>
                </div>
                <div class="modal-body">
                    <div class="records_content_vv pt-2 px-2 "></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>

	<!-- INICIO Container-fluid -->
	<div class="container-fluid">
		<h8><br></h8>
		
		<!-- INICIO Row -->
		<div class="row">
			<!-- Espacio con logo -->
			<div class="col-md-1 col-sm-12">
				<h5>ESPACIO de DEBATE</h5>
				<img src="img/general/debate.png" width=100" height="100" class="align-middle align-center pr-2">
			</div>
			<!-- Fondo de los datos -->
			<div class="col-md-10 col-sm-12 fondo3 pt-2 px-4">
				<!-- Presentación/Cabecera de la encuesta -->
				<br>			
				<h3><b><?php echo $nombre;?></b></h3>
				<h5><?php echo $resumen;?></h5>
				<small class="subtitulo">Debate <?php echo $gd1;?> de tipo <?php echo $tipo_d;?>, creado por <?php echo $facilitador;echo $gd2;?></small><br><br>
				<img src="img/debates/<?php echo $imagen; ?>" width=200" height="100" class="align-middle align-center pr-2"><br>
				<hr>

					<!-- Inicio ACORDEÓN con datos -->
					<div id="accordion">
					    <div class= "fondo6 rounded border" id="headingOne">
					          <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" >
					          <h5><i class="fas fa-comments"></i> TEXTO INICIAL</h5>
					        </button>
					    </div>
					    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
					        <div class="row py-2 px-4"><?php echo $texto_inicial; ?></div>
					    </div>
					    <div class= "fondo6 rounded border" id="headingTwo">
					        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" >
					          <h5><i class="fas fa-comments"></i> RESPUESTAS/PROPUESTAS</h5>
					        </button>
					    </div>
					    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
					        <div class="px-2 pt-2">
					        	
<?php     // Diseño de tabla
   $data = '<table class="table table-bordered table-striped table-xtra-consensed">
                        <tr class="table-xtra-consensed">
                            <th width="40" style="text-align:center;">Gn</th>
                            <th width="6%" style="text-align:center; vertical-align:bottom;">fecha</th>
                            <th width="120">Nick/email</th>
                            <th width="70%">TEXTO (Se muestra solo el comienzo)</th>
                            <th width="40" style="text-align:center;" data-toggle= "tooltip" title="Ver el texto completo" target="_self">TXT</th>
                            <th width="40" style="text-align:center;" data-toggle= "tooltip" title="VALORAR/COMENTAR la propuesta" target="_self">VAL</th>
                            <th width="40">VALOR</th>
                            <th width="40" style="text-align:center" data-toggle= "tooltip" title="Ver comentarios y valoraciones" target="_self">comm</th>
                            <th width="40" style="text-align:center" data-toggle= "tooltip" title="Evolucionar propuesta" target="_self">EVO</th>                            
                        </tr>';
    
    $id_debate = $_SESSION["idd"];
    if(!isset($_SESSION['email'])){$usuario=null;}else{$usuario = $_SESSION['email'];}
    $query = "SELECT * FROM T_PROPUESTAS WHERE id_debate='$id_debate'";

    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
 
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
        $number = 1;
        while($row = mysqli_fetch_array($result))
        {
            
            $numdeb=$id_debate;
            while(strlen($numdeb)<3){$numdeb='0'.$numdeb;}
            $texto_propuesta = $row['texto_propuesta'];
            if(strlen($texto_propuesta)>100){$texto_propuesta=substr($texto_propuesta, 0, 99).' ...';} 
            $valor=$row['valoracion'];
            $color="medio";
            $gen=$row['generacion'];

            if ($valor>1){$color="alto";}
            if ($valor<0){$color="bajo";}
            $data .= '<tr class="table-xtra-consensed">
                <td style="text-align:center">'.$gen.'</td>
                <td style="text-align:center; font-size:60%"; vertical-align:middle;>'.$row['fecha'].'</td>
                <td style="text-align:center; font-size:80%"; vertical-align:middle;>'.$row['user_nick'].'</td>
                <td>'.$texto_propuesta.'</td>
                <td style="text-align:center;vertical-align:middle;">
                    <button onclick="LeerPropuesta('.$row['id_propuesta'].')" class="btn btn-secondary btn-sm"><i class="fa fa-align-justify"></i></button>
                </td>                
                <td style="text-align:center;vertical-align:middle;">
                    <button onclick="AbrirValoracion('.$row['id_propuesta'].')" class="btn btn-warning btn-sm"><i class="fa fa-hand-point-right"></i></button>
                </td>
                <td style="text-align:center" class="'.$color.'">'.$valor.'</td>
                <td style="text-align:center;vertical-align:middle;">
                    <button onclick="SelectValoraciones('.$row['id_propuesta'].')" class="btn btn-info btn-sm"><i class="far fa-eye"></i></button>
                </td>
                <td style="text-align:center;vertical-align:middle;">
                    <button onclick="EvolucionarPropuesta('.$row['id_propuesta'].')" class="btn btn-success btn-sm"><i class="fas fa-arrow-right"></i></button>
                </td>
            </tr>';
            $number++;
        }
    }
    else
    {
        // records now found 
        $data .= '<tr><td colspan="16">Aún no hay respuestas/propuestas para este debate</td></tr>';
    }
     $data .= '</table>';
     echo $data;

?>




					        </div>
					    </div>
					    <br>
				  	</div>
				  	<!-- Fin ACORDEÓN con datos -->
					<hr>
					<!-- ACORDEÓN para nueva propuesta -->
					<div>
						<div class= "fondo5 rounded border" >
					          <button class="btn btn-link" data-toggle="collapse" data-target="#collapseThree">
					          <h5><i class="fas fa-comments"></i> Inserte una nueva propuesta o evolucione una anterior </h5>
					          </button>
					    </div>
					    <small> (El formulario NO se activará si ya ha participado en esta generación o si la fase no está activa)</small>
					    <p><small>IMPORTANTE: No se permite la duplicidad de usuarios desde el mismo terminal para propuestas o valoraciones</small></p>
						<div <?php if (($num_dup==0)&&($estado_fase==1)) {echo 'id="collapseThree"';}?> class="collapse" >
							<!-- Inicio FORMULARIO para entrada datos -->
							<form action="datos/insertarParticipacion.php" method="post">
								<input type="hidden" name="id_D" id="id_D" value="<?php echo $id_debate;?>">
								<input type="hidden" name="tipo_D" id="tipo_D" value="<?php echo $tipo_d;?>">
							<!--form-groups para inserción, captcha y geolocalizacion -->
							<div class="form-group input-group-sm col-12">
								<b>INTRODUZCA UNA NUEVA PROPUESTA/RESPUESTA:</b> (Solo una por usuario cada generación )
								<br>
								





                                <textarea rows="4" cols="50" class="form-control" name="texto" id="texto" placeholder="Escriba un texto (máximo 256 caracteres)" required value=""></textarea>
                                <small>FIRMADA POR:</small>
							<?php
							//control si hay email o nick
							if ((isset($_COOKIE[$nom_cookie]))||(isset($_SESSION['email']))){
							echo'<input type="text" class="form-control" name="nick" id="nick" value="'.$nom.'" disabled >';

							}
							else{echo'<input type="text" class="form-control" name="nick" id="nick" placeholder="(necesita identificarse con un nick)" required value="">';
							}
							?>

                            <small>EN RESPUESTA A:</small>
                    <select name="propuesta" id="propuesta" class="form-control input-lg">
                    <option value=null>(Escoja una de las respuestas/propuestas si se trata de una evolución. Dejar en blanco si es nueva idea o primera generación)</option>
                    <?php 
                    $queryB = "SELECT * FROM T_PROPUESTAS WHERE id_debate = '$id_debate' AND generacion = $genact -1";
                    $resultB = mysqli_query($con, $queryB);
                    while($rowB = mysqli_fetch_array($resultB)){
                    $text=$rowB['user_nick'].': '.$rowB['texto_propuesta'];
                    if(strlen($text)>90){$text=substr($text, 0, 89).' ...';}    
                    echo "<option value='".$rowB['id_propuesta']."'>"."G".$rowB['generacion']."- ".$text."</option>";
                    } ?>
                    </select>



							</div>
							<div class="form-group input-group-sm col-3">	
								Rellene el Captcha: <img src="base/captcha.php" alt="código" data-toggle="tooltip" title="Click para refrescar" name="captcha" id="captcha" onclick="document.getElementById('captcha').src = 'base/captcha.php?'+ Math.random(); return false"><br>
								<input type="text" class="form-control" name="capt" id="capt" placeholder="(introduzca el texto de la imagen)" required value="">
							</div>
							<!--fin captcha y geolocalizacion-->
							<div class="form-group input-group-sm col-12">	
							<button type="submit" class="btn btn-info px-1" name="participa" id="participa">ENVIAR RESPUESTA/PROPUESTA</button>
							<br>
							<p class="letrilla pt-1 text-justify"><br>Por favor, antes de enviar las propuestas revise el texto del formulario. Tenga en cuenta que en algunas modalidades se permite solo una propuesta por usuario. Sobre todo chequee el captcha y si no está seguro haga clic en él y se generará otro. Hay controles internos para evitar duplicidades. En algunos casos se pide la geolocalización a efectos de establecer cortes geográficos de los resultados de la encuesta, por favor, permita la geolocalización si es requerida, puede tener un error de un centenar de metros o más.</p>
							</div>
						</div>
						
					</div>
					<!-- Fin ACORDEÓN para nueva propuesta -->
				</form>
				<!--fin FORMULARIO -->
			</div>
			<!-- Fin Fondo de los datos -->
		</div>
		<!--Fin primer ROW-->
		<br>
	</div>
	<!--FIN container-fluid-->
	<!-- FIN CONTENIDO ESPECÍFICO -->
	<?php include 'base/pie.php';?>
		<script type="text/javascript">$(document).ready(function () {});</script>
		<!--<script src="js/jquery-1.11.3.min.js"></script>-->
	</body>
</html>