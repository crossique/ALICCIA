<!DOCTYPE html>
<html lang="es">
	<head>
     	<?php include 'base/head.php';?>
      <script src="js/go.js"></script>
      <script src="js/script_debatesU.js"></script>
	</head>
	<body>
	   	<?php include 'base/cabecera.php';?>

	   	<!-- CONTENIDO ESPECÍFICO DE PÁGINA -->

  <!-- Modal Ver DESARROLLO con GoJS -->
    <div class="modal fade" id="arbol_modal" role="dialog" aria-labelledby="myModalLabel3">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <b><p>ARBOL</p></b>
                </div>
                <div class="modal-body">
                  <div class="px-2 py-2"><div class="arbol_gojs pt-2 px-2 "></div></div>
                </div> 
                <div class="modal-footer">
                    <button type="button" class="btn btn-success " onclick="refresh()"> OK </button>
                <input type="hidden" id="hidden_propuesta_id2">     
                </div>
            </div>
        </div>
    </div>
	
<div class="container-fluid px-2 pt-2">
  <h4 class = "px-2">Zona de Debates y Preguntas Abiertas <i class="far fa-comments"></i></h4>
	<div id="accordion">
    <div class= "fondo6 rounded border" id="headingOne">
          <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          <h5><i class="fas fa-comments"></i> Mis debates activos en curso</h5>
        </button>
    </div>
    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
        <div class="records_content_da px-2"></div>
    </div>
    <div class= "fondo6 rounded border" id="headingTwo">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          <h5><i class="fas fa-comments"></i> Debates ya cerrados (Con resultados finales)</h5>
        </button>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
        <div class="records_content_dr px-2"></div>
    </div>
    <div class="pt-2"></div>
</div> 
</div>

<!--<script> jQuery(document).ready(function($) { var delay = 100; setTimeout(function() { $('.elementor-tab-title').removeClass('elementor-active'); $('.elementor-tab-content').css('display', 'none'); }, delay); }); </script>-->

		<!-- FIN CONTENIDO ESPECÍFICO -->

		<?php include 'base/pie.php';?>
   </body>
</html>