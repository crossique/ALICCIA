# -*- coding: utf-8 -*-
import sys
import json
import os
from algebra_client_4 import resolver_operacion

def respuesta_json(resultado="", consola=""):
    print(json.dumps({
        "resultado": resultado,
        "consola": consola
    }))
    sys.exit(0)

def validar_longitud(texto, minimo, maximo):
    palabras = texto.strip().split()
    return minimo <= len(palabras) <= maximo

def main():
    try:
        if len(sys.argv) < 2:
            respuesta_json("", "No se han recibido argumentos desde PHP.")

        datos = json.loads(sys.argv[1])

        tema = datos.get("tema", "").strip()
        p1 = datos.get("p1", "").strip()
        p2 = datos.get("p2", "").strip()
        valoracion = datos.get("valoracion", "").strip()
        operacion = datos.get("operacion", "").strip().upper()
        debug = datos.get("debug", False)

        binarias = ["UNION", "INTERSECCION", "CONSENSO", "CERCANIA"]
        unarias = ["SIMPLIFICAR", "GENERALIZAR", "ENMIENDA_PLUS", "ENMIENDA_MINUS"]

        if operacion in binarias:
            if not validar_longitud(p1, 10, 300) or not validar_longitud(p2, 10, 300):
                respuesta_json("", "Alguna de las propuestas es demasiado corta o demasiado larga.")
            resultado = resolver_operacion(tema, p1, p2, operacion, debug)

        elif operacion in unarias:
            if not validar_longitud(p1, 10, 300):
                respuesta_json("", "La propuesta es demasiado corta o demasiado larga.")
            if operacion in ["ENMIENDA_PLUS", "ENMIENDA_MINUS"]:
                if not validar_longitud(valoracion, 5, 100):
                    respuesta_json("", "La valoración es demasiado corta o demasiado larga.")
            resultado = resolver_operacion(tema, p1, p2, operacion, debug, valoracion)

        else:
            respuesta_json("", "Operación no reconocida: {}".format(operacion))

        respuesta_json(resultado, "")

    except Exception as e:
        respuesta_json("", "Error al procesar: {}".format(str(e)))

if __name__ == "__main__":
    main()
