<?php
$resultado = "";
$consola = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'ejecutar') {
    $tema = $_POST['tema'] ?? '';
    $p1 = $_POST['p1'] ?? '';
    $p2 = $_POST['p2'] ?? '';
    $valoracion = $_POST['valoracion'] ?? '';
    $operacion = $_POST['operacion'] ?? '';

    $datos = [
        "tema" => $tema,
        "p1" => $p1,
        "p2" => $p2,
        "valoracion" => $valoracion,
        "operacion" => $operacion
    ];

    $json_args = escapeshellarg(json_encode($datos));

    $comando = "bash run_backend.sh $json_args 2>&1";
    $output = shell_exec($comando);

    $resultado_json = json_decode($output, true);

    if (is_array($resultado_json)) {
        $resultado = $resultado_json['resultado'] ?? '';
        $consola = $resultado_json['consola'] ?? 'Consola vacía';
    } else {
        $resultado = '';
        $consola = "Error: No se pudo decodificar JSON\nSalida cruda:\n" . $output;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Operaciones del Álgebra Deliberativa</title>
    <?php include 'base/head.php'; ?>
    <style>
        textarea { width: 100%; height: 100px; margin-bottom: 10px; }
        select, button { margin-top: 10px; }
        label { font-weight: bold; display: block; margin-top: 10px; }
    </style>
</head>
<body>
    <?php include 'base/cabecera.php'; ?>

    <div class="container mt-4">
        <h2>Facilitador de Inteligencia Colectiva - Álgebra de Propuestas</h2>

        <form method="post">
            <label for="tema">Tema / Problema / Pregunta:</label>
            <textarea name="tema" id="tema"><?php echo $_POST['tema'] ?? ''; ?></textarea>

            <label for="p1">Propuesta A:</label>
            <textarea name="p1" id="p1"><?php echo $_POST['p1'] ?? ''; ?></textarea>

            <label for="p2">Propuesta B (opcional):</label>
            <textarea name="p2" id="p2"><?php echo $_POST['p2'] ?? ''; ?></textarea>

            <label for="valoracion">Valoración (opcional):</label>
            <textarea name="valoracion" id="valoracion"><?php echo $_POST['valoracion'] ?? ''; ?></textarea>

            <label for="operacion">Operación:</label>
            <select name="operacion" id="operacion">
                <?php
                $operaciones = ["UNION", "INTERSECCION", "CONSENSO", "ENMIENDA_PLUS", "ENMIENDA_MINUS", "CERCANIA", "SIMPLIFICAR", "GENERALIZAR"];
                foreach ($operaciones as $opcion) {
                    $selected = ($_POST['operacion'] ?? '') === $opcion ? 'selected' : '';
                    echo "<option value=\"$opcion\" $selected>$opcion</option>";
                }
                ?>
            </select><br>

            <button type="submit" name="accion" value="ejecutar">Ejecutar</button>
            <button type="button" onclick="intercambiar()">Intercambiar</button>
        </form>

        <label for="resultado">Resultado:</label>
        <textarea id="resultado" readonly><?php echo htmlspecialchars($resultado); ?></textarea>

        <label for="consola">Salida de consola:</label>
        <textarea id="consola" readonly><?php echo htmlspecialchars($consola); ?></textarea>
    </div>

    <script>
        function intercambiar() {
            let p1 = document.getElementById("p1");
            let p2 = document.getElementById("p2");
            let temp = p1.value;
            p1.value = p2.value;
            p2.value = temp;
        }
    </script>

    <?php include 'base/pie.php'; ?>
</body>
</html>
