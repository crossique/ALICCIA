# -*- coding: utf-8 -*-
import os
import json
import requests
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
API_URL = "https://api.openai.com/v1/chat/completions"

HEADERS = {
    "Authorization": f"Bearer {OPENAI_API_KEY}",
    "Content-Type": "application/json"
}

# Creamos la sesión persistente
session = requests.Session()
session.headers.update(HEADERS)


def resolver_operacion(tema, p1, p2, operacion, debug=False, valoracion=None):
    try:
        prompt = construir_prompt(tema, p1, p2, operacion, valoracion)

        if debug:
            return "[DEBUG] Prompt:\n{}".format(prompt)

        payload = {
            "model": "gpt-4",
            "messages": [
                {"role": "system", "content": "Eres un asistente experto en combinar y analizar propuestas."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.2
        }

        response = session.post(API_URL, data=json.dumps(payload), timeout=20)

        if response.status_code == 200:
            data = response.json()
            return data["choices"][0]["message"]["content"].strip()
        else:
            return f"Error en la respuesta de OpenAI ({response.status_code}): {response.text}"

    except requests.exceptions.Timeout:
        return "Timeout: la solicitud a OpenAI tardó demasiado."
    except Exception as e:
        return f"Error al contactar con OpenAI: {str(e)}"


def construir_prompt(tema, p1, p2, operacion, valoracion):
    if operacion in ["UNION", "INTERSECCION", "CONSENSO", "CERCANIA"]:
        return ("Dado el tema '{}', y dos propuestas:\n\nA: {}\n\nB: {}\n\n"
                "Realiza la operación de tipo '{}' entre ambas.").format(tema, p1, p2, operacion)
    
    elif operacion in ["SIMPLIFICAR", "GENERALIZAR"]:
        return ("Dado el tema '{}', y la propuesta:\n\n{}\n\n"
                "Realiza la operación de tipo '{}' sobre ella.").format(tema, p1, operacion)

    elif operacion in ["ENMIENDA_PLUS", "ENMIENDA_MINUS"]:
        return ("Dado el tema '{}', la propuesta:\n\n{}\n\n"
                "Y esta valoración del ciudadano:\n\n{}\n\n"
                "Realiza la operación de tipo '{}' combinando ambos elementos.").format(
                    tema, p1, valoracion, operacion)

    else:
        return f"Operación no reconocida: {operacion}"
