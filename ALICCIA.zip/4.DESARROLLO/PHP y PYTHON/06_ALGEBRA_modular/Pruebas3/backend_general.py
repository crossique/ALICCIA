# -*- coding: utf-8 -*-
import sys
import json
from algebra_client_4 import resolver_operacion

try:
    # Leer los argumentos JSON desde línea de comandos
    input_json = sys.argv[1]
    datos = json.loads(input_json)

    tema = datos.get("tema", "").strip()
    p1 = datos.get("p1", "").strip()
    p2 = datos.get("p2", "").strip()
    valoracion = datos.get("valoracion", "").strip()
    operacion = datos.get("operacion", "").strip().lower()

    resultado = resolver_operacion(tema, p1, p2, operacion, valoracion=valoracion)
    print(json.dumps({"resultado": resultado, "consola": ""}))

except Exception as e:
    print(json.dumps({"resultado": "", "consola": f"Error al procesar: {str(e)}"}))
