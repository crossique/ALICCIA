# -*- coding: utf-8 -*-
import os
import json
import requests
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
API_URL = "https://api.openai.com/v1/chat/completions"
HEADERS = {
    "Content-Type": "application/json",
    "Authorization": f"Bearer {OPENAI_API_KEY}",
}

def construir_prompt(tema, p1, p2, operacion, valoracion=None):
    prompts = {
        "union": f"Dado el tema '{tema}' y las siguientes dos propuestas:\n\nPropuesta A:\n{p1}\n\nPropuesta B:\n{p2}\n\nFusiona ambas en una propuesta unificada que mantenga los aspectos esenciales de cada una.",
        "interseccion": f"Dado el tema '{tema}' y las siguientes dos propuestas:\n\nPropuesta A:\n{p1}\n\nPropuesta B:\n{p2}\n\nExtrae los elementos comunes entre ambas propuestas.",
        "consenso": f"Dado el tema '{tema}' y las siguientes dos propuestas:\n\nPropuesta A:\n{p1}\n\nPropuesta B:\n{p2}\n\nGenera una nueva propuesta que represente un consenso equilibrado entre ambas.",
        "cercania": f"Dado el tema '{tema}', evalúa en una escala del 0 al 10 cuán similares o cercanas son las siguientes propuestas:\n\nPropuesta A:\n{p1}\n\nPropuesta B:\n{p2}\n\nDevuelve únicamente un número entero entre 0 y 10.",
        "enmienda_plus": f"Dado el tema '{tema}' y la siguiente propuesta:\n\n{p1}\n\nTeniendo en cuenta la valoración positiva que se detalla a continuación:\n\n{valoracion}\n\nRedacta una nueva versión mejorada de la propuesta que potencie sus virtudes.",
        "enmienda_minus": f"Dado el tema '{tema}' y la siguiente propuesta:\n\n{p1}\n\nTeniendo en cuenta la valoración crítica que se detalla a continuación:\n\n{valoracion}\n\nRedacta una nueva versión corregida de la propuesta que subsane sus defectos.",
        "simplificar": f"Dado el tema '{tema}' y la siguiente propuesta:\n\n{p1}\n\nRedáctala de forma más breve y sencilla sin perder el contenido esencial.",
        "generalizar": f"Dado el tema '{tema}' y la siguiente propuesta:\n\n{p1}\n\nRedáctala de forma más general y amplia, de modo que pueda aplicarse a más contextos.",
    }
    return prompts.get(operacion.lower(), "Operación no reconocida.")

def llamar_a_openai(prompt, debug=False):
    data = {
        "model": "gpt-3.5-turbo",
        "temperature": 0.7,
        "messages": [{"role": "user", "content": prompt}],
    }

    if debug:
        print("PROMPT ENVIADO A OPENAI:")
        print(prompt)

    response = requests.post(API_URL, headers=HEADERS, json=data)

    if response.status_code == 200:
        content = response.json()["choices"][0]["message"]["content"].strip()
        return content
    else:
        raise Exception(f"Error al contactar con OpenAI: {response.text}")

def resolver_operacion(tema, p1, p2, operacion, valoracion=None, debug=False):
    prompt = construir_prompt(tema, p1, p2, operacion, valoracion)
    return llamar_a_openai(prompt, debug=debug)
