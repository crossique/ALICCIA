<?php
if (in_array('shell_exec', explode(',', ini_get('disable_functions')))) {
    echo "⚠️ shell_exec está deshabilitado en php.ini";
} else {
    echo "✅ shell_exec está habilitado<br>";
    echo "Ruta de python3: " . shell_exec("which python3");
}
?>