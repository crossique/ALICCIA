# -*- coding: utf-8 -*-
import time
from algebra_client_4 import resolver_operacion

# Entradas de prueba
tema = "Transporte urbano sostenible"
p1 = "Incrementar la frecuencia de autobuses eléctricos en las horas punta para reducir el uso del coche particular."
p2 = "Crear una red de carriles bici protegidos que conecten los barrios periféricos con el centro."
operacion = "UNION"

# Número de repeticiones para medir tiempo promedio
N = 3
tiempos = []

print("⏱️ Iniciando test de rendimiento...\n")

for i in range(N):
    inicio = time.time()
    resultado = resolver_operacion(tema, p1, p2, operacion)
    fin = time.time()
    duracion = fin - inicio
    tiempos.append(duracion)
    print(f"Prueba {i+1}: {duracion:.2f} segundos")

media = sum(tiempos) / N
print(f"\n⏳ Tiempo promedio sobre {N} llamadas: {media:.2f} segundos")
