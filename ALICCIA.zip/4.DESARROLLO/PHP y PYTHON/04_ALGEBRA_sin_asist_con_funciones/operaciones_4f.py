import sys
import io
import os
import json
from datetime import datetime
from dotenv import load_dotenv
from openai import OpenAI

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
LOG_FILE = os.path.join(os.path.dirname(__file__), "debug_py.log")

def log(msg):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now()} | {msg}\n")

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    log("[ERROR] No se encontró OPENAI_API_KEY en .env")
    print("[ERROR: clave OpenAI no disponible]")
    sys.exit(1)

client = OpenAI(api_key=api_key)

# Leer entrada JSON desde stdin
try:
    raw_input = sys.stdin.read()
    log(f"[DEBUG] JSON recibido:\n{raw_input}")
    input_data = json.loads(raw_input)
except Exception as e:
    log(f"[ERROR] JSON inválido: {e}")
    print("[ERROR: entrada JSON no válida]")
    sys.exit(1)

# Extraer campos del input
tema = input_data.get("tema", "").strip()
p1 = input_data.get("p1", "").strip()
p2 = input_data.get("p2", "").strip()
op = input_data.get("op", "").strip().lower()

if not tema or not op:
    log("[ERROR] Faltan datos obligatorios")
    print("[ERROR: datos incompletos]")
    sys.exit(1)

log(f"[OK] Operación solicitada: {op}")

# Generar el prompt según la operación
mensaje_usuario = ""
if op == "union":
    mensaje_usuario = f"Operación: UNION\nTema: {tema}\nPropuesta A: {p1}\nPropuesta B: {p2}"
elif op == "interseccion":
    mensaje_usuario = f"Operación: INTERSECCION\nTema: {tema}\nPropuesta A: {p1}\nPropuesta B: {p2}"
elif op == "cercania":
    mensaje_usuario = f"Operación: CERCANIA\nTema: {tema}\nPropuesta A: {p1}\nPropuesta B: {p2}"
elif op == "simplificar_p1":
    mensaje_usuario = f"Operación: SIMPLIFICAR\nPropuesta: {p1}"
elif op == "simplificar_p2":
    mensaje_usuario = f"Operación: SIMPLIFICAR\nPropuesta: {p2}"
elif op == "chequear_p1":
    mensaje_usuario = f"Operación: VALIDAR_T\nTema: {tema}\nPropuesta: {p1}"
elif op == "chequear_p2":
    mensaje_usuario = f"Operación: VALIDAR_T\nTema: {tema}\nPropuesta: {p2}"
else:
    log(f"[ERROR] Operación desconocida: {op}")
    print(f"[ERROR: operación desconocida: {op}]")
    sys.exit(1)

try:
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "Actúas como un facilitador de inteligencia colectiva y consenso. Tu función es aplicar operaciones de álgebra deliberativa sobre propuestas ciudadanas, siguiendo reglas específicas para cada operación."},
            {"role": "user", "content": mensaje_usuario}
        ],
        temperature=0.3
    )
    contenido = response.choices[0].message.content.strip()
    log(f"[OK] Respuesta recibida:\n{contenido}")
    print(contenido)

except Exception as e:
    log(f"[ERROR] Fallo en la llamada a OpenAI: {e}")
    print(f"[ERROR: fallo en llamada OpenAI] {e}")
    sys.exit(1)
