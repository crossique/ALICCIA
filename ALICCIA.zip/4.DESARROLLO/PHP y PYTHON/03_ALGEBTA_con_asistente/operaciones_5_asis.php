<?php
// No incluir session_start si ya está en cabecera.php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$respuesta = '';
$log = '';
$thread_id = $_SESSION['thread_id'] ?? null;

$tema = '';
$p1 = '';
$p2 = '';
$operacion = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tema = $_POST['tema'] ?? '';
    $p1 = $_POST['propuestaA'] ?? '';
    $p2 = $_POST['propuestaB'] ?? '';
    $operacion = $_POST['operacion'] ?? '';
    $chequear = $_POST['chequear'] ?? '';

    // Tabla de equivalencias de códigos para el asistente
    $map = [
        "UNION" => "UNION",
        "INTERSECCION" => "INTERSECCION",
        "CERCANIA" => "CERCANIA",
        "SIMPLIFICAR_P1" => "SIMPLIFICAR",
        "SIMPLIFICAR_P2" => "SIMPLIFICAR",
        "VALIDAR_O" => "VALIDAR_O",
        "VALIDAR_T" => "VALIDAR_T",
        "ENMIENDA_PLUS" => "ENMIENDA+",
        "ENMIENDA_MINUS" => "ENMIENDA-"
    ];

    // Resolver operación real que se enviará al LLM
    $operacion_seleccionada = $chequear === "p1" || $chequear === "p2" ? "VALIDAR_T" : strtoupper($operacion);
    $op_code = $map[$operacion_seleccionada] ?? "UNION";

    // Construir mensaje para el asistente
    $contenido = "Operación: $op_code\nTema: $tema\n";

    if ($op_code === "SIMPLIFICAR") {
        $contenido .= $operacion === "SIMPLIFICAR_P1" ? "Propuesta A: $p1\n" : "Propuesta B: $p2\n";
    } elseif ($op_code === "VALIDAR_T") {
        $contenido .= $chequear === "p1" ? "Propuesta A: $p1\n" : "Propuesta B: $p2\n";
    } else {
        $contenido .= "Propuesta A: $p1\nPropuesta B: $p2\n";
    }

    $input_array = [
        "contenido" => $contenido,
        "thread_id" => $thread_id
    ];

    $json_input = json_encode($input_array, JSON_UNESCAPED_UNICODE);
    file_put_contents("py/temp_input.json", $json_input);

    $cmd = "/usr/src/Python-3.9.18/venv_openai/bin/python3 py/operaciones_5_asis.py < py/temp_input.json";
    $salida = shell_exec($cmd);

    file_put_contents("debug_raw.log", "CMD:\n$cmd\nSALIDA:\n$salida\n\n", FILE_APPEND);

    if (!$salida) {
        $respuesta = '[ERROR: el script no devolvió salida]';
    } else {
        $respuesta_data = json_decode($salida, true);
        if (isset($respuesta_data['error'])) {
            $respuesta = '[ERROR: ' . $respuesta_data['error'] . ']';
        } else {
            $_SESSION['thread_id'] = $respuesta_data['thread_id'] ?? null;
            $respuesta = $respuesta_data['respuesta'] ?? '[ERROR: sin respuesta]';
            if ($chequear) {
                $log = $respuesta;
                $respuesta = '';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<?php include 'base/head.php'; ?>
</head>
<body>
<?php include 'base/cabecera.php'; ?>

<div class="container mt-4">
    <h2>Operaciones de Álgebra Deliberativa (con Asistente persistente)</h2>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Tema / Problema</label>
            <input type="text" class="form-control" name="tema" required value="<?= htmlspecialchars($tema) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Propuesta A</label>
            <textarea name="propuestaA" class="form-control" rows="3" required><?= htmlspecialchars($p1) ?></textarea>
            <button name="chequear" value="p1" class="btn btn-sm btn-outline-secondary mt-1">Chequear validez</button>
        </div>

        <div class="mb-3">
            <label class="form-label">Propuesta B</label>
            <textarea name="propuestaB" class="form-control" rows="3" required><?= htmlspecialchars($p2) ?></textarea>
            <button name="chequear" value="p2" class="btn btn-sm btn-outline-secondary mt-1">Chequear validez</button>
        </div>

        <div class="mb-3 d-flex align-items-end">
            <div class="flex-grow-1 me-2">
                <label class="form-label">Operación</label>
                <select name="operacion" class="form-select" required>
                    <option value="UNION" <?= $operacion === 'UNION' ? 'selected' : '' ?>>Unión</option>
                    <option value="INTERSECCION" <?= $operacion === 'INTERSECCION' ? 'selected' : '' ?>>Intersección</option>
                    <option value="CERCANIA" <?= $operacion === 'CERCANIA' ? 'selected' : '' ?>>Cercanía</option>
                    <option value="SIMPLIFICAR_P1" <?= $operacion === 'SIMPLIFICAR_P1' ? 'selected' : '' ?>>Simplificar Propuesta A</option>
                    <option value="SIMPLIFICAR_P2" <?= $operacion === 'SIMPLIFICAR_P2' ? 'selected' : '' ?>>Simplificar Propuesta B</option>
                    <option value="VALIDAR_O" <?= $operacion === 'VALIDAR_O' ? 'selected' : '' ?>>Validar Ortografía</option>
                    <option value="VALIDAR_T" <?= $operacion === 'VALIDAR_T' ? 'selected' : '' ?>>Validar con el Tema</option>
                    <option value="ENMIENDA_PLUS" <?= $operacion === 'ENMIENDA_PLUS' ? 'selected' : '' ?>>Enmienda positiva</option>
                    <option value="ENMIENDA_MINUS" <?= $operacion === 'ENMIENDA_MINUS' ? 'selected' : '' ?>>Enmienda negativa</option>
                </select>
            </div>
            <div>
                <label class="form-label d-block invisible">Ejecutar</label>
                <button type="submit" class="btn btn-primary">Ejecutar operación</button>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Propuesta resultado</label>
            <textarea class="form-control" rows="3" readonly><?= htmlspecialchars($respuesta) ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Salida de consola</label>
            <textarea class="form-control" rows="2" readonly><?= htmlspecialchars($log) ?></textarea>
        </div>
    </form>
</div>

<?php include 'base/pie.php'; ?>
</body>
</html>
