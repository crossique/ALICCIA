import sys
import io
import os
import json
import time
from openai import OpenAI
from dotenv import load_dotenv

# Forzar salida UTF-8
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Logging de depuración
DEBUG_LOG = "py/debug_py.log"
def log(msg):
    with open(DEBUG_LOG, "a", encoding="utf-8") as f:
        f.write(msg + "\n")

log("--- INICIO SCRIPT ---")

# Cargar variables de entorno
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
assistant_id = os.getenv("OPENAI_ASSISTANT_ID")

log(f"API KEY PRESENTE: {'SÍ' if api_key else 'NO'}")
log(f"ASSISTANT_ID: {assistant_id}")

if not api_key or not assistant_id:
    print(json.dumps({"error": "Falta OPENAI_API_KEY o OPENAI_ASSISTANT_ID en .env"}))
    sys.exit(1)

client = OpenAI(api_key=api_key)

# Leer JSON de stdin
try:
    raw_input = sys.stdin.read()
    log(f"RAW INPUT: {raw_input}")
    input_data = json.loads(raw_input)
except Exception as e:
    print(json.dumps({"error": f"JSON inválido: {str(e)}"}))
    sys.exit(1)

contenido = input_data.get("contenido", "").strip()
thread_id = input_data.get("thread_id")

if not contenido:
    print(json.dumps({"error": "Falta contenido"}))
    sys.exit(1)

# Crear hilo si es necesario
if not thread_id:
    thread = client.beta.threads.create()
    thread_id = thread.id
    log(f"CREADO NUEVO THREAD: {thread_id}")
else:
    log(f"USANDO THREAD EXISTENTE: {thread_id}")

# Añadir mensaje
client.beta.threads.messages.create(
    thread_id=thread_id,
    role="user",
    content=contenido
)

# Ejecutar asistente
run = client.beta.threads.runs.create(
    thread_id=thread_id,
    assistant_id=assistant_id
)

# Esperar a que termine
while True:
    run = client.beta.threads.runs.retrieve(thread_id=thread_id, run_id=run.id)
    if run.status == "completed":
        log("RUN COMPLETADO")
        break
    elif run.status == "failed":
        print(json.dumps({"error": "Fallo en la ejecución"}))
        log("RUN FALLÓ")
        sys.exit(1)
    time.sleep(0.5)

# Recuperar mensaje
messages = client.beta.threads.messages.list(thread_id=thread_id)
if not messages.data or not messages.data[0].content:
    print(json.dumps({"error": "No se encontró mensaje de respuesta"}))
    log("NO HAY MENSAJE EN RESPUESTA")
    sys.exit(1)

respuesta = messages.data[0].content[0].text.value.strip()
log(f"RESPUESTA: {respuesta}")

print(json.dumps({
    "respuesta": respuesta,
    "thread_id": thread_id
}))

