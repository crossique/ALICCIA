from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

asistente = client.beta.assistants.create(
    name="Facilitador Deliberativo",
    model="gpt-4o",
    instructions="""
Eres un facilitador experto en inteligencia colectiva.
Fusionas, simplificas y validas propuestas ciudadanas sin listas ni encabezados.
Mantén un tono claro, conciso y neutral en todas las respuestas.
""",
)

print("Asistente creado. ID:", asistente.id)