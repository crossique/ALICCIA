
import random
import numpy

from deap import base
from deap import creator
from deap import tools

# --- 1. Definición del Problema y Datos Iniciales ---

# Número de usuarios y propuestas
NUM_USERS = 9
NUM_PROPOSALS = 4

# Simulación de datos iniciales para 4 propuestas en el Frente de Pareto
# Cada propuesta es un diccionario con 'apoyos' y 'rechazos'
# Los usuarios se representan como 'U1', 'U2', etc.
# Los rechazos se representan como 'R1', 'R2', etc.

# Ejemplo de datos iniciales (esto debería venir de tu sistema real)
initial_proposals_data = {
    "P1": {"apoyos": {"U1", "U2", "U3"}, "rechazos": {"R4", "R5"}},
    "P2": {"apoyos": {"U2", "U4", "U6"}, "rechazos": {"R1", "R3"}},
    "P3": {"apoyos": {"U1", "U5", "U7"}, "rechazos": {"R2", "R6"}},
    "P4": {"apoyos": {"U3", "U8", "U9"}, "rechazos": {"R7", "R9"}},
}

# Mapeo de usuarios y rechazos a un formato numérico para facilitar el cálculo
# U1 -> 0, U2 -> 1, ..., R1 -> 0, R2 -> 1, ...
user_map = {f"U{i+1}": i for i in range(NUM_USERS)}
reject_map = {f"R{i+1}": i for i in range(NUM_USERS)}

# --- 2. Definición de la Representación del Individuo ---

# Un individuo (una posible propuesta de consenso final) se representará como:
# Una lista de NUM_USERS booleanos, donde True significa apoyo y False significa rechazo.
# Por ejemplo, [True, True, False, False, ...] significaría U1 apoya, U2 apoya, U3 rechaza, U4 rechaza, ...

creator.create("FitnessMax", base.Fitness, weights=(1.0,))
creator.create("Individual", list, fitness=creator.FitnessMax)

# --- 3. Inicialización de la Población ---

toolbox = base.Toolbox()

# Atributo: un booleano aleatorio (apoyo/rechazo de un usuario)
toolbox.register("attr_bool", random.randint, 0, 1) # 0 para rechazo, 1 para apoyo

# Individuo: una lista de NUM_USERS atributos booleanos
toolbox.register("individual", tools.initRepeat, creator.Individual, toolbox.attr_bool, NUM_USERS)

# Población: una lista de individuos
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

# --- 4. Función de Aptitud (Fitness Function) ---

# Esta es la parte crucial y más compleja. Necesita reflejar el "consenso".
# Una propuesta de consenso ideal tendría todos los usuarios apoyándola y ninguno rechazándola.
# La función de aptitud debe penalizar los rechazos y recompensar los apoyos.
# También debe considerar la "cercanía" a las propuestas iniciales y el "cambio de opinión".

# Simplificación para el ejemplo: la aptitud se basa en:
# 1. Número de apoyos en la propuesta de consenso.
# 2. Penalización por número de rechazos en la propuesta de consenso.
# 3. "Cercanía" a las propuestas iniciales (cuántos usuarios de las propuestas iniciales
#    apoyan/rechazan de la misma manera en la propuesta de consenso).
# 4. Penalización por "cambio de opinión" (si un usuario que apoyaba una P_i ahora rechaza la P_final, o viceversa).

# Pesos para las diferentes componentes de la aptitud
WEIGHT_SUPPORTS = 1.0
WEIGHT_REJECTS = -2.0 # Penalización mayor por rechazos
WEIGHT_CLOSENESS = 0.5
WEIGHT_OPINION_CHANGE = -1.5 # Penalización por cambio de opinión

def evaluate(individual):
    # individual es una lista de 0s y 1s (0=rechazo, 1=apoyo)
    
    num_supports = sum(individual) # Número de usuarios que apoyan
    num_rejects = NUM_USERS - num_supports # Número de usuarios que rechazan

    closeness_score = 0.0
    opinion_change_penalty = 0.0

    # Calcular cercanía y penalización por cambio de opinión con respecto a las propuestas iniciales
    for p_name, p_data in initial_proposals_data.items():
        for user_str in user_map.keys():
            user_idx = user_map[user_str]
            
            # Si el usuario apoya la propuesta inicial
            if user_str in p_data["apoyos"]:
                if individual[user_idx] == 1: # Apoya también la propuesta de consenso
                    closeness_score += 1
                else: # Cambia de apoyo a rechazo
                    opinion_change_penalty += 1
            
            # Si el usuario rechaza la propuesta inicial
            elif user_str.replace("U", "R") in p_data["rechazos"]:
                if individual[user_idx] == 0: # Rechaza también la propuesta de consenso
                    closeness_score += 1
                else: # Cambia de rechazo a apoyo
                    opinion_change_penalty += 1
            # Si el usuario no estaba en la propuesta inicial (NS/NC), no se considera cambio de opinión

    # La aptitud es una combinación ponderada de las métricas
    fitness = (num_supports * WEIGHT_SUPPORTS +
               num_rejects * WEIGHT_REJECTS +
               closeness_score * WEIGHT_CLOSENESS +
               opinion_change_penalty * WEIGHT_OPINION_CHANGE)

    return fitness, # La tupla es necesaria para DEAP

toolbox.register("evaluate", evaluate)

# --- 5. Operadores Genéticos ---

# Crossover (cruce): Intercambia partes de dos individuos
toolbox.register("mate", tools.cxTwoPoint)

# Mutation (mutación): Cambia aleatoriamente algunos bits (apoyos/rechazos)
toolbox.register("mutate", tools.mutFlipBit, indpb=0.05) # indpb es la probabilidad de mutar cada bit

# Selection (selección): Elige los mejores individuos para la siguiente generación
toolbox.register("select", tools.selTournament, tournsize=3)

# --- 6. Algoritmo Genético Principal ---

def main():
    random.seed(42) # Para reproducibilidad

    population = toolbox.population(n=50) # Tamaño de la población
    ngen = 100 # Número de generaciones
    cxpb = 0.7 # Probabilidad de cruce
    mutpb = 0.2 # Probabilidad de mutación

    # Evaluar la aptitud de los individuos iniciales
    for ind in population:
        ind.fitness.values = toolbox.evaluate(ind)

    print("\n--- Comienza la evolución ---")

    for gen in range(ngen):
        # Seleccionar los individuos para la próxima generación
        offspring = toolbox.select(population, len(population))
        # Clonar los individuos seleccionados
        offspring = list(map(toolbox.clone, offspring))

        # Aplicar cruce en la descendencia
        for child1, child2 in zip(offspring[::2], offspring[1::2]):
            if random.random() < cxpb:
                toolbox.mate(child1, child2)
                del child1.fitness.values
                del child2.fitness.values

        # Aplicar mutación en la descendencia
        for mutant in offspring:
            if random.random() < mutpb:
                toolbox.mutate(mutant)
                del mutant.fitness.values

        # Evaluar los individuos con aptitud inválida
        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        for ind in invalid_ind:
            ind.fitness.values = toolbox.evaluate(ind)

        # Reemplazar la población antigua con la nueva generación
        population[:] = offspring

        # Imprimir estadísticas (opcional)
        fits = [ind.fitness.values[0] for ind in population]
        length = len(population)
        mean = sum(fits) / length
        sum2 = sum(x*x for x in fits)
        std = abs(sum2 / length - mean**2)**0.5

        print(f"Generación {gen}: Min {min(fits):.2f}, Max {max(fits):.2f}, Avg {mean:.2f}, Std {std:.2f}")

    print("\n--- Fin de la evolución ---")

    best_individual = tools.selBest(population, 1)[0]
    print(f"Mejor individuo encontrado: {best_individual}")
    print(f"Aptitud del mejor individuo: {best_individual.fitness.values[0]:.2f}")

    # Convertir el mejor individuo a un formato legible
    final_proposal_supports = []
    final_proposal_rejects = []
    for i, val in enumerate(best_individual):
        if val == 1:
            final_proposal_supports.append(f"U{i+1}")
        else:
            final_proposal_rejects.append(f"R{i+1}")

    print("\nPropuesta de Consenso Final Sugerida:")
    print(f"  Apoyos: {final_proposal_supports if final_proposal_supports else 'Ninguno'}")
    print(f"  Rechazos: {final_proposal_rejects if final_proposal_rejects else 'Ninguno'}")

if __name__ == "__main__":
    main()


