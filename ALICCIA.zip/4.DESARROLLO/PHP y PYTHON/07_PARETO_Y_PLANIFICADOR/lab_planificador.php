<?php
// lab_planificador.php
// Incluye marco de la aplicación
include 'head.php';
include 'cabecera.php';

// Si se envía petición AJAX desde el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $json = file_get_contents('php://input');
    $cmd = 'python3 planificador.py';
    $descriptors = [
        ["pipe", "r"], // stdin
        ["pipe", "w"], // stdout
        ["pipe", "w"]  // stderr
    ];
    $process = proc_open($cmd, $descriptors, $pipes);
    if (is_resource($process)) {
        fwrite($pipes[0], $json);
        fclose($pipes[0]);
        $output = stream_get_contents($pipes[1]); fclose($pipes[1]);
        $error  = stream_get_contents($pipes[2]); fclose($pipes[2]);
        proc_close($process);
        if ($error) {
            http_response_code(500);
            echo json_encode(['error' => $error]);
        } else {
            header('Content-Type: application/json');
            echo $output;
        }
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'No se pudo iniciar planificador.py']);
    }
    exit;
}
?>

<div class="container">
  <h1>Planificador de Consenso</h1>
  <form id="plannerForm" onsubmit="return false;">
    <div class="row">
      <!-- Cajas de propuestas Prop1..Prop4 -->
      <?php foreach (['Prop1','Prop2','Prop3','Prop4'] as $p): ?>
        <div class="col-md-3">
          <h4><?php echo \$p; ?></h4>
          <select id="<?php echo \$p; ?>List" class="form-control" multiple size="12">
            <?php for (\$i=1; \$i<=12; \$i++): ?>
              <option value="U<?php echo \$i; ?>">U<?php echo \$i; ?></option>
              <option value="R<?php echo \$i; ?>">R<?php echo \$i; ?></option>
            <?php endfor; ?>
          </select>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="row mt-3">
      <!-- Inputs de cercanía -->
      <?php foreach ([[1,2],[1,3],[1,4],[2,3],[2,4],[3,4]] as \$pair): ?>
        <div class="col-md-2">
          <label>P<?php echo \$pair[0]; ?>-P<?php echo \$pair[1]; ?></label>
          <input type="number" id="c<?php echo \$pair[0].\$pair[1]; ?>" class="form-control" step="0.01" min="0" max="1" value="0.5">
        </div>
      <?php endforeach; ?>
      <div class="col-md-2 align-self-end">
        <button class="btn btn-primary" onclick="runPlanner()">Planificar</button>
      </div>
    </div>
  </form>

  <div id="result" class="mt-4">
    <h3>Descripción</h3>
    <p id="description"></p>
    <h3>Grafo de la mejor ruta</h3>
    <img id="graph" class="img-fluid" alt="Grafo de consenso">
    <h3>Top 10 Rutas</h3>
    <ul id="topRoutes" class="list-group"></ul>
  </div>
</div>

<script>
function runPlanner() {
  const payload = { data: {}, closeness: {} };
  ['Prop1','Prop2','Prop3','Prop4'].forEach(p => {
    const sel = document.getElementById(p + 'List');
    payload.data[p] = Array.from(sel.selectedOptions).map(o => o.value);
  });
  [[1,2],[1,3],[1,4],[2,3],[2,4],[3,4]].forEach(pair => {
    const key = '' + pair[0] + pair[1];
    payload.closeness[key] = parseFloat(document.getElementById('c' + key).value);
  });
  fetch('lab_planificador.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  })
  .then(r => r.json())
  .then(res => {
    if (res.error) {
      alert('Error: ' + res.error);
      return;
    }
    document.getElementById('description').innerText = res.description;
    document.getElementById('graph').src = 'data:image/png;base64,' + res.graph;
    const ul = document.getElementById('topRoutes'); ul.innerHTML = '';
    res.top10.forEach(item => {
      const li = document.createElement('li');
      li.className = 'list-group-item';
      li.innerText = item;
      ul.appendChild(li);
    });
  });
}
</script>

<?php include 'pie.php'; ?>
