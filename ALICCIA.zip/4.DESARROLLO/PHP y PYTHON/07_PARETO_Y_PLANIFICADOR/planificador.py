<?php
// lab_planificador.php
// Recoge entradas, envía JSON a planificador.py y muestra resultados

if (\$_SERVER['REQUEST_METHOD'] === 'POST') {
    // Leer JSON enviado desde JavaScript
    \$json = file_get_contents('php://input');
    // Invocar al script Python pasando el JSON por stdin
    \$cmd = 'python3 planificador.py';
    \$descriptors = [ ["pipe", "r"], ["pipe", "w"], ["pipe", "w"] ];
    \$process = proc_open(\$cmd, \$descriptors, \$pipes);
    if (is_resource(\$process)) {
        fwrite(\$pipes[0], \$json);
        fclose(\$pipes[0]);
        \$output = stream_get_contents(\$pipes[1]);
        fclose(\$pipes[1]);
        \$err = stream_get_contents(\$pipes[2]);
        fclose(\$pipes[2]);
        proc_close(\$process);
        if (\$err) {
            http_response_code(500);
            echo json_encode(['error' => \$err]);
        } else {
            header('Content-Type: application/json');
            echo \$output;
        }
    }
    exit;
}
?>

<!DOCTYPE html>

<html>
<head><title>Planificador de Consenso</title></head>
<body>
<h1>Planificador de Consenso</h1>
<form id="plannerForm">
  <!-- Cajas de propuestas -->
  <?php foreach (['Prop1','Prop2','Prop3','Prop4'] as \$p): ?>
    <div>
      <h3><?php echo \$p; ?></h3>
      <select id="<?php echo \$p; ?>_list" multiple size="12"></select>
    </div>
  <?php endforeach; ?>
  <!-- Inputs de cercanía -->
  <?php foreach ([[1,2],[1,3],[1,4],[2,3],[2,4],[3,4]] as \$pair): ?>
    <label>Closeness P<?php echo \$pair[0]; ?>-P<?php echo \$pair[1]; ?>:
      <input type="number" id="c<?php echo \$pair[0]; ?><?php echo \$pair[1]; ?>" step="0.01" min="0" max="1" value="0.5">
    </label>
  <?php endforeach; ?>
  <button type="button" onclick="runPlanner()">Planificar</button>
</form>
<div id="result">
  <h2>Descripción</h2>
  <p id="description"></p>
  <h2>Grafo</h2>
  <img id="graph" alt="Grafo de consenso">
  <h2>Top 10 rutas</h2>
  <ul id="topRoutes"></ul>
</div>
<script>
function runPlanner() {
  // Construir objeto JSON
  let data = {};
  ['Prop1','Prop2','Prop3','Prop4'].forEach(p => {
    let sel = document.getElementById(p + '_list');
    data[p] = Array.from(sel.selectedOptions).map(o => o.value);
  });
  let closeness = {};
  [[1,2],[1,3],[1,4],[2,3],[2,4],[3,4]].forEach(pair => {
    let id = 'c'+pair[0]+pair[1];
    closeness[pair.join('')] = parseFloat(document.getElementById(id).value);
  });
  let payload = { data: data, closeness: closeness };
  fetch('lab_planificador.php', {
    method: 'POST',
    body: JSON.stringify(payload)
  }).then(r=>r.json()).then(res=>{
    document.getElementById('description').innerText = res.description;
    document.getElementById('graph').src = 'data:image/png;base64,'+res.graph;
    let ul = document.getElementById('topRoutes'); ul.innerHTML='';
    res.top10.forEach(item=>{
      let li = document.createElement('li');
      li.innerText = item;
      ul.appendChild(li);
    });
  });
}
</script>

```python
# planificador.py
import sys, json, itertools
import numpy as np
from io import BytesIO
import base64
import networkx as nx
import matplotlib.pyplot as plt

# Leer JSON de stdin
inp = json.load(sys.stdin)
data = inp['data']
cl = inp['closeness']

proposals = list(data.keys())
# Construir matriz de cercanía 4x4
cm = np.eye(4)
pairs = {'12':(0,1),'13':(0,2),'14':(0,3),'23':(1,2),'24':(1,3),'34':(2,3)}
for k,v in pairs.items():
    cm[v] = cm[v[::-1]] = cl.get(k,0.5)

# Parámetros de coste
epsilon = 0.01; alpha=1.0; beta=3.0
orig_sup = {p:set(u for u in lst if u.startswith('U')) for p,lst in data.items()}
orig_rec = {p:set('U'+e[1:] for e in lst if e.startswith('R')) for p,lst in data.items()}

def simulate(seq):
    dyn = {p:set(orig_sup[p]) for p in proposals}
    trans=[]; total=0
    for a,b in seq:
        movers = dyn[a]-dyn[b]
        r = sum(1 for u in movers if u in orig_rec[b]); u = len(movers)-r
        base=1.0/(cm[proposals.index(a),proposals.index(b)]+epsilon)
        cost=alpha*base*u+beta*base*r
        dyn[b]|=movers; dyn[a]-=movers
        trans.append((f"{a}->{b}",cost,u,r)); total+=cost
    return trans,total

# Generar rutas
routes=[]
# serie
for perm in itertools.permutations(proposals,4):
    seq=list(zip(perm,perm[1:])); t,c=simulate(seq)
    routes.append(('serie',seq,t,c))
# paralelo
for dest in proposals:
    srcs=[p for p in proposals if p!=dest]
    seq=[(s,dest) for s in srcs]; t,c=simulate(seq)
    routes.append(('paralelo',seq,t,c))
# mixta
for ch in itertools.permutations(proposals,3):
    rest=[p for p in proposals if p not in ch]
    for s in rest:
        seq=[(ch[0],ch[1]),(ch[1],ch[2]),(s,ch[2])]
        t,c=simulate(seq); routes.append(('mixta',seq,t,c))
# ordenar
routes.sort(key=lambda x:x[3])
# mejor
kind,edges,trans,cost=routes[0]
# frase
if kind=='serie': seq=[edges[0][0]]+[b for(_,b) in edges]
    desc=f"La ruta óptima integra {'→'.join(seq)} (coste {cost:.2f})."
elif kind=='paralelo':
    dest=edges[0][1]; srcs=[a for(a,_) in edges]
    desc=f"La ruta óptima integra en paralelo {', '.join(srcs)}→{dest} (coste {cost:.2f})."
else:
    a1,b1=edges[0]; a2,b2=edges[1]; a3,b3=edges[2]
    desc=f"Ruta mixta: {a1}->{b1}, {a2}->{b2}, {a3}->{b3} (coste {cost:.2f})."
# grafo
G=nx.DiGraph()
for(a,b),(e,c,u,r) in zip(edges,trans): G.add_edge(a,b,weight=c)
pos={}
if kind=='serie':
    nodes=[edges[0][0]]+[b for(_,b) in edges]
    pos={nodes[i]:(i,0) for i in range(len(nodes))}
elif kind=='paralelo':
    srcs=[a for(a,_) in edges]
    for i,s in enumerate(srcs): pos[s]=(0,len(srcs)-1-i)
    pos[edges[0][1]]=(1,(len(srcs)-1)/2)
else:
    chain=[edges[0][0],edges[0][1],edges[1][1]]
    for i,n in enumerate(chain): pos[n]=(i,1)
    pos[edges[2][0]]=(2,0)
fig,ax=plt.subplots(figsize=(6,4));
nx.draw(G,pos,ax=ax,with_labels=True,arrows=True,node_size=800)
elab={(u,v):f"{d['weight']:.2f}" for u,v,d in G.edges(data=True)}
nx.draw_networkx_edge_labels(G,pos,edge_labels=elab)
ax.axis('off')
buf=BytesIO(); plt.savefig(buf, format='png'); buf.seek(0)
img_b64=base64.b64encode(buf.read()).decode()
# top10
top10=[', '.join(f"{e}(c={c:.2f},u={u},r={r})" for(e,c,u,r) in trans) + f" (total={c:.2f})" for _,_,trans,c in routes[:top_n]]
# salida JSON
print(json.dumps({
    'description': desc,
    'graph': img_b64,
    'top10': top10
}))
```
