# algebra_client_1.py

import os
from dotenv import load_dotenv
import openai

def get_system_prompt():
    return (
        "Eres un asistente experto en facilitación de deliberación colectiva. "
        "Aplicas un álgebra deliberativa sobre propuestas en lenguaje natural. "
        "Sigue fielmente las instrucciones de cada operación sin agregar justificaciones ni encabezados."
    )

def generar_prompt(op, tema=None, p1=None, p2=None):
    op = op.lower()

    if op == "union":
        return f"""Fusiona estas dos propuestas en una sola, sin encabezados ni listas:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """

    elif op == "interseccion":
        return f"""Redacta una propuesta que represente solo las ideas comunes entre las siguientes dos. No uses listas ni encabezados:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """

    elif op == "cercania":
        return f"""Evalúa la similitud entre estas propuestas sobre el tema "{tema}". 
Responde solo con un número de dos decimales entre 0 y 1:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """

    elif op == "simplificar_p1":
        return f"""Simplifica esta propuesta sin perder su sentido. Solo devuelve la versión simplificada:
{p1}"""

    elif op == "simplificar_p2":
        return f"""Simplifica esta propuesta sin perder su sentido. Solo devuelve la versión simplificada:
{p2}"""

    elif op == "chequear_p1":
        return f"""Responde solo con una de estas frases:
- "Propuesta válida"
- "Propuesta sin relación con el tema/problema"

Tema: {tema}
Propuesta: {p1}"""

    elif op == "chequear_p2":
        return f"""Responde solo con una de estas frases:
- "Propuesta válida"
- "Propuesta sin relación con el tema/problema"

Tema: {tema}
Propuesta: {p2}"""

    else:
        raise ValueError(f"Operación desconocida: {op}")

def resolver_operacion(tema, p1, p2, op, model="gpt-4o", temperature=0.2):
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        raise EnvironmentError("No se encontró OPENAI_API_KEY en .env")

    client = openai.OpenAI(api_key=api_key)

    system = get_system_prompt()
    user = generar_prompt(op, tema, p1, p2)

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user}
        ],
        temperature=temperature
    )

    return response.choices[0].message.content.strip()# algebra_client.py

import os
from dotenv import load_dotenv
import openai

def get_system_prompt():
    return (
        "Eres un asistente experto en facilitación de deliberación colectiva. "
        "Aplicas un álgebra deliberativa sobre propuestas en lenguaje natural. "
        "Sigue fielmente las instrucciones de cada operación sin agregar justificaciones ni encabezados."
    )

def generar_prompt(op, tema=None, p1=None, p2=None):
    op = op.lower()

    if op == "union":
        return f"""Fusiona estas dos propuestas en una sola, sin encabezados ni listas:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """

    elif op == "interseccion":
        return f"""Redacta una propuesta que represente solo las ideas comunes entre las siguientes dos. No uses listas ni encabezados:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """

    elif op == "cercania":
        return f"""Evalúa la similitud entre estas propuestas sobre el tema "{tema}". 
Responde solo con un número con tres decimales entre 0 y 1:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """

    elif op == "simplificar_p1":
        return f"""Simplifica esta propuesta sin perder su sentido. Solo devuelve la versión simplificada:
{p1}"""

    elif op == "simplificar_p2":
        return f"""Simplifica esta propuesta sin perder su sentido. Solo devuelve la versión simplificada:
{p2}"""

    elif op == "chequear_p1":
        return f"""Responde solo con una de estas frases:
- "Propuesta válida"
- "Propuesta sin relación con el tema/problema"

Tema: {tema}
Propuesta: {p1}"""

    elif op == "chequear_p2":
        return f"""Responde solo con una de estas frases:
- "Propuesta válida"
- "Propuesta sin relación con el tema/problema"

Tema: {tema}
Propuesta: {p2}"""

    else:
        raise ValueError(f"Operación desconocida: {op}")

def resolver_operacion(tema, p1, p2, op, model="gpt-4o", temperature=0.2):
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        raise EnvironmentError("No se encontró OPENAI_API_KEY en .env")

    client = openai.OpenAI(api_key=api_key)

    system = get_system_prompt()
    user = generar_prompt(op, tema, p1, p2)

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user}
        ],
        temperature=temperature
    )

    return response.choices[0].message.content.strip()