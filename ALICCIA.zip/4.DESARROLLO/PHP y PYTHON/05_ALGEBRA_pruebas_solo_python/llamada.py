# llamada

# !pip install openai python-dotenv
# !pip install --upgrade openai python-dotenv



from algebra_client_4 import resolver_operacion

# Datos de entrada
tema = "Gestión hídrica"
p1 = "Expandir redes de distribución de agua potable en áreas rurales."
p2 = "Promover recolección de agua de lluvia en comunidades alejadas."
op = "cercania"

resultado = resolver_operacion(tema, p1, p2, op, debug=False)
print("Resultado:", resultado)