# algebra_client_3.py (CON DEBUG Y TOOLS)

import os
import json
from dotenv import load_dotenv
import openai

# -------------------------------
# Prompt del sistema
# -------------------------------
def get_system_prompt():
    return (
        "Eres un asistente experto en facilitación de deliberación colectiva. "
        "Aplicas un álgebra deliberativa sobre propuestas en lenguaje natural. "
        "Sigue fielmente las instrucciones de cada operación sin encabezados ni explicaciones innecesarias."
    )

# -------------------------------
# Herramienta declarada (para 'cercania')
# -------------------------------
tools = [
    {
        "type": "function",
        "function": {
            "name": "calcular_cercania",
            "description": "Calcula la cercanía semántica entre dos propuestas",
            "parameters": {
                "type": "object",
                "properties": {
                    "propuesta_a": {"type": "string"},
                    "propuesta_b": {"type": "string"}
                },
                "required": ["propuesta_a", "propuesta_b"]
            }
        }
    }
]

def calcular_cercania(propuesta_a, propuesta_b):
    # Aquí podrías usar embeddings o lógica real
    return {"resultado": 0.83}  # Resultado simulado

# -------------------------------
# Generación de prompt para otras operaciones
# -------------------------------
def generar_prompt(op, tema=None, p1=None, p2=None):
    op = op.lower()
    if op == "union":
        return f"""Fusiona estas dos propuestas en una sola, sin encabezados ni listas:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """
    elif op == "interseccion":
        return f"""Redacta una propuesta que represente solo las ideas comunes entre las siguientes dos. No uses listas ni encabezados:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """
    elif op == "simplificar_p1":
        return f"""Simplifica esta propuesta sin perder su sentido. Solo devuelve la versión simplificada:
{p1}"""
    elif op == "simplificar_p2":
        return f"""Simplifica esta propuesta sin perder su sentido. Solo devuelve la versión simplificada:
{p2}"""
    elif op == "chequear_p1":
        return f"""Responde solo con una de estas frases:
- "Propuesta válida"
- "Propuesta sin relación con el tema/problema"

Tema: {tema}
Propuesta: {p1}"""
    elif op == "chequear_p2":
        return f"""Responde solo con una de estas frases:
- "Propuesta válida"
- "Propuesta sin relación con el tema/problema"

Tema: {tema}
Propuesta: {p2}"""
    else:
        raise ValueError(f"Operación desconocida o no soportada: {op}")

# -------------------------------
# Función principal
# -------------------------------
def resolver_operacion(tema, p1, p2, op, model="gpt-4o", temperature=0.2, debug=False):
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise EnvironmentError("No se encontró OPENAI_API_KEY en el archivo .env")

    client = openai.OpenAI(api_key=api_key)

    system_prompt = get_system_prompt()

    # -------------------------------
    # OPERACIÓN CON TOOL: cercania
    # -------------------------------
    if op.lower() == "cercania":
        user_content = f"""Evalúa la cercanía entre las siguientes dos propuestas:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """

        # Primer paso: el modelo decide llamar a la función
        tool_response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content}
            ],
            tools=tools,
            tool_choice="auto"
        )

        assistant_msg = tool_response.choices[0].message
        tool_call = assistant_msg.tool_calls[0]
        args = json.loads(tool_call.function.arguments)

        if tool_call.function.name == "calcular_cercania":
            resultado = calcular_cercania(**args)

            # Segundo paso: enviamos la respuesta de la función
            final_response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_content},
                    {"role": "assistant", "content": None, "tool_calls": [tool_call]},
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "name": tool_call.function.name,
                        "content": json.dumps(resultado)
                    }
                ]
            )

            output = final_response.choices[0].message.content.strip()

            if debug:
                return {
                    "operacion": op,
                    "tema": tema,
                    "input": {"p1": p1, "p2": p2},
                    "tool_result": resultado,
                    "output": output
                }
            else:
                return output

    # -------------------------------
    # OPERACIONES TEXTUALES NORMALES
    # -------------------------------
    user_prompt = generar_prompt(op, tema, p1, p2)
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        temperature=temperature
    )

    output_text = response.choices[0].message.content.strip()

    if debug:
        return {
            "operacion": op,
            "tema": tema,
            "input": {"p1": p1, "p2": p2},
            "system_prompt": system_prompt,
            "user_prompt": user_prompt,
            "output": output_text,
            "usage": dict(response.usage) if response.usage else {}
        }
    else:
        return output_text
