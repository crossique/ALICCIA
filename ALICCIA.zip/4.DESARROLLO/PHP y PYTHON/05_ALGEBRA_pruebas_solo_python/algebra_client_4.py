# algebra_client_4.py

import os
import json
from dotenv import load_dotenv
import openai

# -------------------------------
# Prompt del sistema
# -------------------------------
def get_system_prompt():
    return (
        "Eres un asistente experto en facilitación de deliberación colectiva. "
        "Aplicas un álgebra deliberativa sobre propuestas en lenguaje natural. "
        "Utilizas funciones auxiliares si es necesario. No expliques tu razonamiento."
    )

# -------------------------------
# Tools disponibles
# -------------------------------
tools = [
    {
        "type": "function",
        "function": {
            "name": "calcular_cercania",
            "description": "Calcula la cercanía semántica entre dos propuestas",
            "parameters": {
                "type": "object",
                "properties": {
                    "propuesta_a": {"type": "string"},
                    "propuesta_b": {"type": "string"}
                },
                "required": ["propuesta_a", "propuesta_b"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "detectar_contradiccion",
            "description": "Detecta si hay contradicción entre dos propuestas",
            "parameters": {
                "type": "object",
                "properties": {
                    "propuesta_a": {"type": "string"},
                    "propuesta_b": {"type": "string"}
                },
                "required": ["propuesta_a", "propuesta_b"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "medir_alineamiento_ideologico",
            "description": "Evalúa el alineamiento ideológico entre dos propuestas (escala 0 a 1)",
            "parameters": {
                "type": "object",
                "properties": {
                    "propuesta_a": {"type": "string"},
                    "propuesta_b": {"type": "string"}
                },
                "required": ["propuesta_a", "propuesta_b"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "clasificar_tematica",
            "description": "Clasifica una propuesta dentro de un conjunto de temas predefinidos",
            "parameters": {
                "type": "object",
                "properties": {
                    "propuesta": {"type": "string"}
                },
                "required": ["propuesta"]
            }
        }
    }
]

# -------------------------------
# Simulaciones funcionales
# -------------------------------
def calcular_cercania(propuesta_a, propuesta_b):
    return {"resultado": 0.84}

def detectar_contradiccion(propuesta_a, propuesta_b):
    return {"contradiccion": False}

def medir_alineamiento_ideologico(propuesta_a, propuesta_b):
    return {"alineamiento": 0.65}

def clasificar_tematica(propuesta):
    return {"tema": "Infraestructura hídrica"}

# -------------------------------
# Prompt textual para operaciones normales
# -------------------------------
def generar_prompt(op, tema=None, p1=None, p2=None):
    op = op.lower()
    if op == "union":
        return f"""Fusiona estas dos propuestas en una sola, sin encabezados ni listas:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """
    elif op == "interseccion":
        return f"""Redacta una propuesta que represente solo las ideas comunes entre las siguientes dos. No uses listas ni encabezados:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """
    elif op == "simplificar_p1":
        return f"""Simplifica esta propuesta sin perder su sentido. Solo devuelve la versión simplificada:
{p1}"""
    elif op == "simplificar_p2":
        return f"""Simplifica esta propuesta sin perder su sentido. Solo devuelve la versión simplificada:
{p2}"""
    elif op == "chequear_p1":
        return f"""Responde solo con una de estas frases:
- "Propuesta válida"
- "Propuesta sin relación con el tema/problema"
Tema: {tema}
Propuesta: {p1}"""
    elif op == "chequear_p2":
        return f"""Responde solo con una de estas frases:
- "Propuesta válida"
- "Propuesta sin relación con el tema/problema"
Tema: {tema}
Propuesta: {p2}"""
    else:
        raise ValueError(f"Operación desconocida o no soportada: {op}")

# -------------------------------
# Función principal
# -------------------------------
def resolver_operacion(tema, p1, p2, op, model="gpt-4o", temperature=0.2, debug=False):
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise EnvironmentError("No se encontró OPENAI_API_KEY en el archivo .env")

    client = openai.OpenAI(api_key=api_key)
    system_prompt = get_system_prompt()
    op = op.lower()

    # -------------------------------
    # OPERACIONES QUE USAN TOOLS
    # -------------------------------
    if op in {"cercania", "contradiccion", "alineamiento", "clasificar"}:
        if op == "clasificar":
            user_content = f"""Clasifica esta propuesta dentro de un conjunto de temas:
{p1}"""
        else:
            user_content = f"""Evalúa la operación '{op}' entre estas propuestas:
Propuesta A: "{p1}"
Propuesta B: "{p2}" """

        # Paso 1: el modelo decide llamar a la función
        tool_response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content}
            ],
            tools=tools,
            tool_choice="auto"
        )

        assistant_msg = tool_response.choices[0].message
        tool_call = assistant_msg.tool_calls[0]
        args = json.loads(tool_call.function.arguments)

        # Ejecutar función simulada local
        if tool_call.function.name == "calcular_cercania":
            resultado = calcular_cercania(**args)
        elif tool_call.function.name == "detectar_contradiccion":
            resultado = detectar_contradiccion(**args)
        elif tool_call.function.name == "medir_alineamiento_ideologico":
            resultado = medir_alineamiento_ideologico(**args)
        elif tool_call.function.name == "clasificar_tematica":
            resultado = clasificar_tematica(**args)
        else:
            raise ValueError("Tool desconocido")

        # Paso 2: enviar respuesta como "tool"
        final_response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content},
                {"role": "assistant", "content": None, "tool_calls": [tool_call]},
                {
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "name": tool_call.function.name,
                    "content": json.dumps(resultado)
                }
            ]
        )

        output = final_response.choices[0].message.content.strip()

        if debug:
            return {
                "operacion": op,
                "input": {"p1": p1, "p2": p2},
                "tool": tool_call.function.name,
                "tool_args": args,
                "tool_result": resultado,
                "output": output
            }
        else:
            return output

    # -------------------------------
    # OPERACIONES TEXTUALES NORMALES
    # -------------------------------
    user_prompt = generar_prompt(op, tema, p1, p2)
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        temperature=temperature
    )

    output_text = response.choices[0].message.content.strip()

    if debug:
        return {
            "operacion": op,
            "tema": tema,
            "input": {"p1": p1, "p2": p2},
            "system_prompt": system_prompt,
            "user_prompt": user_prompt,
            "output": output_text,
            "usage": dict(response.usage) if response.usage else {}
        }
    else:
        return output_text
